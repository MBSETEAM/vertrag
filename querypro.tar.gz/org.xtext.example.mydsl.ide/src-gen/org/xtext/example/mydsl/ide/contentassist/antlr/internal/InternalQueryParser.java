package org.xtext.example.mydsl.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import org.xtext.example.mydsl.services.QueryGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalQueryParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_STRING", "RULE_ID", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'Anfrage:'", "'Kriterium'", "'()'"
    };
    public static final int RULE_ID=5;
    public static final int RULE_WS=9;
    public static final int RULE_STRING=4;
    public static final int RULE_ANY_OTHER=10;
    public static final int RULE_SL_COMMENT=8;
    public static final int RULE_INT=6;
    public static final int T__11=11;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int EOF=-1;

    // delegates
    // delegators


        public InternalQueryParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalQueryParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalQueryParser.tokenNames; }
    public String getGrammarFileName() { return "InternalQuery.g"; }


    	private QueryGrammarAccess grammarAccess;

    	public void setGrammarAccess(QueryGrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRuleQuery"
    // InternalQuery.g:53:1: entryRuleQuery : ruleQuery EOF ;
    public final void entryRuleQuery() throws RecognitionException {
        try {
            // InternalQuery.g:54:1: ( ruleQuery EOF )
            // InternalQuery.g:55:1: ruleQuery EOF
            {
             before(grammarAccess.getQueryRule()); 
            pushFollow(FOLLOW_1);
            ruleQuery();

            state._fsp--;

             after(grammarAccess.getQueryRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleQuery"


    // $ANTLR start "ruleQuery"
    // InternalQuery.g:62:1: ruleQuery : ( ( rule__Query__Group__0 ) ) ;
    public final void ruleQuery() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQuery.g:66:2: ( ( ( rule__Query__Group__0 ) ) )
            // InternalQuery.g:67:2: ( ( rule__Query__Group__0 ) )
            {
            // InternalQuery.g:67:2: ( ( rule__Query__Group__0 ) )
            // InternalQuery.g:68:3: ( rule__Query__Group__0 )
            {
             before(grammarAccess.getQueryAccess().getGroup()); 
            // InternalQuery.g:69:3: ( rule__Query__Group__0 )
            // InternalQuery.g:69:4: rule__Query__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Query__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getQueryAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleQuery"


    // $ANTLR start "entryRuleQuestion"
    // InternalQuery.g:78:1: entryRuleQuestion : ruleQuestion EOF ;
    public final void entryRuleQuestion() throws RecognitionException {
        try {
            // InternalQuery.g:79:1: ( ruleQuestion EOF )
            // InternalQuery.g:80:1: ruleQuestion EOF
            {
             before(grammarAccess.getQuestionRule()); 
            pushFollow(FOLLOW_1);
            ruleQuestion();

            state._fsp--;

             after(grammarAccess.getQuestionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleQuestion"


    // $ANTLR start "ruleQuestion"
    // InternalQuery.g:87:1: ruleQuestion : ( ( rule__Question__Group__0 ) ) ;
    public final void ruleQuestion() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQuery.g:91:2: ( ( ( rule__Question__Group__0 ) ) )
            // InternalQuery.g:92:2: ( ( rule__Question__Group__0 ) )
            {
            // InternalQuery.g:92:2: ( ( rule__Question__Group__0 ) )
            // InternalQuery.g:93:3: ( rule__Question__Group__0 )
            {
             before(grammarAccess.getQuestionAccess().getGroup()); 
            // InternalQuery.g:94:3: ( rule__Question__Group__0 )
            // InternalQuery.g:94:4: rule__Question__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Question__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getQuestionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleQuestion"


    // $ANTLR start "entryRuleOption"
    // InternalQuery.g:103:1: entryRuleOption : ruleOption EOF ;
    public final void entryRuleOption() throws RecognitionException {
        try {
            // InternalQuery.g:104:1: ( ruleOption EOF )
            // InternalQuery.g:105:1: ruleOption EOF
            {
             before(grammarAccess.getOptionRule()); 
            pushFollow(FOLLOW_1);
            ruleOption();

            state._fsp--;

             after(grammarAccess.getOptionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleOption"


    // $ANTLR start "ruleOption"
    // InternalQuery.g:112:1: ruleOption : ( ( rule__Option__Group__0 ) ) ;
    public final void ruleOption() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQuery.g:116:2: ( ( ( rule__Option__Group__0 ) ) )
            // InternalQuery.g:117:2: ( ( rule__Option__Group__0 ) )
            {
            // InternalQuery.g:117:2: ( ( rule__Option__Group__0 ) )
            // InternalQuery.g:118:3: ( rule__Option__Group__0 )
            {
             before(grammarAccess.getOptionAccess().getGroup()); 
            // InternalQuery.g:119:3: ( rule__Option__Group__0 )
            // InternalQuery.g:119:4: rule__Option__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Option__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getOptionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleOption"


    // $ANTLR start "rule__Query__Group__0"
    // InternalQuery.g:127:1: rule__Query__Group__0 : rule__Query__Group__0__Impl rule__Query__Group__1 ;
    public final void rule__Query__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQuery.g:131:1: ( rule__Query__Group__0__Impl rule__Query__Group__1 )
            // InternalQuery.g:132:2: rule__Query__Group__0__Impl rule__Query__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__Query__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Query__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Query__Group__0"


    // $ANTLR start "rule__Query__Group__0__Impl"
    // InternalQuery.g:139:1: rule__Query__Group__0__Impl : ( ( rule__Query__Group_0__0 )? ) ;
    public final void rule__Query__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQuery.g:143:1: ( ( ( rule__Query__Group_0__0 )? ) )
            // InternalQuery.g:144:1: ( ( rule__Query__Group_0__0 )? )
            {
            // InternalQuery.g:144:1: ( ( rule__Query__Group_0__0 )? )
            // InternalQuery.g:145:2: ( rule__Query__Group_0__0 )?
            {
             before(grammarAccess.getQueryAccess().getGroup_0()); 
            // InternalQuery.g:146:2: ( rule__Query__Group_0__0 )?
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==11) ) {
                alt1=1;
            }
            switch (alt1) {
                case 1 :
                    // InternalQuery.g:146:3: rule__Query__Group_0__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Query__Group_0__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getQueryAccess().getGroup_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Query__Group__0__Impl"


    // $ANTLR start "rule__Query__Group__1"
    // InternalQuery.g:154:1: rule__Query__Group__1 : rule__Query__Group__1__Impl ;
    public final void rule__Query__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQuery.g:158:1: ( rule__Query__Group__1__Impl )
            // InternalQuery.g:159:2: rule__Query__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Query__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Query__Group__1"


    // $ANTLR start "rule__Query__Group__1__Impl"
    // InternalQuery.g:165:1: rule__Query__Group__1__Impl : ( ( rule__Query__QuestionsAssignment_1 )* ) ;
    public final void rule__Query__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQuery.g:169:1: ( ( ( rule__Query__QuestionsAssignment_1 )* ) )
            // InternalQuery.g:170:1: ( ( rule__Query__QuestionsAssignment_1 )* )
            {
            // InternalQuery.g:170:1: ( ( rule__Query__QuestionsAssignment_1 )* )
            // InternalQuery.g:171:2: ( rule__Query__QuestionsAssignment_1 )*
            {
             before(grammarAccess.getQueryAccess().getQuestionsAssignment_1()); 
            // InternalQuery.g:172:2: ( rule__Query__QuestionsAssignment_1 )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==12) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // InternalQuery.g:172:3: rule__Query__QuestionsAssignment_1
            	    {
            	    pushFollow(FOLLOW_4);
            	    rule__Query__QuestionsAssignment_1();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);

             after(grammarAccess.getQueryAccess().getQuestionsAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Query__Group__1__Impl"


    // $ANTLR start "rule__Query__Group_0__0"
    // InternalQuery.g:181:1: rule__Query__Group_0__0 : rule__Query__Group_0__0__Impl rule__Query__Group_0__1 ;
    public final void rule__Query__Group_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQuery.g:185:1: ( rule__Query__Group_0__0__Impl rule__Query__Group_0__1 )
            // InternalQuery.g:186:2: rule__Query__Group_0__0__Impl rule__Query__Group_0__1
            {
            pushFollow(FOLLOW_5);
            rule__Query__Group_0__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Query__Group_0__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Query__Group_0__0"


    // $ANTLR start "rule__Query__Group_0__0__Impl"
    // InternalQuery.g:193:1: rule__Query__Group_0__0__Impl : ( 'Anfrage:' ) ;
    public final void rule__Query__Group_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQuery.g:197:1: ( ( 'Anfrage:' ) )
            // InternalQuery.g:198:1: ( 'Anfrage:' )
            {
            // InternalQuery.g:198:1: ( 'Anfrage:' )
            // InternalQuery.g:199:2: 'Anfrage:'
            {
             before(grammarAccess.getQueryAccess().getAnfrageKeyword_0_0()); 
            match(input,11,FOLLOW_2); 
             after(grammarAccess.getQueryAccess().getAnfrageKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Query__Group_0__0__Impl"


    // $ANTLR start "rule__Query__Group_0__1"
    // InternalQuery.g:208:1: rule__Query__Group_0__1 : rule__Query__Group_0__1__Impl ;
    public final void rule__Query__Group_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQuery.g:212:1: ( rule__Query__Group_0__1__Impl )
            // InternalQuery.g:213:2: rule__Query__Group_0__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Query__Group_0__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Query__Group_0__1"


    // $ANTLR start "rule__Query__Group_0__1__Impl"
    // InternalQuery.g:219:1: rule__Query__Group_0__1__Impl : ( ( rule__Query__DescriptionAssignment_0_1 ) ) ;
    public final void rule__Query__Group_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQuery.g:223:1: ( ( ( rule__Query__DescriptionAssignment_0_1 ) ) )
            // InternalQuery.g:224:1: ( ( rule__Query__DescriptionAssignment_0_1 ) )
            {
            // InternalQuery.g:224:1: ( ( rule__Query__DescriptionAssignment_0_1 ) )
            // InternalQuery.g:225:2: ( rule__Query__DescriptionAssignment_0_1 )
            {
             before(grammarAccess.getQueryAccess().getDescriptionAssignment_0_1()); 
            // InternalQuery.g:226:2: ( rule__Query__DescriptionAssignment_0_1 )
            // InternalQuery.g:226:3: rule__Query__DescriptionAssignment_0_1
            {
            pushFollow(FOLLOW_2);
            rule__Query__DescriptionAssignment_0_1();

            state._fsp--;


            }

             after(grammarAccess.getQueryAccess().getDescriptionAssignment_0_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Query__Group_0__1__Impl"


    // $ANTLR start "rule__Question__Group__0"
    // InternalQuery.g:235:1: rule__Question__Group__0 : rule__Question__Group__0__Impl rule__Question__Group__1 ;
    public final void rule__Question__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQuery.g:239:1: ( rule__Question__Group__0__Impl rule__Question__Group__1 )
            // InternalQuery.g:240:2: rule__Question__Group__0__Impl rule__Question__Group__1
            {
            pushFollow(FOLLOW_5);
            rule__Question__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Question__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Question__Group__0"


    // $ANTLR start "rule__Question__Group__0__Impl"
    // InternalQuery.g:247:1: rule__Question__Group__0__Impl : ( 'Kriterium' ) ;
    public final void rule__Question__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQuery.g:251:1: ( ( 'Kriterium' ) )
            // InternalQuery.g:252:1: ( 'Kriterium' )
            {
            // InternalQuery.g:252:1: ( 'Kriterium' )
            // InternalQuery.g:253:2: 'Kriterium'
            {
             before(grammarAccess.getQuestionAccess().getKriteriumKeyword_0()); 
            match(input,12,FOLLOW_2); 
             after(grammarAccess.getQuestionAccess().getKriteriumKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Question__Group__0__Impl"


    // $ANTLR start "rule__Question__Group__1"
    // InternalQuery.g:262:1: rule__Question__Group__1 : rule__Question__Group__1__Impl rule__Question__Group__2 ;
    public final void rule__Question__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQuery.g:266:1: ( rule__Question__Group__1__Impl rule__Question__Group__2 )
            // InternalQuery.g:267:2: rule__Question__Group__1__Impl rule__Question__Group__2
            {
            pushFollow(FOLLOW_6);
            rule__Question__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Question__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Question__Group__1"


    // $ANTLR start "rule__Question__Group__1__Impl"
    // InternalQuery.g:274:1: rule__Question__Group__1__Impl : ( ( rule__Question__TitleAssignment_1 ) ) ;
    public final void rule__Question__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQuery.g:278:1: ( ( ( rule__Question__TitleAssignment_1 ) ) )
            // InternalQuery.g:279:1: ( ( rule__Question__TitleAssignment_1 ) )
            {
            // InternalQuery.g:279:1: ( ( rule__Question__TitleAssignment_1 ) )
            // InternalQuery.g:280:2: ( rule__Question__TitleAssignment_1 )
            {
             before(grammarAccess.getQuestionAccess().getTitleAssignment_1()); 
            // InternalQuery.g:281:2: ( rule__Question__TitleAssignment_1 )
            // InternalQuery.g:281:3: rule__Question__TitleAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Question__TitleAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getQuestionAccess().getTitleAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Question__Group__1__Impl"


    // $ANTLR start "rule__Question__Group__2"
    // InternalQuery.g:289:1: rule__Question__Group__2 : rule__Question__Group__2__Impl rule__Question__Group__3 ;
    public final void rule__Question__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQuery.g:293:1: ( rule__Question__Group__2__Impl rule__Question__Group__3 )
            // InternalQuery.g:294:2: rule__Question__Group__2__Impl rule__Question__Group__3
            {
            pushFollow(FOLLOW_7);
            rule__Question__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Question__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Question__Group__2"


    // $ANTLR start "rule__Question__Group__2__Impl"
    // InternalQuery.g:301:1: rule__Question__Group__2__Impl : ( ( rule__Question__NameAssignment_2 ) ) ;
    public final void rule__Question__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQuery.g:305:1: ( ( ( rule__Question__NameAssignment_2 ) ) )
            // InternalQuery.g:306:1: ( ( rule__Question__NameAssignment_2 ) )
            {
            // InternalQuery.g:306:1: ( ( rule__Question__NameAssignment_2 ) )
            // InternalQuery.g:307:2: ( rule__Question__NameAssignment_2 )
            {
             before(grammarAccess.getQuestionAccess().getNameAssignment_2()); 
            // InternalQuery.g:308:2: ( rule__Question__NameAssignment_2 )
            // InternalQuery.g:308:3: rule__Question__NameAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Question__NameAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getQuestionAccess().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Question__Group__2__Impl"


    // $ANTLR start "rule__Question__Group__3"
    // InternalQuery.g:316:1: rule__Question__Group__3 : rule__Question__Group__3__Impl ;
    public final void rule__Question__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQuery.g:320:1: ( rule__Question__Group__3__Impl )
            // InternalQuery.g:321:2: rule__Question__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Question__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Question__Group__3"


    // $ANTLR start "rule__Question__Group__3__Impl"
    // InternalQuery.g:327:1: rule__Question__Group__3__Impl : ( ( ( rule__Question__OptionsAssignment_3 ) ) ( ( rule__Question__OptionsAssignment_3 )* ) ) ;
    public final void rule__Question__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQuery.g:331:1: ( ( ( ( rule__Question__OptionsAssignment_3 ) ) ( ( rule__Question__OptionsAssignment_3 )* ) ) )
            // InternalQuery.g:332:1: ( ( ( rule__Question__OptionsAssignment_3 ) ) ( ( rule__Question__OptionsAssignment_3 )* ) )
            {
            // InternalQuery.g:332:1: ( ( ( rule__Question__OptionsAssignment_3 ) ) ( ( rule__Question__OptionsAssignment_3 )* ) )
            // InternalQuery.g:333:2: ( ( rule__Question__OptionsAssignment_3 ) ) ( ( rule__Question__OptionsAssignment_3 )* )
            {
            // InternalQuery.g:333:2: ( ( rule__Question__OptionsAssignment_3 ) )
            // InternalQuery.g:334:3: ( rule__Question__OptionsAssignment_3 )
            {
             before(grammarAccess.getQuestionAccess().getOptionsAssignment_3()); 
            // InternalQuery.g:335:3: ( rule__Question__OptionsAssignment_3 )
            // InternalQuery.g:335:4: rule__Question__OptionsAssignment_3
            {
            pushFollow(FOLLOW_8);
            rule__Question__OptionsAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getQuestionAccess().getOptionsAssignment_3()); 

            }

            // InternalQuery.g:338:2: ( ( rule__Question__OptionsAssignment_3 )* )
            // InternalQuery.g:339:3: ( rule__Question__OptionsAssignment_3 )*
            {
             before(grammarAccess.getQuestionAccess().getOptionsAssignment_3()); 
            // InternalQuery.g:340:3: ( rule__Question__OptionsAssignment_3 )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==13) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // InternalQuery.g:340:4: rule__Question__OptionsAssignment_3
            	    {
            	    pushFollow(FOLLOW_8);
            	    rule__Question__OptionsAssignment_3();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);

             after(grammarAccess.getQuestionAccess().getOptionsAssignment_3()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Question__Group__3__Impl"


    // $ANTLR start "rule__Option__Group__0"
    // InternalQuery.g:350:1: rule__Option__Group__0 : rule__Option__Group__0__Impl rule__Option__Group__1 ;
    public final void rule__Option__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQuery.g:354:1: ( rule__Option__Group__0__Impl rule__Option__Group__1 )
            // InternalQuery.g:355:2: rule__Option__Group__0__Impl rule__Option__Group__1
            {
            pushFollow(FOLLOW_5);
            rule__Option__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Option__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Option__Group__0"


    // $ANTLR start "rule__Option__Group__0__Impl"
    // InternalQuery.g:362:1: rule__Option__Group__0__Impl : ( '()' ) ;
    public final void rule__Option__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQuery.g:366:1: ( ( '()' ) )
            // InternalQuery.g:367:1: ( '()' )
            {
            // InternalQuery.g:367:1: ( '()' )
            // InternalQuery.g:368:2: '()'
            {
             before(grammarAccess.getOptionAccess().getLeftParenthesisRightParenthesisKeyword_0()); 
            match(input,13,FOLLOW_2); 
             after(grammarAccess.getOptionAccess().getLeftParenthesisRightParenthesisKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Option__Group__0__Impl"


    // $ANTLR start "rule__Option__Group__1"
    // InternalQuery.g:377:1: rule__Option__Group__1 : rule__Option__Group__1__Impl rule__Option__Group__2 ;
    public final void rule__Option__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQuery.g:381:1: ( rule__Option__Group__1__Impl rule__Option__Group__2 )
            // InternalQuery.g:382:2: rule__Option__Group__1__Impl rule__Option__Group__2
            {
            pushFollow(FOLLOW_6);
            rule__Option__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Option__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Option__Group__1"


    // $ANTLR start "rule__Option__Group__1__Impl"
    // InternalQuery.g:389:1: rule__Option__Group__1__Impl : ( ( rule__Option__TitleAssignment_1 ) ) ;
    public final void rule__Option__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQuery.g:393:1: ( ( ( rule__Option__TitleAssignment_1 ) ) )
            // InternalQuery.g:394:1: ( ( rule__Option__TitleAssignment_1 ) )
            {
            // InternalQuery.g:394:1: ( ( rule__Option__TitleAssignment_1 ) )
            // InternalQuery.g:395:2: ( rule__Option__TitleAssignment_1 )
            {
             before(grammarAccess.getOptionAccess().getTitleAssignment_1()); 
            // InternalQuery.g:396:2: ( rule__Option__TitleAssignment_1 )
            // InternalQuery.g:396:3: rule__Option__TitleAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Option__TitleAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getOptionAccess().getTitleAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Option__Group__1__Impl"


    // $ANTLR start "rule__Option__Group__2"
    // InternalQuery.g:404:1: rule__Option__Group__2 : rule__Option__Group__2__Impl ;
    public final void rule__Option__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQuery.g:408:1: ( rule__Option__Group__2__Impl )
            // InternalQuery.g:409:2: rule__Option__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Option__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Option__Group__2"


    // $ANTLR start "rule__Option__Group__2__Impl"
    // InternalQuery.g:415:1: rule__Option__Group__2__Impl : ( ( rule__Option__NameAssignment_2 ) ) ;
    public final void rule__Option__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQuery.g:419:1: ( ( ( rule__Option__NameAssignment_2 ) ) )
            // InternalQuery.g:420:1: ( ( rule__Option__NameAssignment_2 ) )
            {
            // InternalQuery.g:420:1: ( ( rule__Option__NameAssignment_2 ) )
            // InternalQuery.g:421:2: ( rule__Option__NameAssignment_2 )
            {
             before(grammarAccess.getOptionAccess().getNameAssignment_2()); 
            // InternalQuery.g:422:2: ( rule__Option__NameAssignment_2 )
            // InternalQuery.g:422:3: rule__Option__NameAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Option__NameAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getOptionAccess().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Option__Group__2__Impl"


    // $ANTLR start "rule__Query__DescriptionAssignment_0_1"
    // InternalQuery.g:431:1: rule__Query__DescriptionAssignment_0_1 : ( RULE_STRING ) ;
    public final void rule__Query__DescriptionAssignment_0_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQuery.g:435:1: ( ( RULE_STRING ) )
            // InternalQuery.g:436:2: ( RULE_STRING )
            {
            // InternalQuery.g:436:2: ( RULE_STRING )
            // InternalQuery.g:437:3: RULE_STRING
            {
             before(grammarAccess.getQueryAccess().getDescriptionSTRINGTerminalRuleCall_0_1_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getQueryAccess().getDescriptionSTRINGTerminalRuleCall_0_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Query__DescriptionAssignment_0_1"


    // $ANTLR start "rule__Query__QuestionsAssignment_1"
    // InternalQuery.g:446:1: rule__Query__QuestionsAssignment_1 : ( ruleQuestion ) ;
    public final void rule__Query__QuestionsAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQuery.g:450:1: ( ( ruleQuestion ) )
            // InternalQuery.g:451:2: ( ruleQuestion )
            {
            // InternalQuery.g:451:2: ( ruleQuestion )
            // InternalQuery.g:452:3: ruleQuestion
            {
             before(grammarAccess.getQueryAccess().getQuestionsQuestionParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleQuestion();

            state._fsp--;

             after(grammarAccess.getQueryAccess().getQuestionsQuestionParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Query__QuestionsAssignment_1"


    // $ANTLR start "rule__Question__TitleAssignment_1"
    // InternalQuery.g:461:1: rule__Question__TitleAssignment_1 : ( RULE_STRING ) ;
    public final void rule__Question__TitleAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQuery.g:465:1: ( ( RULE_STRING ) )
            // InternalQuery.g:466:2: ( RULE_STRING )
            {
            // InternalQuery.g:466:2: ( RULE_STRING )
            // InternalQuery.g:467:3: RULE_STRING
            {
             before(grammarAccess.getQuestionAccess().getTitleSTRINGTerminalRuleCall_1_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getQuestionAccess().getTitleSTRINGTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Question__TitleAssignment_1"


    // $ANTLR start "rule__Question__NameAssignment_2"
    // InternalQuery.g:476:1: rule__Question__NameAssignment_2 : ( RULE_ID ) ;
    public final void rule__Question__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQuery.g:480:1: ( ( RULE_ID ) )
            // InternalQuery.g:481:2: ( RULE_ID )
            {
            // InternalQuery.g:481:2: ( RULE_ID )
            // InternalQuery.g:482:3: RULE_ID
            {
             before(grammarAccess.getQuestionAccess().getNameIDTerminalRuleCall_2_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getQuestionAccess().getNameIDTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Question__NameAssignment_2"


    // $ANTLR start "rule__Question__OptionsAssignment_3"
    // InternalQuery.g:491:1: rule__Question__OptionsAssignment_3 : ( ruleOption ) ;
    public final void rule__Question__OptionsAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQuery.g:495:1: ( ( ruleOption ) )
            // InternalQuery.g:496:2: ( ruleOption )
            {
            // InternalQuery.g:496:2: ( ruleOption )
            // InternalQuery.g:497:3: ruleOption
            {
             before(grammarAccess.getQuestionAccess().getOptionsOptionParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleOption();

            state._fsp--;

             after(grammarAccess.getQuestionAccess().getOptionsOptionParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Question__OptionsAssignment_3"


    // $ANTLR start "rule__Option__TitleAssignment_1"
    // InternalQuery.g:506:1: rule__Option__TitleAssignment_1 : ( RULE_STRING ) ;
    public final void rule__Option__TitleAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQuery.g:510:1: ( ( RULE_STRING ) )
            // InternalQuery.g:511:2: ( RULE_STRING )
            {
            // InternalQuery.g:511:2: ( RULE_STRING )
            // InternalQuery.g:512:3: RULE_STRING
            {
             before(grammarAccess.getOptionAccess().getTitleSTRINGTerminalRuleCall_1_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getOptionAccess().getTitleSTRINGTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Option__TitleAssignment_1"


    // $ANTLR start "rule__Option__NameAssignment_2"
    // InternalQuery.g:521:1: rule__Option__NameAssignment_2 : ( RULE_ID ) ;
    public final void rule__Option__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQuery.g:525:1: ( ( RULE_ID ) )
            // InternalQuery.g:526:2: ( RULE_ID )
            {
            // InternalQuery.g:526:2: ( RULE_ID )
            // InternalQuery.g:527:3: RULE_ID
            {
             before(grammarAccess.getOptionAccess().getNameIDTerminalRuleCall_2_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getOptionAccess().getNameIDTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Option__NameAssignment_2"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000001002L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000002002L});

}