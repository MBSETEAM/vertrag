package org.xtext.example.mydsl.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.example.mydsl.services.QueryGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalQueryParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_STRING", "RULE_ID", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'Anfrage:'", "'Kriterium'", "'()'"
    };
    public static final int RULE_ID=5;
    public static final int RULE_WS=9;
    public static final int RULE_STRING=4;
    public static final int RULE_ANY_OTHER=10;
    public static final int RULE_SL_COMMENT=8;
    public static final int RULE_INT=6;
    public static final int T__11=11;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int EOF=-1;

    // delegates
    // delegators


        public InternalQueryParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalQueryParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalQueryParser.tokenNames; }
    public String getGrammarFileName() { return "InternalQuery.g"; }



     	private QueryGrammarAccess grammarAccess;

        public InternalQueryParser(TokenStream input, QueryGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Query";
       	}

       	@Override
       	protected QueryGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleQuery"
    // InternalQuery.g:64:1: entryRuleQuery returns [EObject current=null] : iv_ruleQuery= ruleQuery EOF ;
    public final EObject entryRuleQuery() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleQuery = null;


        try {
            // InternalQuery.g:64:46: (iv_ruleQuery= ruleQuery EOF )
            // InternalQuery.g:65:2: iv_ruleQuery= ruleQuery EOF
            {
             newCompositeNode(grammarAccess.getQueryRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleQuery=ruleQuery();

            state._fsp--;

             current =iv_ruleQuery; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleQuery"


    // $ANTLR start "ruleQuery"
    // InternalQuery.g:71:1: ruleQuery returns [EObject current=null] : ( (otherlv_0= 'Anfrage:' ( (lv_description_1_0= RULE_STRING ) ) )? ( (lv_questions_2_0= ruleQuestion ) )* ) ;
    public final EObject ruleQuery() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_description_1_0=null;
        EObject lv_questions_2_0 = null;



        	enterRule();

        try {
            // InternalQuery.g:77:2: ( ( (otherlv_0= 'Anfrage:' ( (lv_description_1_0= RULE_STRING ) ) )? ( (lv_questions_2_0= ruleQuestion ) )* ) )
            // InternalQuery.g:78:2: ( (otherlv_0= 'Anfrage:' ( (lv_description_1_0= RULE_STRING ) ) )? ( (lv_questions_2_0= ruleQuestion ) )* )
            {
            // InternalQuery.g:78:2: ( (otherlv_0= 'Anfrage:' ( (lv_description_1_0= RULE_STRING ) ) )? ( (lv_questions_2_0= ruleQuestion ) )* )
            // InternalQuery.g:79:3: (otherlv_0= 'Anfrage:' ( (lv_description_1_0= RULE_STRING ) ) )? ( (lv_questions_2_0= ruleQuestion ) )*
            {
            // InternalQuery.g:79:3: (otherlv_0= 'Anfrage:' ( (lv_description_1_0= RULE_STRING ) ) )?
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==11) ) {
                alt1=1;
            }
            switch (alt1) {
                case 1 :
                    // InternalQuery.g:80:4: otherlv_0= 'Anfrage:' ( (lv_description_1_0= RULE_STRING ) )
                    {
                    otherlv_0=(Token)match(input,11,FOLLOW_3); 

                    				newLeafNode(otherlv_0, grammarAccess.getQueryAccess().getAnfrageKeyword_0_0());
                    			
                    // InternalQuery.g:84:4: ( (lv_description_1_0= RULE_STRING ) )
                    // InternalQuery.g:85:5: (lv_description_1_0= RULE_STRING )
                    {
                    // InternalQuery.g:85:5: (lv_description_1_0= RULE_STRING )
                    // InternalQuery.g:86:6: lv_description_1_0= RULE_STRING
                    {
                    lv_description_1_0=(Token)match(input,RULE_STRING,FOLLOW_4); 

                    						newLeafNode(lv_description_1_0, grammarAccess.getQueryAccess().getDescriptionSTRINGTerminalRuleCall_0_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getQueryRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"description",
                    							lv_description_1_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalQuery.g:103:3: ( (lv_questions_2_0= ruleQuestion ) )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==12) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // InternalQuery.g:104:4: (lv_questions_2_0= ruleQuestion )
            	    {
            	    // InternalQuery.g:104:4: (lv_questions_2_0= ruleQuestion )
            	    // InternalQuery.g:105:5: lv_questions_2_0= ruleQuestion
            	    {

            	    					newCompositeNode(grammarAccess.getQueryAccess().getQuestionsQuestionParserRuleCall_1_0());
            	    				
            	    pushFollow(FOLLOW_4);
            	    lv_questions_2_0=ruleQuestion();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getQueryRule());
            	    					}
            	    					add(
            	    						current,
            	    						"questions",
            	    						lv_questions_2_0,
            	    						"org.xtext.example.mydsl.Query.Question");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleQuery"


    // $ANTLR start "entryRuleQuestion"
    // InternalQuery.g:126:1: entryRuleQuestion returns [EObject current=null] : iv_ruleQuestion= ruleQuestion EOF ;
    public final EObject entryRuleQuestion() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleQuestion = null;


        try {
            // InternalQuery.g:126:49: (iv_ruleQuestion= ruleQuestion EOF )
            // InternalQuery.g:127:2: iv_ruleQuestion= ruleQuestion EOF
            {
             newCompositeNode(grammarAccess.getQuestionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleQuestion=ruleQuestion();

            state._fsp--;

             current =iv_ruleQuestion; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleQuestion"


    // $ANTLR start "ruleQuestion"
    // InternalQuery.g:133:1: ruleQuestion returns [EObject current=null] : (otherlv_0= 'Kriterium' ( (lv_title_1_0= RULE_STRING ) ) ( (lv_name_2_0= RULE_ID ) ) ( (lv_options_3_0= ruleOption ) )+ ) ;
    public final EObject ruleQuestion() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_title_1_0=null;
        Token lv_name_2_0=null;
        EObject lv_options_3_0 = null;



        	enterRule();

        try {
            // InternalQuery.g:139:2: ( (otherlv_0= 'Kriterium' ( (lv_title_1_0= RULE_STRING ) ) ( (lv_name_2_0= RULE_ID ) ) ( (lv_options_3_0= ruleOption ) )+ ) )
            // InternalQuery.g:140:2: (otherlv_0= 'Kriterium' ( (lv_title_1_0= RULE_STRING ) ) ( (lv_name_2_0= RULE_ID ) ) ( (lv_options_3_0= ruleOption ) )+ )
            {
            // InternalQuery.g:140:2: (otherlv_0= 'Kriterium' ( (lv_title_1_0= RULE_STRING ) ) ( (lv_name_2_0= RULE_ID ) ) ( (lv_options_3_0= ruleOption ) )+ )
            // InternalQuery.g:141:3: otherlv_0= 'Kriterium' ( (lv_title_1_0= RULE_STRING ) ) ( (lv_name_2_0= RULE_ID ) ) ( (lv_options_3_0= ruleOption ) )+
            {
            otherlv_0=(Token)match(input,12,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getQuestionAccess().getKriteriumKeyword_0());
            		
            // InternalQuery.g:145:3: ( (lv_title_1_0= RULE_STRING ) )
            // InternalQuery.g:146:4: (lv_title_1_0= RULE_STRING )
            {
            // InternalQuery.g:146:4: (lv_title_1_0= RULE_STRING )
            // InternalQuery.g:147:5: lv_title_1_0= RULE_STRING
            {
            lv_title_1_0=(Token)match(input,RULE_STRING,FOLLOW_5); 

            					newLeafNode(lv_title_1_0, grammarAccess.getQuestionAccess().getTitleSTRINGTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getQuestionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"title",
            						lv_title_1_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalQuery.g:163:3: ( (lv_name_2_0= RULE_ID ) )
            // InternalQuery.g:164:4: (lv_name_2_0= RULE_ID )
            {
            // InternalQuery.g:164:4: (lv_name_2_0= RULE_ID )
            // InternalQuery.g:165:5: lv_name_2_0= RULE_ID
            {
            lv_name_2_0=(Token)match(input,RULE_ID,FOLLOW_6); 

            					newLeafNode(lv_name_2_0, grammarAccess.getQuestionAccess().getNameIDTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getQuestionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_2_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalQuery.g:181:3: ( (lv_options_3_0= ruleOption ) )+
            int cnt3=0;
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==13) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // InternalQuery.g:182:4: (lv_options_3_0= ruleOption )
            	    {
            	    // InternalQuery.g:182:4: (lv_options_3_0= ruleOption )
            	    // InternalQuery.g:183:5: lv_options_3_0= ruleOption
            	    {

            	    					newCompositeNode(grammarAccess.getQuestionAccess().getOptionsOptionParserRuleCall_3_0());
            	    				
            	    pushFollow(FOLLOW_7);
            	    lv_options_3_0=ruleOption();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getQuestionRule());
            	    					}
            	    					add(
            	    						current,
            	    						"options",
            	    						lv_options_3_0,
            	    						"org.xtext.example.mydsl.Query.Option");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt3 >= 1 ) break loop3;
                        EarlyExitException eee =
                            new EarlyExitException(3, input);
                        throw eee;
                }
                cnt3++;
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleQuestion"


    // $ANTLR start "entryRuleOption"
    // InternalQuery.g:204:1: entryRuleOption returns [EObject current=null] : iv_ruleOption= ruleOption EOF ;
    public final EObject entryRuleOption() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleOption = null;


        try {
            // InternalQuery.g:204:47: (iv_ruleOption= ruleOption EOF )
            // InternalQuery.g:205:2: iv_ruleOption= ruleOption EOF
            {
             newCompositeNode(grammarAccess.getOptionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleOption=ruleOption();

            state._fsp--;

             current =iv_ruleOption; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleOption"


    // $ANTLR start "ruleOption"
    // InternalQuery.g:211:1: ruleOption returns [EObject current=null] : (otherlv_0= '()' ( (lv_title_1_0= RULE_STRING ) ) ( (lv_name_2_0= RULE_ID ) ) ) ;
    public final EObject ruleOption() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_title_1_0=null;
        Token lv_name_2_0=null;


        	enterRule();

        try {
            // InternalQuery.g:217:2: ( (otherlv_0= '()' ( (lv_title_1_0= RULE_STRING ) ) ( (lv_name_2_0= RULE_ID ) ) ) )
            // InternalQuery.g:218:2: (otherlv_0= '()' ( (lv_title_1_0= RULE_STRING ) ) ( (lv_name_2_0= RULE_ID ) ) )
            {
            // InternalQuery.g:218:2: (otherlv_0= '()' ( (lv_title_1_0= RULE_STRING ) ) ( (lv_name_2_0= RULE_ID ) ) )
            // InternalQuery.g:219:3: otherlv_0= '()' ( (lv_title_1_0= RULE_STRING ) ) ( (lv_name_2_0= RULE_ID ) )
            {
            otherlv_0=(Token)match(input,13,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getOptionAccess().getLeftParenthesisRightParenthesisKeyword_0());
            		
            // InternalQuery.g:223:3: ( (lv_title_1_0= RULE_STRING ) )
            // InternalQuery.g:224:4: (lv_title_1_0= RULE_STRING )
            {
            // InternalQuery.g:224:4: (lv_title_1_0= RULE_STRING )
            // InternalQuery.g:225:5: lv_title_1_0= RULE_STRING
            {
            lv_title_1_0=(Token)match(input,RULE_STRING,FOLLOW_5); 

            					newLeafNode(lv_title_1_0, grammarAccess.getOptionAccess().getTitleSTRINGTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getOptionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"title",
            						lv_title_1_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalQuery.g:241:3: ( (lv_name_2_0= RULE_ID ) )
            // InternalQuery.g:242:4: (lv_name_2_0= RULE_ID )
            {
            // InternalQuery.g:242:4: (lv_name_2_0= RULE_ID )
            // InternalQuery.g:243:5: lv_name_2_0= RULE_ID
            {
            lv_name_2_0=(Token)match(input,RULE_ID,FOLLOW_2); 

            					newLeafNode(lv_name_2_0, grammarAccess.getOptionAccess().getNameIDTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getOptionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_2_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleOption"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000001002L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000002002L});

}