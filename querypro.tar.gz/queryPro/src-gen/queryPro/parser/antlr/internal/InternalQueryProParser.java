package queryPro.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import queryPro.services.QueryProGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalQueryProParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_INT", "RULE_PRICE", "RULE_ID", "RULE_STRING", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'SUCHE'", "'TELEFONIERE'", "'SMS'", "'INTERNET'", "'datenvolumen'", "'MBits'", "'NETZ'", "'LAUFZEIT'", "'HANDY'", "'Marke'", "'Betriebssystem'", "'Speicher'", "'O2'", "'TELEKOM'", "'VODAFON'", "'egal'", "'ANDROID'", "'IOS'", "'wenig'", "'viel'", "'flat'", "'normal'", "'gut'", "'kurz'", "'flexibel'", "'SAMSUNG'", "'IPHONE'", "'NOKIA'"
    };
    public static final int RULE_STRING=7;
    public static final int RULE_SL_COMMENT=9;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__37=37;
    public static final int T__16=16;
    public static final int T__38=38;
    public static final int T__17=17;
    public static final int T__39=39;
    public static final int T__18=18;
    public static final int T__33=33;
    public static final int T__12=12;
    public static final int T__34=34;
    public static final int T__13=13;
    public static final int T__35=35;
    public static final int T__14=14;
    public static final int T__36=36;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_ID=6;
    public static final int RULE_WS=10;
    public static final int RULE_ANY_OTHER=11;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=4;
    public static final int RULE_PRICE=5;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=8;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalQueryProParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalQueryProParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalQueryProParser.tokenNames; }
    public String getGrammarFileName() { return "InternalQueryPro.g"; }



     	private QueryProGrammarAccess grammarAccess;

        public InternalQueryProParser(TokenStream input, QueryProGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Query";
       	}

       	@Override
       	protected QueryProGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleQuery"
    // InternalQueryPro.g:65:1: entryRuleQuery returns [EObject current=null] : iv_ruleQuery= ruleQuery EOF ;
    public final EObject entryRuleQuery() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleQuery = null;


        try {
            // InternalQueryPro.g:65:46: (iv_ruleQuery= ruleQuery EOF )
            // InternalQueryPro.g:66:2: iv_ruleQuery= ruleQuery EOF
            {
             newCompositeNode(grammarAccess.getQueryRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleQuery=ruleQuery();

            state._fsp--;

             current =iv_ruleQuery; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleQuery"


    // $ANTLR start "ruleQuery"
    // InternalQueryPro.g:72:1: ruleQuery returns [EObject current=null] : (otherlv_0= 'SUCHE' ( (lv_amount_1_0= RULE_INT ) ) ( (lv_krits_2_0= ruleKriteria ) )* ) ;
    public final EObject ruleQuery() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_amount_1_0=null;
        EObject lv_krits_2_0 = null;



        	enterRule();

        try {
            // InternalQueryPro.g:78:2: ( (otherlv_0= 'SUCHE' ( (lv_amount_1_0= RULE_INT ) ) ( (lv_krits_2_0= ruleKriteria ) )* ) )
            // InternalQueryPro.g:79:2: (otherlv_0= 'SUCHE' ( (lv_amount_1_0= RULE_INT ) ) ( (lv_krits_2_0= ruleKriteria ) )* )
            {
            // InternalQueryPro.g:79:2: (otherlv_0= 'SUCHE' ( (lv_amount_1_0= RULE_INT ) ) ( (lv_krits_2_0= ruleKriteria ) )* )
            // InternalQueryPro.g:80:3: otherlv_0= 'SUCHE' ( (lv_amount_1_0= RULE_INT ) ) ( (lv_krits_2_0= ruleKriteria ) )*
            {
            otherlv_0=(Token)match(input,12,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getQueryAccess().getSUCHEKeyword_0());
            		
            // InternalQueryPro.g:84:3: ( (lv_amount_1_0= RULE_INT ) )
            // InternalQueryPro.g:85:4: (lv_amount_1_0= RULE_INT )
            {
            // InternalQueryPro.g:85:4: (lv_amount_1_0= RULE_INT )
            // InternalQueryPro.g:86:5: lv_amount_1_0= RULE_INT
            {
            lv_amount_1_0=(Token)match(input,RULE_INT,FOLLOW_4); 

            					newLeafNode(lv_amount_1_0, grammarAccess.getQueryAccess().getAmountINTTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getQueryRule());
            					}
            					setWithLastConsumed(
            						current,
            						"amount",
            						lv_amount_1_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            // InternalQueryPro.g:102:3: ( (lv_krits_2_0= ruleKriteria ) )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( ((LA1_0>=13 && LA1_0<=15)||(LA1_0>=18 && LA1_0<=20)) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalQueryPro.g:103:4: (lv_krits_2_0= ruleKriteria )
            	    {
            	    // InternalQueryPro.g:103:4: (lv_krits_2_0= ruleKriteria )
            	    // InternalQueryPro.g:104:5: lv_krits_2_0= ruleKriteria
            	    {

            	    					newCompositeNode(grammarAccess.getQueryAccess().getKritsKriteriaParserRuleCall_2_0());
            	    				
            	    pushFollow(FOLLOW_4);
            	    lv_krits_2_0=ruleKriteria();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getQueryRule());
            	    					}
            	    					add(
            	    						current,
            	    						"krits",
            	    						lv_krits_2_0,
            	    						"queryPro.QueryPro.Kriteria");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleQuery"


    // $ANTLR start "entryRuleKriteria"
    // InternalQueryPro.g:125:1: entryRuleKriteria returns [EObject current=null] : iv_ruleKriteria= ruleKriteria EOF ;
    public final EObject entryRuleKriteria() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleKriteria = null;


        try {
            // InternalQueryPro.g:125:49: (iv_ruleKriteria= ruleKriteria EOF )
            // InternalQueryPro.g:126:2: iv_ruleKriteria= ruleKriteria EOF
            {
             newCompositeNode(grammarAccess.getKriteriaRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleKriteria=ruleKriteria();

            state._fsp--;

             current =iv_ruleKriteria; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleKriteria"


    // $ANTLR start "ruleKriteria"
    // InternalQueryPro.g:132:1: ruleKriteria returns [EObject current=null] : ( ( (lv_type_0_1= ruleTelephone | lv_type_0_2= ruleSMS | lv_type_0_3= ruleInternet | lv_type_0_4= ruleNet | lv_type_0_5= ruleFlexibilty | lv_type_0_6= rulePhone ) ) ) ;
    public final EObject ruleKriteria() throws RecognitionException {
        EObject current = null;

        EObject lv_type_0_1 = null;

        EObject lv_type_0_2 = null;

        EObject lv_type_0_3 = null;

        EObject lv_type_0_4 = null;

        EObject lv_type_0_5 = null;

        EObject lv_type_0_6 = null;



        	enterRule();

        try {
            // InternalQueryPro.g:138:2: ( ( ( (lv_type_0_1= ruleTelephone | lv_type_0_2= ruleSMS | lv_type_0_3= ruleInternet | lv_type_0_4= ruleNet | lv_type_0_5= ruleFlexibilty | lv_type_0_6= rulePhone ) ) ) )
            // InternalQueryPro.g:139:2: ( ( (lv_type_0_1= ruleTelephone | lv_type_0_2= ruleSMS | lv_type_0_3= ruleInternet | lv_type_0_4= ruleNet | lv_type_0_5= ruleFlexibilty | lv_type_0_6= rulePhone ) ) )
            {
            // InternalQueryPro.g:139:2: ( ( (lv_type_0_1= ruleTelephone | lv_type_0_2= ruleSMS | lv_type_0_3= ruleInternet | lv_type_0_4= ruleNet | lv_type_0_5= ruleFlexibilty | lv_type_0_6= rulePhone ) ) )
            // InternalQueryPro.g:140:3: ( (lv_type_0_1= ruleTelephone | lv_type_0_2= ruleSMS | lv_type_0_3= ruleInternet | lv_type_0_4= ruleNet | lv_type_0_5= ruleFlexibilty | lv_type_0_6= rulePhone ) )
            {
            // InternalQueryPro.g:140:3: ( (lv_type_0_1= ruleTelephone | lv_type_0_2= ruleSMS | lv_type_0_3= ruleInternet | lv_type_0_4= ruleNet | lv_type_0_5= ruleFlexibilty | lv_type_0_6= rulePhone ) )
            // InternalQueryPro.g:141:4: (lv_type_0_1= ruleTelephone | lv_type_0_2= ruleSMS | lv_type_0_3= ruleInternet | lv_type_0_4= ruleNet | lv_type_0_5= ruleFlexibilty | lv_type_0_6= rulePhone )
            {
            // InternalQueryPro.g:141:4: (lv_type_0_1= ruleTelephone | lv_type_0_2= ruleSMS | lv_type_0_3= ruleInternet | lv_type_0_4= ruleNet | lv_type_0_5= ruleFlexibilty | lv_type_0_6= rulePhone )
            int alt2=6;
            switch ( input.LA(1) ) {
            case 13:
                {
                alt2=1;
                }
                break;
            case 14:
                {
                alt2=2;
                }
                break;
            case 15:
                {
                alt2=3;
                }
                break;
            case 18:
                {
                alt2=4;
                }
                break;
            case 19:
                {
                alt2=5;
                }
                break;
            case 20:
                {
                alt2=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }

            switch (alt2) {
                case 1 :
                    // InternalQueryPro.g:142:5: lv_type_0_1= ruleTelephone
                    {

                    					newCompositeNode(grammarAccess.getKriteriaAccess().getTypeTelephoneParserRuleCall_0_0());
                    				
                    pushFollow(FOLLOW_2);
                    lv_type_0_1=ruleTelephone();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getKriteriaRule());
                    					}
                    					set(
                    						current,
                    						"type",
                    						lv_type_0_1,
                    						"queryPro.QueryPro.Telephone");
                    					afterParserOrEnumRuleCall();
                    				

                    }
                    break;
                case 2 :
                    // InternalQueryPro.g:158:5: lv_type_0_2= ruleSMS
                    {

                    					newCompositeNode(grammarAccess.getKriteriaAccess().getTypeSMSParserRuleCall_0_1());
                    				
                    pushFollow(FOLLOW_2);
                    lv_type_0_2=ruleSMS();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getKriteriaRule());
                    					}
                    					set(
                    						current,
                    						"type",
                    						lv_type_0_2,
                    						"queryPro.QueryPro.SMS");
                    					afterParserOrEnumRuleCall();
                    				

                    }
                    break;
                case 3 :
                    // InternalQueryPro.g:174:5: lv_type_0_3= ruleInternet
                    {

                    					newCompositeNode(grammarAccess.getKriteriaAccess().getTypeInternetParserRuleCall_0_2());
                    				
                    pushFollow(FOLLOW_2);
                    lv_type_0_3=ruleInternet();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getKriteriaRule());
                    					}
                    					set(
                    						current,
                    						"type",
                    						lv_type_0_3,
                    						"queryPro.QueryPro.Internet");
                    					afterParserOrEnumRuleCall();
                    				

                    }
                    break;
                case 4 :
                    // InternalQueryPro.g:190:5: lv_type_0_4= ruleNet
                    {

                    					newCompositeNode(grammarAccess.getKriteriaAccess().getTypeNetParserRuleCall_0_3());
                    				
                    pushFollow(FOLLOW_2);
                    lv_type_0_4=ruleNet();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getKriteriaRule());
                    					}
                    					set(
                    						current,
                    						"type",
                    						lv_type_0_4,
                    						"queryPro.QueryPro.Net");
                    					afterParserOrEnumRuleCall();
                    				

                    }
                    break;
                case 5 :
                    // InternalQueryPro.g:206:5: lv_type_0_5= ruleFlexibilty
                    {

                    					newCompositeNode(grammarAccess.getKriteriaAccess().getTypeFlexibiltyParserRuleCall_0_4());
                    				
                    pushFollow(FOLLOW_2);
                    lv_type_0_5=ruleFlexibilty();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getKriteriaRule());
                    					}
                    					set(
                    						current,
                    						"type",
                    						lv_type_0_5,
                    						"queryPro.QueryPro.Flexibilty");
                    					afterParserOrEnumRuleCall();
                    				

                    }
                    break;
                case 6 :
                    // InternalQueryPro.g:222:5: lv_type_0_6= rulePhone
                    {

                    					newCompositeNode(grammarAccess.getKriteriaAccess().getTypePhoneParserRuleCall_0_5());
                    				
                    pushFollow(FOLLOW_2);
                    lv_type_0_6=rulePhone();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getKriteriaRule());
                    					}
                    					set(
                    						current,
                    						"type",
                    						lv_type_0_6,
                    						"queryPro.QueryPro.Phone");
                    					afterParserOrEnumRuleCall();
                    				

                    }
                    break;

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleKriteria"


    // $ANTLR start "entryRuleTelephone"
    // InternalQueryPro.g:243:1: entryRuleTelephone returns [EObject current=null] : iv_ruleTelephone= ruleTelephone EOF ;
    public final EObject entryRuleTelephone() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTelephone = null;


        try {
            // InternalQueryPro.g:243:50: (iv_ruleTelephone= ruleTelephone EOF )
            // InternalQueryPro.g:244:2: iv_ruleTelephone= ruleTelephone EOF
            {
             newCompositeNode(grammarAccess.getTelephoneRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTelephone=ruleTelephone();

            state._fsp--;

             current =iv_ruleTelephone; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTelephone"


    // $ANTLR start "ruleTelephone"
    // InternalQueryPro.g:250:1: ruleTelephone returns [EObject current=null] : (otherlv_0= 'TELEFONIERE' ( ( (lv_value_1_0= ruleIntensitaet_Flat ) ) | ( (lv_freeminutes_2_0= RULE_INT ) ) ) ) ;
    public final EObject ruleTelephone() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_freeminutes_2_0=null;
        Enumerator lv_value_1_0 = null;



        	enterRule();

        try {
            // InternalQueryPro.g:256:2: ( (otherlv_0= 'TELEFONIERE' ( ( (lv_value_1_0= ruleIntensitaet_Flat ) ) | ( (lv_freeminutes_2_0= RULE_INT ) ) ) ) )
            // InternalQueryPro.g:257:2: (otherlv_0= 'TELEFONIERE' ( ( (lv_value_1_0= ruleIntensitaet_Flat ) ) | ( (lv_freeminutes_2_0= RULE_INT ) ) ) )
            {
            // InternalQueryPro.g:257:2: (otherlv_0= 'TELEFONIERE' ( ( (lv_value_1_0= ruleIntensitaet_Flat ) ) | ( (lv_freeminutes_2_0= RULE_INT ) ) ) )
            // InternalQueryPro.g:258:3: otherlv_0= 'TELEFONIERE' ( ( (lv_value_1_0= ruleIntensitaet_Flat ) ) | ( (lv_freeminutes_2_0= RULE_INT ) ) )
            {
            otherlv_0=(Token)match(input,13,FOLLOW_5); 

            			newLeafNode(otherlv_0, grammarAccess.getTelephoneAccess().getTELEFONIEREKeyword_0());
            		
            // InternalQueryPro.g:262:3: ( ( (lv_value_1_0= ruleIntensitaet_Flat ) ) | ( (lv_freeminutes_2_0= RULE_INT ) ) )
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==27||(LA3_0>=30 && LA3_0<=32)) ) {
                alt3=1;
            }
            else if ( (LA3_0==RULE_INT) ) {
                alt3=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }
            switch (alt3) {
                case 1 :
                    // InternalQueryPro.g:263:4: ( (lv_value_1_0= ruleIntensitaet_Flat ) )
                    {
                    // InternalQueryPro.g:263:4: ( (lv_value_1_0= ruleIntensitaet_Flat ) )
                    // InternalQueryPro.g:264:5: (lv_value_1_0= ruleIntensitaet_Flat )
                    {
                    // InternalQueryPro.g:264:5: (lv_value_1_0= ruleIntensitaet_Flat )
                    // InternalQueryPro.g:265:6: lv_value_1_0= ruleIntensitaet_Flat
                    {

                    						newCompositeNode(grammarAccess.getTelephoneAccess().getValueIntensitaet_FlatEnumRuleCall_1_0_0());
                    					
                    pushFollow(FOLLOW_2);
                    lv_value_1_0=ruleIntensitaet_Flat();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getTelephoneRule());
                    						}
                    						set(
                    							current,
                    							"value",
                    							lv_value_1_0,
                    							"queryPro.QueryPro.Intensitaet_Flat");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalQueryPro.g:283:4: ( (lv_freeminutes_2_0= RULE_INT ) )
                    {
                    // InternalQueryPro.g:283:4: ( (lv_freeminutes_2_0= RULE_INT ) )
                    // InternalQueryPro.g:284:5: (lv_freeminutes_2_0= RULE_INT )
                    {
                    // InternalQueryPro.g:284:5: (lv_freeminutes_2_0= RULE_INT )
                    // InternalQueryPro.g:285:6: lv_freeminutes_2_0= RULE_INT
                    {
                    lv_freeminutes_2_0=(Token)match(input,RULE_INT,FOLLOW_2); 

                    						newLeafNode(lv_freeminutes_2_0, grammarAccess.getTelephoneAccess().getFreeminutesINTTerminalRuleCall_1_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getTelephoneRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"freeminutes",
                    							lv_freeminutes_2_0,
                    							"org.eclipse.xtext.common.Terminals.INT");
                    					

                    }


                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTelephone"


    // $ANTLR start "entryRuleSMS"
    // InternalQueryPro.g:306:1: entryRuleSMS returns [EObject current=null] : iv_ruleSMS= ruleSMS EOF ;
    public final EObject entryRuleSMS() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSMS = null;


        try {
            // InternalQueryPro.g:306:44: (iv_ruleSMS= ruleSMS EOF )
            // InternalQueryPro.g:307:2: iv_ruleSMS= ruleSMS EOF
            {
             newCompositeNode(grammarAccess.getSMSRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSMS=ruleSMS();

            state._fsp--;

             current =iv_ruleSMS; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSMS"


    // $ANTLR start "ruleSMS"
    // InternalQueryPro.g:313:1: ruleSMS returns [EObject current=null] : (otherlv_0= 'SMS' ( ( (lv_value_1_0= ruleIntensitaet_Flat ) ) | ( (lv_cost_2_0= RULE_PRICE ) ) ) ) ;
    public final EObject ruleSMS() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_cost_2_0=null;
        Enumerator lv_value_1_0 = null;



        	enterRule();

        try {
            // InternalQueryPro.g:319:2: ( (otherlv_0= 'SMS' ( ( (lv_value_1_0= ruleIntensitaet_Flat ) ) | ( (lv_cost_2_0= RULE_PRICE ) ) ) ) )
            // InternalQueryPro.g:320:2: (otherlv_0= 'SMS' ( ( (lv_value_1_0= ruleIntensitaet_Flat ) ) | ( (lv_cost_2_0= RULE_PRICE ) ) ) )
            {
            // InternalQueryPro.g:320:2: (otherlv_0= 'SMS' ( ( (lv_value_1_0= ruleIntensitaet_Flat ) ) | ( (lv_cost_2_0= RULE_PRICE ) ) ) )
            // InternalQueryPro.g:321:3: otherlv_0= 'SMS' ( ( (lv_value_1_0= ruleIntensitaet_Flat ) ) | ( (lv_cost_2_0= RULE_PRICE ) ) )
            {
            otherlv_0=(Token)match(input,14,FOLLOW_6); 

            			newLeafNode(otherlv_0, grammarAccess.getSMSAccess().getSMSKeyword_0());
            		
            // InternalQueryPro.g:325:3: ( ( (lv_value_1_0= ruleIntensitaet_Flat ) ) | ( (lv_cost_2_0= RULE_PRICE ) ) )
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==27||(LA4_0>=30 && LA4_0<=32)) ) {
                alt4=1;
            }
            else if ( (LA4_0==RULE_PRICE) ) {
                alt4=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }
            switch (alt4) {
                case 1 :
                    // InternalQueryPro.g:326:4: ( (lv_value_1_0= ruleIntensitaet_Flat ) )
                    {
                    // InternalQueryPro.g:326:4: ( (lv_value_1_0= ruleIntensitaet_Flat ) )
                    // InternalQueryPro.g:327:5: (lv_value_1_0= ruleIntensitaet_Flat )
                    {
                    // InternalQueryPro.g:327:5: (lv_value_1_0= ruleIntensitaet_Flat )
                    // InternalQueryPro.g:328:6: lv_value_1_0= ruleIntensitaet_Flat
                    {

                    						newCompositeNode(grammarAccess.getSMSAccess().getValueIntensitaet_FlatEnumRuleCall_1_0_0());
                    					
                    pushFollow(FOLLOW_2);
                    lv_value_1_0=ruleIntensitaet_Flat();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getSMSRule());
                    						}
                    						set(
                    							current,
                    							"value",
                    							lv_value_1_0,
                    							"queryPro.QueryPro.Intensitaet_Flat");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalQueryPro.g:346:4: ( (lv_cost_2_0= RULE_PRICE ) )
                    {
                    // InternalQueryPro.g:346:4: ( (lv_cost_2_0= RULE_PRICE ) )
                    // InternalQueryPro.g:347:5: (lv_cost_2_0= RULE_PRICE )
                    {
                    // InternalQueryPro.g:347:5: (lv_cost_2_0= RULE_PRICE )
                    // InternalQueryPro.g:348:6: lv_cost_2_0= RULE_PRICE
                    {
                    lv_cost_2_0=(Token)match(input,RULE_PRICE,FOLLOW_2); 

                    						newLeafNode(lv_cost_2_0, grammarAccess.getSMSAccess().getCostPRICETerminalRuleCall_1_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getSMSRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"cost",
                    							lv_cost_2_0,
                    							"queryPro.QueryPro.PRICE");
                    					

                    }


                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSMS"


    // $ANTLR start "entryRuleInternet"
    // InternalQueryPro.g:369:1: entryRuleInternet returns [EObject current=null] : iv_ruleInternet= ruleInternet EOF ;
    public final EObject entryRuleInternet() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInternet = null;


        try {
            // InternalQueryPro.g:369:49: (iv_ruleInternet= ruleInternet EOF )
            // InternalQueryPro.g:370:2: iv_ruleInternet= ruleInternet EOF
            {
             newCompositeNode(grammarAccess.getInternetRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInternet=ruleInternet();

            state._fsp--;

             current =iv_ruleInternet; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInternet"


    // $ANTLR start "ruleInternet"
    // InternalQueryPro.g:376:1: ruleInternet returns [EObject current=null] : (otherlv_0= 'INTERNET' ( ( (lv_value_1_0= ruleIntensitaet ) ) | ( ( ( (lv_volume_2_0= RULE_INT ) ) otherlv_3= 'datenvolumen' ) | ( ( (lv_speed_4_0= RULE_INT ) ) otherlv_5= 'MBits' ) )* ) ) ;
    public final EObject ruleInternet() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_volume_2_0=null;
        Token otherlv_3=null;
        Token lv_speed_4_0=null;
        Token otherlv_5=null;
        Enumerator lv_value_1_0 = null;



        	enterRule();

        try {
            // InternalQueryPro.g:382:2: ( (otherlv_0= 'INTERNET' ( ( (lv_value_1_0= ruleIntensitaet ) ) | ( ( ( (lv_volume_2_0= RULE_INT ) ) otherlv_3= 'datenvolumen' ) | ( ( (lv_speed_4_0= RULE_INT ) ) otherlv_5= 'MBits' ) )* ) ) )
            // InternalQueryPro.g:383:2: (otherlv_0= 'INTERNET' ( ( (lv_value_1_0= ruleIntensitaet ) ) | ( ( ( (lv_volume_2_0= RULE_INT ) ) otherlv_3= 'datenvolumen' ) | ( ( (lv_speed_4_0= RULE_INT ) ) otherlv_5= 'MBits' ) )* ) )
            {
            // InternalQueryPro.g:383:2: (otherlv_0= 'INTERNET' ( ( (lv_value_1_0= ruleIntensitaet ) ) | ( ( ( (lv_volume_2_0= RULE_INT ) ) otherlv_3= 'datenvolumen' ) | ( ( (lv_speed_4_0= RULE_INT ) ) otherlv_5= 'MBits' ) )* ) )
            // InternalQueryPro.g:384:3: otherlv_0= 'INTERNET' ( ( (lv_value_1_0= ruleIntensitaet ) ) | ( ( ( (lv_volume_2_0= RULE_INT ) ) otherlv_3= 'datenvolumen' ) | ( ( (lv_speed_4_0= RULE_INT ) ) otherlv_5= 'MBits' ) )* )
            {
            otherlv_0=(Token)match(input,15,FOLLOW_7); 

            			newLeafNode(otherlv_0, grammarAccess.getInternetAccess().getINTERNETKeyword_0());
            		
            // InternalQueryPro.g:388:3: ( ( (lv_value_1_0= ruleIntensitaet ) ) | ( ( ( (lv_volume_2_0= RULE_INT ) ) otherlv_3= 'datenvolumen' ) | ( ( (lv_speed_4_0= RULE_INT ) ) otherlv_5= 'MBits' ) )* )
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==27||(LA6_0>=30 && LA6_0<=31)) ) {
                alt6=1;
            }
            else if ( (LA6_0==EOF||LA6_0==RULE_INT||(LA6_0>=13 && LA6_0<=15)||(LA6_0>=18 && LA6_0<=20)) ) {
                alt6=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }
            switch (alt6) {
                case 1 :
                    // InternalQueryPro.g:389:4: ( (lv_value_1_0= ruleIntensitaet ) )
                    {
                    // InternalQueryPro.g:389:4: ( (lv_value_1_0= ruleIntensitaet ) )
                    // InternalQueryPro.g:390:5: (lv_value_1_0= ruleIntensitaet )
                    {
                    // InternalQueryPro.g:390:5: (lv_value_1_0= ruleIntensitaet )
                    // InternalQueryPro.g:391:6: lv_value_1_0= ruleIntensitaet
                    {

                    						newCompositeNode(grammarAccess.getInternetAccess().getValueIntensitaetEnumRuleCall_1_0_0());
                    					
                    pushFollow(FOLLOW_2);
                    lv_value_1_0=ruleIntensitaet();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getInternetRule());
                    						}
                    						set(
                    							current,
                    							"value",
                    							lv_value_1_0,
                    							"queryPro.QueryPro.Intensitaet");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalQueryPro.g:409:4: ( ( ( (lv_volume_2_0= RULE_INT ) ) otherlv_3= 'datenvolumen' ) | ( ( (lv_speed_4_0= RULE_INT ) ) otherlv_5= 'MBits' ) )*
                    {
                    // InternalQueryPro.g:409:4: ( ( ( (lv_volume_2_0= RULE_INT ) ) otherlv_3= 'datenvolumen' ) | ( ( (lv_speed_4_0= RULE_INT ) ) otherlv_5= 'MBits' ) )*
                    loop5:
                    do {
                        int alt5=3;
                        int LA5_0 = input.LA(1);

                        if ( (LA5_0==RULE_INT) ) {
                            int LA5_2 = input.LA(2);

                            if ( (LA5_2==17) ) {
                                alt5=2;
                            }
                            else if ( (LA5_2==16) ) {
                                alt5=1;
                            }


                        }


                        switch (alt5) {
                    	case 1 :
                    	    // InternalQueryPro.g:410:5: ( ( (lv_volume_2_0= RULE_INT ) ) otherlv_3= 'datenvolumen' )
                    	    {
                    	    // InternalQueryPro.g:410:5: ( ( (lv_volume_2_0= RULE_INT ) ) otherlv_3= 'datenvolumen' )
                    	    // InternalQueryPro.g:411:6: ( (lv_volume_2_0= RULE_INT ) ) otherlv_3= 'datenvolumen'
                    	    {
                    	    // InternalQueryPro.g:411:6: ( (lv_volume_2_0= RULE_INT ) )
                    	    // InternalQueryPro.g:412:7: (lv_volume_2_0= RULE_INT )
                    	    {
                    	    // InternalQueryPro.g:412:7: (lv_volume_2_0= RULE_INT )
                    	    // InternalQueryPro.g:413:8: lv_volume_2_0= RULE_INT
                    	    {
                    	    lv_volume_2_0=(Token)match(input,RULE_INT,FOLLOW_8); 

                    	    								newLeafNode(lv_volume_2_0, grammarAccess.getInternetAccess().getVolumeINTTerminalRuleCall_1_1_0_0_0());
                    	    							

                    	    								if (current==null) {
                    	    									current = createModelElement(grammarAccess.getInternetRule());
                    	    								}
                    	    								setWithLastConsumed(
                    	    									current,
                    	    									"volume",
                    	    									lv_volume_2_0,
                    	    									"org.eclipse.xtext.common.Terminals.INT");
                    	    							

                    	    }


                    	    }

                    	    otherlv_3=(Token)match(input,16,FOLLOW_9); 

                    	    						newLeafNode(otherlv_3, grammarAccess.getInternetAccess().getDatenvolumenKeyword_1_1_0_1());
                    	    					

                    	    }


                    	    }
                    	    break;
                    	case 2 :
                    	    // InternalQueryPro.g:435:5: ( ( (lv_speed_4_0= RULE_INT ) ) otherlv_5= 'MBits' )
                    	    {
                    	    // InternalQueryPro.g:435:5: ( ( (lv_speed_4_0= RULE_INT ) ) otherlv_5= 'MBits' )
                    	    // InternalQueryPro.g:436:6: ( (lv_speed_4_0= RULE_INT ) ) otherlv_5= 'MBits'
                    	    {
                    	    // InternalQueryPro.g:436:6: ( (lv_speed_4_0= RULE_INT ) )
                    	    // InternalQueryPro.g:437:7: (lv_speed_4_0= RULE_INT )
                    	    {
                    	    // InternalQueryPro.g:437:7: (lv_speed_4_0= RULE_INT )
                    	    // InternalQueryPro.g:438:8: lv_speed_4_0= RULE_INT
                    	    {
                    	    lv_speed_4_0=(Token)match(input,RULE_INT,FOLLOW_10); 

                    	    								newLeafNode(lv_speed_4_0, grammarAccess.getInternetAccess().getSpeedINTTerminalRuleCall_1_1_1_0_0());
                    	    							

                    	    								if (current==null) {
                    	    									current = createModelElement(grammarAccess.getInternetRule());
                    	    								}
                    	    								setWithLastConsumed(
                    	    									current,
                    	    									"speed",
                    	    									lv_speed_4_0,
                    	    									"org.eclipse.xtext.common.Terminals.INT");
                    	    							

                    	    }


                    	    }

                    	    otherlv_5=(Token)match(input,17,FOLLOW_9); 

                    	    						newLeafNode(otherlv_5, grammarAccess.getInternetAccess().getMBitsKeyword_1_1_1_1());
                    	    					

                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop5;
                        }
                    } while (true);


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInternet"


    // $ANTLR start "entryRuleNet"
    // InternalQueryPro.g:465:1: entryRuleNet returns [EObject current=null] : iv_ruleNet= ruleNet EOF ;
    public final EObject entryRuleNet() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleNet = null;


        try {
            // InternalQueryPro.g:465:44: (iv_ruleNet= ruleNet EOF )
            // InternalQueryPro.g:466:2: iv_ruleNet= ruleNet EOF
            {
             newCompositeNode(grammarAccess.getNetRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleNet=ruleNet();

            state._fsp--;

             current =iv_ruleNet; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleNet"


    // $ANTLR start "ruleNet"
    // InternalQueryPro.g:472:1: ruleNet returns [EObject current=null] : (otherlv_0= 'NETZ' ( ( (lv_value_1_0= ruleNetzverbreitung ) ) | ( (lv_net_2_0= ruleNetzanbieter ) ) ) ) ;
    public final EObject ruleNet() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Enumerator lv_value_1_0 = null;

        Enumerator lv_net_2_0 = null;



        	enterRule();

        try {
            // InternalQueryPro.g:478:2: ( (otherlv_0= 'NETZ' ( ( (lv_value_1_0= ruleNetzverbreitung ) ) | ( (lv_net_2_0= ruleNetzanbieter ) ) ) ) )
            // InternalQueryPro.g:479:2: (otherlv_0= 'NETZ' ( ( (lv_value_1_0= ruleNetzverbreitung ) ) | ( (lv_net_2_0= ruleNetzanbieter ) ) ) )
            {
            // InternalQueryPro.g:479:2: (otherlv_0= 'NETZ' ( ( (lv_value_1_0= ruleNetzverbreitung ) ) | ( (lv_net_2_0= ruleNetzanbieter ) ) ) )
            // InternalQueryPro.g:480:3: otherlv_0= 'NETZ' ( ( (lv_value_1_0= ruleNetzverbreitung ) ) | ( (lv_net_2_0= ruleNetzanbieter ) ) )
            {
            otherlv_0=(Token)match(input,18,FOLLOW_11); 

            			newLeafNode(otherlv_0, grammarAccess.getNetAccess().getNETZKeyword_0());
            		
            // InternalQueryPro.g:484:3: ( ( (lv_value_1_0= ruleNetzverbreitung ) ) | ( (lv_net_2_0= ruleNetzanbieter ) ) )
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==27||(LA7_0>=33 && LA7_0<=34)) ) {
                alt7=1;
            }
            else if ( ((LA7_0>=24 && LA7_0<=26)) ) {
                alt7=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 7, 0, input);

                throw nvae;
            }
            switch (alt7) {
                case 1 :
                    // InternalQueryPro.g:485:4: ( (lv_value_1_0= ruleNetzverbreitung ) )
                    {
                    // InternalQueryPro.g:485:4: ( (lv_value_1_0= ruleNetzverbreitung ) )
                    // InternalQueryPro.g:486:5: (lv_value_1_0= ruleNetzverbreitung )
                    {
                    // InternalQueryPro.g:486:5: (lv_value_1_0= ruleNetzverbreitung )
                    // InternalQueryPro.g:487:6: lv_value_1_0= ruleNetzverbreitung
                    {

                    						newCompositeNode(grammarAccess.getNetAccess().getValueNetzverbreitungEnumRuleCall_1_0_0());
                    					
                    pushFollow(FOLLOW_2);
                    lv_value_1_0=ruleNetzverbreitung();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getNetRule());
                    						}
                    						set(
                    							current,
                    							"value",
                    							lv_value_1_0,
                    							"queryPro.QueryPro.Netzverbreitung");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalQueryPro.g:505:4: ( (lv_net_2_0= ruleNetzanbieter ) )
                    {
                    // InternalQueryPro.g:505:4: ( (lv_net_2_0= ruleNetzanbieter ) )
                    // InternalQueryPro.g:506:5: (lv_net_2_0= ruleNetzanbieter )
                    {
                    // InternalQueryPro.g:506:5: (lv_net_2_0= ruleNetzanbieter )
                    // InternalQueryPro.g:507:6: lv_net_2_0= ruleNetzanbieter
                    {

                    						newCompositeNode(grammarAccess.getNetAccess().getNetNetzanbieterEnumRuleCall_1_1_0());
                    					
                    pushFollow(FOLLOW_2);
                    lv_net_2_0=ruleNetzanbieter();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getNetRule());
                    						}
                    						set(
                    							current,
                    							"net",
                    							lv_net_2_0,
                    							"queryPro.QueryPro.Netzanbieter");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleNet"


    // $ANTLR start "entryRuleFlexibilty"
    // InternalQueryPro.g:529:1: entryRuleFlexibilty returns [EObject current=null] : iv_ruleFlexibilty= ruleFlexibilty EOF ;
    public final EObject entryRuleFlexibilty() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFlexibilty = null;


        try {
            // InternalQueryPro.g:529:51: (iv_ruleFlexibilty= ruleFlexibilty EOF )
            // InternalQueryPro.g:530:2: iv_ruleFlexibilty= ruleFlexibilty EOF
            {
             newCompositeNode(grammarAccess.getFlexibiltyRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleFlexibilty=ruleFlexibilty();

            state._fsp--;

             current =iv_ruleFlexibilty; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFlexibilty"


    // $ANTLR start "ruleFlexibilty"
    // InternalQueryPro.g:536:1: ruleFlexibilty returns [EObject current=null] : (otherlv_0= 'LAUFZEIT' ( ( (lv_value_1_0= ruleVertragskondition ) ) | ( (lv_months_2_0= RULE_INT ) ) ) ) ;
    public final EObject ruleFlexibilty() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_months_2_0=null;
        Enumerator lv_value_1_0 = null;



        	enterRule();

        try {
            // InternalQueryPro.g:542:2: ( (otherlv_0= 'LAUFZEIT' ( ( (lv_value_1_0= ruleVertragskondition ) ) | ( (lv_months_2_0= RULE_INT ) ) ) ) )
            // InternalQueryPro.g:543:2: (otherlv_0= 'LAUFZEIT' ( ( (lv_value_1_0= ruleVertragskondition ) ) | ( (lv_months_2_0= RULE_INT ) ) ) )
            {
            // InternalQueryPro.g:543:2: (otherlv_0= 'LAUFZEIT' ( ( (lv_value_1_0= ruleVertragskondition ) ) | ( (lv_months_2_0= RULE_INT ) ) ) )
            // InternalQueryPro.g:544:3: otherlv_0= 'LAUFZEIT' ( ( (lv_value_1_0= ruleVertragskondition ) ) | ( (lv_months_2_0= RULE_INT ) ) )
            {
            otherlv_0=(Token)match(input,19,FOLLOW_12); 

            			newLeafNode(otherlv_0, grammarAccess.getFlexibiltyAccess().getLAUFZEITKeyword_0());
            		
            // InternalQueryPro.g:548:3: ( ( (lv_value_1_0= ruleVertragskondition ) ) | ( (lv_months_2_0= RULE_INT ) ) )
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==27||LA8_0==33||(LA8_0>=35 && LA8_0<=36)) ) {
                alt8=1;
            }
            else if ( (LA8_0==RULE_INT) ) {
                alt8=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 8, 0, input);

                throw nvae;
            }
            switch (alt8) {
                case 1 :
                    // InternalQueryPro.g:549:4: ( (lv_value_1_0= ruleVertragskondition ) )
                    {
                    // InternalQueryPro.g:549:4: ( (lv_value_1_0= ruleVertragskondition ) )
                    // InternalQueryPro.g:550:5: (lv_value_1_0= ruleVertragskondition )
                    {
                    // InternalQueryPro.g:550:5: (lv_value_1_0= ruleVertragskondition )
                    // InternalQueryPro.g:551:6: lv_value_1_0= ruleVertragskondition
                    {

                    						newCompositeNode(grammarAccess.getFlexibiltyAccess().getValueVertragskonditionEnumRuleCall_1_0_0());
                    					
                    pushFollow(FOLLOW_2);
                    lv_value_1_0=ruleVertragskondition();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getFlexibiltyRule());
                    						}
                    						set(
                    							current,
                    							"value",
                    							lv_value_1_0,
                    							"queryPro.QueryPro.Vertragskondition");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalQueryPro.g:569:4: ( (lv_months_2_0= RULE_INT ) )
                    {
                    // InternalQueryPro.g:569:4: ( (lv_months_2_0= RULE_INT ) )
                    // InternalQueryPro.g:570:5: (lv_months_2_0= RULE_INT )
                    {
                    // InternalQueryPro.g:570:5: (lv_months_2_0= RULE_INT )
                    // InternalQueryPro.g:571:6: lv_months_2_0= RULE_INT
                    {
                    lv_months_2_0=(Token)match(input,RULE_INT,FOLLOW_2); 

                    						newLeafNode(lv_months_2_0, grammarAccess.getFlexibiltyAccess().getMonthsINTTerminalRuleCall_1_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getFlexibiltyRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"months",
                    							lv_months_2_0,
                    							"org.eclipse.xtext.common.Terminals.INT");
                    					

                    }


                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFlexibilty"


    // $ANTLR start "entryRulePhone"
    // InternalQueryPro.g:592:1: entryRulePhone returns [EObject current=null] : iv_rulePhone= rulePhone EOF ;
    public final EObject entryRulePhone() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePhone = null;


        try {
            // InternalQueryPro.g:592:46: (iv_rulePhone= rulePhone EOF )
            // InternalQueryPro.g:593:2: iv_rulePhone= rulePhone EOF
            {
             newCompositeNode(grammarAccess.getPhoneRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePhone=rulePhone();

            state._fsp--;

             current =iv_rulePhone; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePhone"


    // $ANTLR start "rulePhone"
    // InternalQueryPro.g:599:1: rulePhone returns [EObject current=null] : (otherlv_0= 'HANDY' ( (otherlv_1= 'Marke' ( (lv_brand_2_0= ruleMarke ) ) ) | (otherlv_3= 'Betriebssystem' ( (lv_os_4_0= ruleBetriebssystem ) ) ) | (otherlv_5= 'Speicher' ( (lv_storage_6_0= RULE_INT ) ) ) )+ ) ;
    public final EObject rulePhone() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token lv_storage_6_0=null;
        Enumerator lv_brand_2_0 = null;

        Enumerator lv_os_4_0 = null;



        	enterRule();

        try {
            // InternalQueryPro.g:605:2: ( (otherlv_0= 'HANDY' ( (otherlv_1= 'Marke' ( (lv_brand_2_0= ruleMarke ) ) ) | (otherlv_3= 'Betriebssystem' ( (lv_os_4_0= ruleBetriebssystem ) ) ) | (otherlv_5= 'Speicher' ( (lv_storage_6_0= RULE_INT ) ) ) )+ ) )
            // InternalQueryPro.g:606:2: (otherlv_0= 'HANDY' ( (otherlv_1= 'Marke' ( (lv_brand_2_0= ruleMarke ) ) ) | (otherlv_3= 'Betriebssystem' ( (lv_os_4_0= ruleBetriebssystem ) ) ) | (otherlv_5= 'Speicher' ( (lv_storage_6_0= RULE_INT ) ) ) )+ )
            {
            // InternalQueryPro.g:606:2: (otherlv_0= 'HANDY' ( (otherlv_1= 'Marke' ( (lv_brand_2_0= ruleMarke ) ) ) | (otherlv_3= 'Betriebssystem' ( (lv_os_4_0= ruleBetriebssystem ) ) ) | (otherlv_5= 'Speicher' ( (lv_storage_6_0= RULE_INT ) ) ) )+ )
            // InternalQueryPro.g:607:3: otherlv_0= 'HANDY' ( (otherlv_1= 'Marke' ( (lv_brand_2_0= ruleMarke ) ) ) | (otherlv_3= 'Betriebssystem' ( (lv_os_4_0= ruleBetriebssystem ) ) ) | (otherlv_5= 'Speicher' ( (lv_storage_6_0= RULE_INT ) ) ) )+
            {
            otherlv_0=(Token)match(input,20,FOLLOW_13); 

            			newLeafNode(otherlv_0, grammarAccess.getPhoneAccess().getHANDYKeyword_0());
            		
            // InternalQueryPro.g:611:3: ( (otherlv_1= 'Marke' ( (lv_brand_2_0= ruleMarke ) ) ) | (otherlv_3= 'Betriebssystem' ( (lv_os_4_0= ruleBetriebssystem ) ) ) | (otherlv_5= 'Speicher' ( (lv_storage_6_0= RULE_INT ) ) ) )+
            int cnt9=0;
            loop9:
            do {
                int alt9=4;
                switch ( input.LA(1) ) {
                case 21:
                    {
                    alt9=1;
                    }
                    break;
                case 22:
                    {
                    alt9=2;
                    }
                    break;
                case 23:
                    {
                    alt9=3;
                    }
                    break;

                }

                switch (alt9) {
            	case 1 :
            	    // InternalQueryPro.g:612:4: (otherlv_1= 'Marke' ( (lv_brand_2_0= ruleMarke ) ) )
            	    {
            	    // InternalQueryPro.g:612:4: (otherlv_1= 'Marke' ( (lv_brand_2_0= ruleMarke ) ) )
            	    // InternalQueryPro.g:613:5: otherlv_1= 'Marke' ( (lv_brand_2_0= ruleMarke ) )
            	    {
            	    otherlv_1=(Token)match(input,21,FOLLOW_14); 

            	    					newLeafNode(otherlv_1, grammarAccess.getPhoneAccess().getMarkeKeyword_1_0_0());
            	    				
            	    // InternalQueryPro.g:617:5: ( (lv_brand_2_0= ruleMarke ) )
            	    // InternalQueryPro.g:618:6: (lv_brand_2_0= ruleMarke )
            	    {
            	    // InternalQueryPro.g:618:6: (lv_brand_2_0= ruleMarke )
            	    // InternalQueryPro.g:619:7: lv_brand_2_0= ruleMarke
            	    {

            	    							newCompositeNode(grammarAccess.getPhoneAccess().getBrandMarkeEnumRuleCall_1_0_1_0());
            	    						
            	    pushFollow(FOLLOW_15);
            	    lv_brand_2_0=ruleMarke();

            	    state._fsp--;


            	    							if (current==null) {
            	    								current = createModelElementForParent(grammarAccess.getPhoneRule());
            	    							}
            	    							set(
            	    								current,
            	    								"brand",
            	    								lv_brand_2_0,
            	    								"queryPro.QueryPro.Marke");
            	    							afterParserOrEnumRuleCall();
            	    						

            	    }


            	    }


            	    }


            	    }
            	    break;
            	case 2 :
            	    // InternalQueryPro.g:638:4: (otherlv_3= 'Betriebssystem' ( (lv_os_4_0= ruleBetriebssystem ) ) )
            	    {
            	    // InternalQueryPro.g:638:4: (otherlv_3= 'Betriebssystem' ( (lv_os_4_0= ruleBetriebssystem ) ) )
            	    // InternalQueryPro.g:639:5: otherlv_3= 'Betriebssystem' ( (lv_os_4_0= ruleBetriebssystem ) )
            	    {
            	    otherlv_3=(Token)match(input,22,FOLLOW_16); 

            	    					newLeafNode(otherlv_3, grammarAccess.getPhoneAccess().getBetriebssystemKeyword_1_1_0());
            	    				
            	    // InternalQueryPro.g:643:5: ( (lv_os_4_0= ruleBetriebssystem ) )
            	    // InternalQueryPro.g:644:6: (lv_os_4_0= ruleBetriebssystem )
            	    {
            	    // InternalQueryPro.g:644:6: (lv_os_4_0= ruleBetriebssystem )
            	    // InternalQueryPro.g:645:7: lv_os_4_0= ruleBetriebssystem
            	    {

            	    							newCompositeNode(grammarAccess.getPhoneAccess().getOsBetriebssystemEnumRuleCall_1_1_1_0());
            	    						
            	    pushFollow(FOLLOW_15);
            	    lv_os_4_0=ruleBetriebssystem();

            	    state._fsp--;


            	    							if (current==null) {
            	    								current = createModelElementForParent(grammarAccess.getPhoneRule());
            	    							}
            	    							set(
            	    								current,
            	    								"os",
            	    								lv_os_4_0,
            	    								"queryPro.QueryPro.Betriebssystem");
            	    							afterParserOrEnumRuleCall();
            	    						

            	    }


            	    }


            	    }


            	    }
            	    break;
            	case 3 :
            	    // InternalQueryPro.g:664:4: (otherlv_5= 'Speicher' ( (lv_storage_6_0= RULE_INT ) ) )
            	    {
            	    // InternalQueryPro.g:664:4: (otherlv_5= 'Speicher' ( (lv_storage_6_0= RULE_INT ) ) )
            	    // InternalQueryPro.g:665:5: otherlv_5= 'Speicher' ( (lv_storage_6_0= RULE_INT ) )
            	    {
            	    otherlv_5=(Token)match(input,23,FOLLOW_3); 

            	    					newLeafNode(otherlv_5, grammarAccess.getPhoneAccess().getSpeicherKeyword_1_2_0());
            	    				
            	    // InternalQueryPro.g:669:5: ( (lv_storage_6_0= RULE_INT ) )
            	    // InternalQueryPro.g:670:6: (lv_storage_6_0= RULE_INT )
            	    {
            	    // InternalQueryPro.g:670:6: (lv_storage_6_0= RULE_INT )
            	    // InternalQueryPro.g:671:7: lv_storage_6_0= RULE_INT
            	    {
            	    lv_storage_6_0=(Token)match(input,RULE_INT,FOLLOW_15); 

            	    							newLeafNode(lv_storage_6_0, grammarAccess.getPhoneAccess().getStorageINTTerminalRuleCall_1_2_1_0());
            	    						

            	    							if (current==null) {
            	    								current = createModelElement(grammarAccess.getPhoneRule());
            	    							}
            	    							setWithLastConsumed(
            	    								current,
            	    								"storage",
            	    								lv_storage_6_0,
            	    								"org.eclipse.xtext.common.Terminals.INT");
            	    						

            	    }


            	    }


            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt9 >= 1 ) break loop9;
                        EarlyExitException eee =
                            new EarlyExitException(9, input);
                        throw eee;
                }
                cnt9++;
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePhone"


    // $ANTLR start "ruleNetzanbieter"
    // InternalQueryPro.g:693:1: ruleNetzanbieter returns [Enumerator current=null] : ( (enumLiteral_0= 'O2' ) | (enumLiteral_1= 'TELEKOM' ) | (enumLiteral_2= 'VODAFON' ) ) ;
    public final Enumerator ruleNetzanbieter() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;


        	enterRule();

        try {
            // InternalQueryPro.g:699:2: ( ( (enumLiteral_0= 'O2' ) | (enumLiteral_1= 'TELEKOM' ) | (enumLiteral_2= 'VODAFON' ) ) )
            // InternalQueryPro.g:700:2: ( (enumLiteral_0= 'O2' ) | (enumLiteral_1= 'TELEKOM' ) | (enumLiteral_2= 'VODAFON' ) )
            {
            // InternalQueryPro.g:700:2: ( (enumLiteral_0= 'O2' ) | (enumLiteral_1= 'TELEKOM' ) | (enumLiteral_2= 'VODAFON' ) )
            int alt10=3;
            switch ( input.LA(1) ) {
            case 24:
                {
                alt10=1;
                }
                break;
            case 25:
                {
                alt10=2;
                }
                break;
            case 26:
                {
                alt10=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 10, 0, input);

                throw nvae;
            }

            switch (alt10) {
                case 1 :
                    // InternalQueryPro.g:701:3: (enumLiteral_0= 'O2' )
                    {
                    // InternalQueryPro.g:701:3: (enumLiteral_0= 'O2' )
                    // InternalQueryPro.g:702:4: enumLiteral_0= 'O2'
                    {
                    enumLiteral_0=(Token)match(input,24,FOLLOW_2); 

                    				current = grammarAccess.getNetzanbieterAccess().getO2EnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getNetzanbieterAccess().getO2EnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalQueryPro.g:709:3: (enumLiteral_1= 'TELEKOM' )
                    {
                    // InternalQueryPro.g:709:3: (enumLiteral_1= 'TELEKOM' )
                    // InternalQueryPro.g:710:4: enumLiteral_1= 'TELEKOM'
                    {
                    enumLiteral_1=(Token)match(input,25,FOLLOW_2); 

                    				current = grammarAccess.getNetzanbieterAccess().getTELEKOMEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getNetzanbieterAccess().getTELEKOMEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalQueryPro.g:717:3: (enumLiteral_2= 'VODAFON' )
                    {
                    // InternalQueryPro.g:717:3: (enumLiteral_2= 'VODAFON' )
                    // InternalQueryPro.g:718:4: enumLiteral_2= 'VODAFON'
                    {
                    enumLiteral_2=(Token)match(input,26,FOLLOW_2); 

                    				current = grammarAccess.getNetzanbieterAccess().getVODAFONEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getNetzanbieterAccess().getVODAFONEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleNetzanbieter"


    // $ANTLR start "ruleBetriebssystem"
    // InternalQueryPro.g:728:1: ruleBetriebssystem returns [Enumerator current=null] : ( (enumLiteral_0= 'egal' ) | (enumLiteral_1= 'ANDROID' ) | (enumLiteral_2= 'IOS' ) ) ;
    public final Enumerator ruleBetriebssystem() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;


        	enterRule();

        try {
            // InternalQueryPro.g:734:2: ( ( (enumLiteral_0= 'egal' ) | (enumLiteral_1= 'ANDROID' ) | (enumLiteral_2= 'IOS' ) ) )
            // InternalQueryPro.g:735:2: ( (enumLiteral_0= 'egal' ) | (enumLiteral_1= 'ANDROID' ) | (enumLiteral_2= 'IOS' ) )
            {
            // InternalQueryPro.g:735:2: ( (enumLiteral_0= 'egal' ) | (enumLiteral_1= 'ANDROID' ) | (enumLiteral_2= 'IOS' ) )
            int alt11=3;
            switch ( input.LA(1) ) {
            case 27:
                {
                alt11=1;
                }
                break;
            case 28:
                {
                alt11=2;
                }
                break;
            case 29:
                {
                alt11=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 11, 0, input);

                throw nvae;
            }

            switch (alt11) {
                case 1 :
                    // InternalQueryPro.g:736:3: (enumLiteral_0= 'egal' )
                    {
                    // InternalQueryPro.g:736:3: (enumLiteral_0= 'egal' )
                    // InternalQueryPro.g:737:4: enumLiteral_0= 'egal'
                    {
                    enumLiteral_0=(Token)match(input,27,FOLLOW_2); 

                    				current = grammarAccess.getBetriebssystemAccess().getEgalEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getBetriebssystemAccess().getEgalEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalQueryPro.g:744:3: (enumLiteral_1= 'ANDROID' )
                    {
                    // InternalQueryPro.g:744:3: (enumLiteral_1= 'ANDROID' )
                    // InternalQueryPro.g:745:4: enumLiteral_1= 'ANDROID'
                    {
                    enumLiteral_1=(Token)match(input,28,FOLLOW_2); 

                    				current = grammarAccess.getBetriebssystemAccess().getANDROIDEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getBetriebssystemAccess().getANDROIDEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalQueryPro.g:752:3: (enumLiteral_2= 'IOS' )
                    {
                    // InternalQueryPro.g:752:3: (enumLiteral_2= 'IOS' )
                    // InternalQueryPro.g:753:4: enumLiteral_2= 'IOS'
                    {
                    enumLiteral_2=(Token)match(input,29,FOLLOW_2); 

                    				current = grammarAccess.getBetriebssystemAccess().getIOSEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getBetriebssystemAccess().getIOSEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleBetriebssystem"


    // $ANTLR start "ruleIntensitaet"
    // InternalQueryPro.g:763:1: ruleIntensitaet returns [Enumerator current=null] : ( (enumLiteral_0= 'egal' ) | (enumLiteral_1= 'wenig' ) | (enumLiteral_2= 'viel' ) ) ;
    public final Enumerator ruleIntensitaet() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;


        	enterRule();

        try {
            // InternalQueryPro.g:769:2: ( ( (enumLiteral_0= 'egal' ) | (enumLiteral_1= 'wenig' ) | (enumLiteral_2= 'viel' ) ) )
            // InternalQueryPro.g:770:2: ( (enumLiteral_0= 'egal' ) | (enumLiteral_1= 'wenig' ) | (enumLiteral_2= 'viel' ) )
            {
            // InternalQueryPro.g:770:2: ( (enumLiteral_0= 'egal' ) | (enumLiteral_1= 'wenig' ) | (enumLiteral_2= 'viel' ) )
            int alt12=3;
            switch ( input.LA(1) ) {
            case 27:
                {
                alt12=1;
                }
                break;
            case 30:
                {
                alt12=2;
                }
                break;
            case 31:
                {
                alt12=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 12, 0, input);

                throw nvae;
            }

            switch (alt12) {
                case 1 :
                    // InternalQueryPro.g:771:3: (enumLiteral_0= 'egal' )
                    {
                    // InternalQueryPro.g:771:3: (enumLiteral_0= 'egal' )
                    // InternalQueryPro.g:772:4: enumLiteral_0= 'egal'
                    {
                    enumLiteral_0=(Token)match(input,27,FOLLOW_2); 

                    				current = grammarAccess.getIntensitaetAccess().getEgalEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getIntensitaetAccess().getEgalEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalQueryPro.g:779:3: (enumLiteral_1= 'wenig' )
                    {
                    // InternalQueryPro.g:779:3: (enumLiteral_1= 'wenig' )
                    // InternalQueryPro.g:780:4: enumLiteral_1= 'wenig'
                    {
                    enumLiteral_1=(Token)match(input,30,FOLLOW_2); 

                    				current = grammarAccess.getIntensitaetAccess().getWenigEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getIntensitaetAccess().getWenigEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalQueryPro.g:787:3: (enumLiteral_2= 'viel' )
                    {
                    // InternalQueryPro.g:787:3: (enumLiteral_2= 'viel' )
                    // InternalQueryPro.g:788:4: enumLiteral_2= 'viel'
                    {
                    enumLiteral_2=(Token)match(input,31,FOLLOW_2); 

                    				current = grammarAccess.getIntensitaetAccess().getVielEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getIntensitaetAccess().getVielEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleIntensitaet"


    // $ANTLR start "ruleIntensitaet_Flat"
    // InternalQueryPro.g:798:1: ruleIntensitaet_Flat returns [Enumerator current=null] : ( (enumLiteral_0= 'egal' ) | (enumLiteral_1= 'wenig' ) | (enumLiteral_2= 'viel' ) | (enumLiteral_3= 'flat' ) ) ;
    public final Enumerator ruleIntensitaet_Flat() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;


        	enterRule();

        try {
            // InternalQueryPro.g:804:2: ( ( (enumLiteral_0= 'egal' ) | (enumLiteral_1= 'wenig' ) | (enumLiteral_2= 'viel' ) | (enumLiteral_3= 'flat' ) ) )
            // InternalQueryPro.g:805:2: ( (enumLiteral_0= 'egal' ) | (enumLiteral_1= 'wenig' ) | (enumLiteral_2= 'viel' ) | (enumLiteral_3= 'flat' ) )
            {
            // InternalQueryPro.g:805:2: ( (enumLiteral_0= 'egal' ) | (enumLiteral_1= 'wenig' ) | (enumLiteral_2= 'viel' ) | (enumLiteral_3= 'flat' ) )
            int alt13=4;
            switch ( input.LA(1) ) {
            case 27:
                {
                alt13=1;
                }
                break;
            case 30:
                {
                alt13=2;
                }
                break;
            case 31:
                {
                alt13=3;
                }
                break;
            case 32:
                {
                alt13=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 13, 0, input);

                throw nvae;
            }

            switch (alt13) {
                case 1 :
                    // InternalQueryPro.g:806:3: (enumLiteral_0= 'egal' )
                    {
                    // InternalQueryPro.g:806:3: (enumLiteral_0= 'egal' )
                    // InternalQueryPro.g:807:4: enumLiteral_0= 'egal'
                    {
                    enumLiteral_0=(Token)match(input,27,FOLLOW_2); 

                    				current = grammarAccess.getIntensitaet_FlatAccess().getEgalEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getIntensitaet_FlatAccess().getEgalEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalQueryPro.g:814:3: (enumLiteral_1= 'wenig' )
                    {
                    // InternalQueryPro.g:814:3: (enumLiteral_1= 'wenig' )
                    // InternalQueryPro.g:815:4: enumLiteral_1= 'wenig'
                    {
                    enumLiteral_1=(Token)match(input,30,FOLLOW_2); 

                    				current = grammarAccess.getIntensitaet_FlatAccess().getWenigEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getIntensitaet_FlatAccess().getWenigEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalQueryPro.g:822:3: (enumLiteral_2= 'viel' )
                    {
                    // InternalQueryPro.g:822:3: (enumLiteral_2= 'viel' )
                    // InternalQueryPro.g:823:4: enumLiteral_2= 'viel'
                    {
                    enumLiteral_2=(Token)match(input,31,FOLLOW_2); 

                    				current = grammarAccess.getIntensitaet_FlatAccess().getVielEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getIntensitaet_FlatAccess().getVielEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalQueryPro.g:830:3: (enumLiteral_3= 'flat' )
                    {
                    // InternalQueryPro.g:830:3: (enumLiteral_3= 'flat' )
                    // InternalQueryPro.g:831:4: enumLiteral_3= 'flat'
                    {
                    enumLiteral_3=(Token)match(input,32,FOLLOW_2); 

                    				current = grammarAccess.getIntensitaet_FlatAccess().getFlatEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getIntensitaet_FlatAccess().getFlatEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleIntensitaet_Flat"


    // $ANTLR start "ruleNetzverbreitung"
    // InternalQueryPro.g:841:1: ruleNetzverbreitung returns [Enumerator current=null] : ( (enumLiteral_0= 'egal' ) | (enumLiteral_1= 'normal' ) | (enumLiteral_2= 'gut' ) ) ;
    public final Enumerator ruleNetzverbreitung() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;


        	enterRule();

        try {
            // InternalQueryPro.g:847:2: ( ( (enumLiteral_0= 'egal' ) | (enumLiteral_1= 'normal' ) | (enumLiteral_2= 'gut' ) ) )
            // InternalQueryPro.g:848:2: ( (enumLiteral_0= 'egal' ) | (enumLiteral_1= 'normal' ) | (enumLiteral_2= 'gut' ) )
            {
            // InternalQueryPro.g:848:2: ( (enumLiteral_0= 'egal' ) | (enumLiteral_1= 'normal' ) | (enumLiteral_2= 'gut' ) )
            int alt14=3;
            switch ( input.LA(1) ) {
            case 27:
                {
                alt14=1;
                }
                break;
            case 33:
                {
                alt14=2;
                }
                break;
            case 34:
                {
                alt14=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 14, 0, input);

                throw nvae;
            }

            switch (alt14) {
                case 1 :
                    // InternalQueryPro.g:849:3: (enumLiteral_0= 'egal' )
                    {
                    // InternalQueryPro.g:849:3: (enumLiteral_0= 'egal' )
                    // InternalQueryPro.g:850:4: enumLiteral_0= 'egal'
                    {
                    enumLiteral_0=(Token)match(input,27,FOLLOW_2); 

                    				current = grammarAccess.getNetzverbreitungAccess().getEgalEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getNetzverbreitungAccess().getEgalEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalQueryPro.g:857:3: (enumLiteral_1= 'normal' )
                    {
                    // InternalQueryPro.g:857:3: (enumLiteral_1= 'normal' )
                    // InternalQueryPro.g:858:4: enumLiteral_1= 'normal'
                    {
                    enumLiteral_1=(Token)match(input,33,FOLLOW_2); 

                    				current = grammarAccess.getNetzverbreitungAccess().getNormalEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getNetzverbreitungAccess().getNormalEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalQueryPro.g:865:3: (enumLiteral_2= 'gut' )
                    {
                    // InternalQueryPro.g:865:3: (enumLiteral_2= 'gut' )
                    // InternalQueryPro.g:866:4: enumLiteral_2= 'gut'
                    {
                    enumLiteral_2=(Token)match(input,34,FOLLOW_2); 

                    				current = grammarAccess.getNetzverbreitungAccess().getGutEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getNetzverbreitungAccess().getGutEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleNetzverbreitung"


    // $ANTLR start "ruleVertragskondition"
    // InternalQueryPro.g:876:1: ruleVertragskondition returns [Enumerator current=null] : ( (enumLiteral_0= 'egal' ) | (enumLiteral_1= 'kurz' ) | (enumLiteral_2= 'flexibel' ) | (enumLiteral_3= 'normal' ) ) ;
    public final Enumerator ruleVertragskondition() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;


        	enterRule();

        try {
            // InternalQueryPro.g:882:2: ( ( (enumLiteral_0= 'egal' ) | (enumLiteral_1= 'kurz' ) | (enumLiteral_2= 'flexibel' ) | (enumLiteral_3= 'normal' ) ) )
            // InternalQueryPro.g:883:2: ( (enumLiteral_0= 'egal' ) | (enumLiteral_1= 'kurz' ) | (enumLiteral_2= 'flexibel' ) | (enumLiteral_3= 'normal' ) )
            {
            // InternalQueryPro.g:883:2: ( (enumLiteral_0= 'egal' ) | (enumLiteral_1= 'kurz' ) | (enumLiteral_2= 'flexibel' ) | (enumLiteral_3= 'normal' ) )
            int alt15=4;
            switch ( input.LA(1) ) {
            case 27:
                {
                alt15=1;
                }
                break;
            case 35:
                {
                alt15=2;
                }
                break;
            case 36:
                {
                alt15=3;
                }
                break;
            case 33:
                {
                alt15=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 15, 0, input);

                throw nvae;
            }

            switch (alt15) {
                case 1 :
                    // InternalQueryPro.g:884:3: (enumLiteral_0= 'egal' )
                    {
                    // InternalQueryPro.g:884:3: (enumLiteral_0= 'egal' )
                    // InternalQueryPro.g:885:4: enumLiteral_0= 'egal'
                    {
                    enumLiteral_0=(Token)match(input,27,FOLLOW_2); 

                    				current = grammarAccess.getVertragskonditionAccess().getEgalEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getVertragskonditionAccess().getEgalEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalQueryPro.g:892:3: (enumLiteral_1= 'kurz' )
                    {
                    // InternalQueryPro.g:892:3: (enumLiteral_1= 'kurz' )
                    // InternalQueryPro.g:893:4: enumLiteral_1= 'kurz'
                    {
                    enumLiteral_1=(Token)match(input,35,FOLLOW_2); 

                    				current = grammarAccess.getVertragskonditionAccess().getKurzEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getVertragskonditionAccess().getKurzEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalQueryPro.g:900:3: (enumLiteral_2= 'flexibel' )
                    {
                    // InternalQueryPro.g:900:3: (enumLiteral_2= 'flexibel' )
                    // InternalQueryPro.g:901:4: enumLiteral_2= 'flexibel'
                    {
                    enumLiteral_2=(Token)match(input,36,FOLLOW_2); 

                    				current = grammarAccess.getVertragskonditionAccess().getFlexibelEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getVertragskonditionAccess().getFlexibelEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalQueryPro.g:908:3: (enumLiteral_3= 'normal' )
                    {
                    // InternalQueryPro.g:908:3: (enumLiteral_3= 'normal' )
                    // InternalQueryPro.g:909:4: enumLiteral_3= 'normal'
                    {
                    enumLiteral_3=(Token)match(input,33,FOLLOW_2); 

                    				current = grammarAccess.getVertragskonditionAccess().getNormalEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getVertragskonditionAccess().getNormalEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVertragskondition"


    // $ANTLR start "ruleMarke"
    // InternalQueryPro.g:919:1: ruleMarke returns [Enumerator current=null] : ( (enumLiteral_0= 'egal' ) | (enumLiteral_1= 'SAMSUNG' ) | (enumLiteral_2= 'IPHONE' ) | (enumLiteral_3= 'NOKIA' ) ) ;
    public final Enumerator ruleMarke() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;


        	enterRule();

        try {
            // InternalQueryPro.g:925:2: ( ( (enumLiteral_0= 'egal' ) | (enumLiteral_1= 'SAMSUNG' ) | (enumLiteral_2= 'IPHONE' ) | (enumLiteral_3= 'NOKIA' ) ) )
            // InternalQueryPro.g:926:2: ( (enumLiteral_0= 'egal' ) | (enumLiteral_1= 'SAMSUNG' ) | (enumLiteral_2= 'IPHONE' ) | (enumLiteral_3= 'NOKIA' ) )
            {
            // InternalQueryPro.g:926:2: ( (enumLiteral_0= 'egal' ) | (enumLiteral_1= 'SAMSUNG' ) | (enumLiteral_2= 'IPHONE' ) | (enumLiteral_3= 'NOKIA' ) )
            int alt16=4;
            switch ( input.LA(1) ) {
            case 27:
                {
                alt16=1;
                }
                break;
            case 37:
                {
                alt16=2;
                }
                break;
            case 38:
                {
                alt16=3;
                }
                break;
            case 39:
                {
                alt16=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 16, 0, input);

                throw nvae;
            }

            switch (alt16) {
                case 1 :
                    // InternalQueryPro.g:927:3: (enumLiteral_0= 'egal' )
                    {
                    // InternalQueryPro.g:927:3: (enumLiteral_0= 'egal' )
                    // InternalQueryPro.g:928:4: enumLiteral_0= 'egal'
                    {
                    enumLiteral_0=(Token)match(input,27,FOLLOW_2); 

                    				current = grammarAccess.getMarkeAccess().getEgalEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getMarkeAccess().getEgalEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalQueryPro.g:935:3: (enumLiteral_1= 'SAMSUNG' )
                    {
                    // InternalQueryPro.g:935:3: (enumLiteral_1= 'SAMSUNG' )
                    // InternalQueryPro.g:936:4: enumLiteral_1= 'SAMSUNG'
                    {
                    enumLiteral_1=(Token)match(input,37,FOLLOW_2); 

                    				current = grammarAccess.getMarkeAccess().getSAMSUNGEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getMarkeAccess().getSAMSUNGEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalQueryPro.g:943:3: (enumLiteral_2= 'IPHONE' )
                    {
                    // InternalQueryPro.g:943:3: (enumLiteral_2= 'IPHONE' )
                    // InternalQueryPro.g:944:4: enumLiteral_2= 'IPHONE'
                    {
                    enumLiteral_2=(Token)match(input,38,FOLLOW_2); 

                    				current = grammarAccess.getMarkeAccess().getIPHONEEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getMarkeAccess().getIPHONEEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalQueryPro.g:951:3: (enumLiteral_3= 'NOKIA' )
                    {
                    // InternalQueryPro.g:951:3: (enumLiteral_3= 'NOKIA' )
                    // InternalQueryPro.g:952:4: enumLiteral_3= 'NOKIA'
                    {
                    enumLiteral_3=(Token)match(input,39,FOLLOW_2); 

                    				current = grammarAccess.getMarkeAccess().getNOKIAEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getMarkeAccess().getNOKIAEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMarke"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x00000000001CE002L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x00000001C8000010L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x00000001C8000020L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x00000000C8000012L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000000012L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x000000060F000000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000001A08000010L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000E00000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x000000E008000000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000E00002L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000038000000L});

}