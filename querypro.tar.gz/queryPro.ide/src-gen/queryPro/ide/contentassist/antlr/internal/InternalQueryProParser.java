package queryPro.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import queryPro.services.QueryProGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalQueryProParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_INT", "RULE_PRICE", "RULE_ID", "RULE_STRING", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'O2'", "'TELEKOM'", "'VODAFON'", "'egal'", "'ANDROID'", "'IOS'", "'wenig'", "'viel'", "'normal'", "'gut'", "'kurz'", "'flexibel'", "'SAMSUNG'", "'IPHONE'", "'NOKIA'", "'SUCHE'", "'TELEFONIERE'", "'SMS'", "'INTERNET'", "'datenvolumen'", "'MBits'", "'NETZ'", "'LAUFZEIT'", "'HANDY'", "'Marke'", "'Betriebssystem'", "'Speicher'"
    };
    public static final int RULE_STRING=7;
    public static final int RULE_SL_COMMENT=9;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__37=37;
    public static final int T__16=16;
    public static final int T__38=38;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__33=33;
    public static final int T__12=12;
    public static final int T__34=34;
    public static final int T__13=13;
    public static final int T__35=35;
    public static final int T__14=14;
    public static final int T__36=36;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_ID=6;
    public static final int RULE_WS=10;
    public static final int RULE_ANY_OTHER=11;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=4;
    public static final int RULE_PRICE=5;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=8;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalQueryProParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalQueryProParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalQueryProParser.tokenNames; }
    public String getGrammarFileName() { return "InternalQueryPro.g"; }


    	private QueryProGrammarAccess grammarAccess;

    	public void setGrammarAccess(QueryProGrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRuleQuery"
    // InternalQueryPro.g:53:1: entryRuleQuery : ruleQuery EOF ;
    public final void entryRuleQuery() throws RecognitionException {
        try {
            // InternalQueryPro.g:54:1: ( ruleQuery EOF )
            // InternalQueryPro.g:55:1: ruleQuery EOF
            {
             before(grammarAccess.getQueryRule()); 
            pushFollow(FOLLOW_1);
            ruleQuery();

            state._fsp--;

             after(grammarAccess.getQueryRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleQuery"


    // $ANTLR start "ruleQuery"
    // InternalQueryPro.g:62:1: ruleQuery : ( ( rule__Query__Group__0 ) ) ;
    public final void ruleQuery() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:66:2: ( ( ( rule__Query__Group__0 ) ) )
            // InternalQueryPro.g:67:2: ( ( rule__Query__Group__0 ) )
            {
            // InternalQueryPro.g:67:2: ( ( rule__Query__Group__0 ) )
            // InternalQueryPro.g:68:3: ( rule__Query__Group__0 )
            {
             before(grammarAccess.getQueryAccess().getGroup()); 
            // InternalQueryPro.g:69:3: ( rule__Query__Group__0 )
            // InternalQueryPro.g:69:4: rule__Query__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Query__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getQueryAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleQuery"


    // $ANTLR start "entryRuleKriteria"
    // InternalQueryPro.g:78:1: entryRuleKriteria : ruleKriteria EOF ;
    public final void entryRuleKriteria() throws RecognitionException {
        try {
            // InternalQueryPro.g:79:1: ( ruleKriteria EOF )
            // InternalQueryPro.g:80:1: ruleKriteria EOF
            {
             before(grammarAccess.getKriteriaRule()); 
            pushFollow(FOLLOW_1);
            ruleKriteria();

            state._fsp--;

             after(grammarAccess.getKriteriaRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleKriteria"


    // $ANTLR start "ruleKriteria"
    // InternalQueryPro.g:87:1: ruleKriteria : ( ( rule__Kriteria__TypeAssignment ) ) ;
    public final void ruleKriteria() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:91:2: ( ( ( rule__Kriteria__TypeAssignment ) ) )
            // InternalQueryPro.g:92:2: ( ( rule__Kriteria__TypeAssignment ) )
            {
            // InternalQueryPro.g:92:2: ( ( rule__Kriteria__TypeAssignment ) )
            // InternalQueryPro.g:93:3: ( rule__Kriteria__TypeAssignment )
            {
             before(grammarAccess.getKriteriaAccess().getTypeAssignment()); 
            // InternalQueryPro.g:94:3: ( rule__Kriteria__TypeAssignment )
            // InternalQueryPro.g:94:4: rule__Kriteria__TypeAssignment
            {
            pushFollow(FOLLOW_2);
            rule__Kriteria__TypeAssignment();

            state._fsp--;


            }

             after(grammarAccess.getKriteriaAccess().getTypeAssignment()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleKriteria"


    // $ANTLR start "entryRuleTelephone"
    // InternalQueryPro.g:103:1: entryRuleTelephone : ruleTelephone EOF ;
    public final void entryRuleTelephone() throws RecognitionException {
        try {
            // InternalQueryPro.g:104:1: ( ruleTelephone EOF )
            // InternalQueryPro.g:105:1: ruleTelephone EOF
            {
             before(grammarAccess.getTelephoneRule()); 
            pushFollow(FOLLOW_1);
            ruleTelephone();

            state._fsp--;

             after(grammarAccess.getTelephoneRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleTelephone"


    // $ANTLR start "ruleTelephone"
    // InternalQueryPro.g:112:1: ruleTelephone : ( ( rule__Telephone__Group__0 ) ) ;
    public final void ruleTelephone() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:116:2: ( ( ( rule__Telephone__Group__0 ) ) )
            // InternalQueryPro.g:117:2: ( ( rule__Telephone__Group__0 ) )
            {
            // InternalQueryPro.g:117:2: ( ( rule__Telephone__Group__0 ) )
            // InternalQueryPro.g:118:3: ( rule__Telephone__Group__0 )
            {
             before(grammarAccess.getTelephoneAccess().getGroup()); 
            // InternalQueryPro.g:119:3: ( rule__Telephone__Group__0 )
            // InternalQueryPro.g:119:4: rule__Telephone__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Telephone__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getTelephoneAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleTelephone"


    // $ANTLR start "entryRuleSMS"
    // InternalQueryPro.g:128:1: entryRuleSMS : ruleSMS EOF ;
    public final void entryRuleSMS() throws RecognitionException {
        try {
            // InternalQueryPro.g:129:1: ( ruleSMS EOF )
            // InternalQueryPro.g:130:1: ruleSMS EOF
            {
             before(grammarAccess.getSMSRule()); 
            pushFollow(FOLLOW_1);
            ruleSMS();

            state._fsp--;

             after(grammarAccess.getSMSRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleSMS"


    // $ANTLR start "ruleSMS"
    // InternalQueryPro.g:137:1: ruleSMS : ( ( rule__SMS__Group__0 ) ) ;
    public final void ruleSMS() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:141:2: ( ( ( rule__SMS__Group__0 ) ) )
            // InternalQueryPro.g:142:2: ( ( rule__SMS__Group__0 ) )
            {
            // InternalQueryPro.g:142:2: ( ( rule__SMS__Group__0 ) )
            // InternalQueryPro.g:143:3: ( rule__SMS__Group__0 )
            {
             before(grammarAccess.getSMSAccess().getGroup()); 
            // InternalQueryPro.g:144:3: ( rule__SMS__Group__0 )
            // InternalQueryPro.g:144:4: rule__SMS__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__SMS__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getSMSAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSMS"


    // $ANTLR start "entryRuleInternet"
    // InternalQueryPro.g:153:1: entryRuleInternet : ruleInternet EOF ;
    public final void entryRuleInternet() throws RecognitionException {
        try {
            // InternalQueryPro.g:154:1: ( ruleInternet EOF )
            // InternalQueryPro.g:155:1: ruleInternet EOF
            {
             before(grammarAccess.getInternetRule()); 
            pushFollow(FOLLOW_1);
            ruleInternet();

            state._fsp--;

             after(grammarAccess.getInternetRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleInternet"


    // $ANTLR start "ruleInternet"
    // InternalQueryPro.g:162:1: ruleInternet : ( ( rule__Internet__Group__0 ) ) ;
    public final void ruleInternet() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:166:2: ( ( ( rule__Internet__Group__0 ) ) )
            // InternalQueryPro.g:167:2: ( ( rule__Internet__Group__0 ) )
            {
            // InternalQueryPro.g:167:2: ( ( rule__Internet__Group__0 ) )
            // InternalQueryPro.g:168:3: ( rule__Internet__Group__0 )
            {
             before(grammarAccess.getInternetAccess().getGroup()); 
            // InternalQueryPro.g:169:3: ( rule__Internet__Group__0 )
            // InternalQueryPro.g:169:4: rule__Internet__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Internet__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getInternetAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleInternet"


    // $ANTLR start "entryRuleNet"
    // InternalQueryPro.g:178:1: entryRuleNet : ruleNet EOF ;
    public final void entryRuleNet() throws RecognitionException {
        try {
            // InternalQueryPro.g:179:1: ( ruleNet EOF )
            // InternalQueryPro.g:180:1: ruleNet EOF
            {
             before(grammarAccess.getNetRule()); 
            pushFollow(FOLLOW_1);
            ruleNet();

            state._fsp--;

             after(grammarAccess.getNetRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleNet"


    // $ANTLR start "ruleNet"
    // InternalQueryPro.g:187:1: ruleNet : ( ( rule__Net__Group__0 ) ) ;
    public final void ruleNet() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:191:2: ( ( ( rule__Net__Group__0 ) ) )
            // InternalQueryPro.g:192:2: ( ( rule__Net__Group__0 ) )
            {
            // InternalQueryPro.g:192:2: ( ( rule__Net__Group__0 ) )
            // InternalQueryPro.g:193:3: ( rule__Net__Group__0 )
            {
             before(grammarAccess.getNetAccess().getGroup()); 
            // InternalQueryPro.g:194:3: ( rule__Net__Group__0 )
            // InternalQueryPro.g:194:4: rule__Net__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Net__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getNetAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleNet"


    // $ANTLR start "entryRuleFlexibilty"
    // InternalQueryPro.g:203:1: entryRuleFlexibilty : ruleFlexibilty EOF ;
    public final void entryRuleFlexibilty() throws RecognitionException {
        try {
            // InternalQueryPro.g:204:1: ( ruleFlexibilty EOF )
            // InternalQueryPro.g:205:1: ruleFlexibilty EOF
            {
             before(grammarAccess.getFlexibiltyRule()); 
            pushFollow(FOLLOW_1);
            ruleFlexibilty();

            state._fsp--;

             after(grammarAccess.getFlexibiltyRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleFlexibilty"


    // $ANTLR start "ruleFlexibilty"
    // InternalQueryPro.g:212:1: ruleFlexibilty : ( ( rule__Flexibilty__Group__0 ) ) ;
    public final void ruleFlexibilty() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:216:2: ( ( ( rule__Flexibilty__Group__0 ) ) )
            // InternalQueryPro.g:217:2: ( ( rule__Flexibilty__Group__0 ) )
            {
            // InternalQueryPro.g:217:2: ( ( rule__Flexibilty__Group__0 ) )
            // InternalQueryPro.g:218:3: ( rule__Flexibilty__Group__0 )
            {
             before(grammarAccess.getFlexibiltyAccess().getGroup()); 
            // InternalQueryPro.g:219:3: ( rule__Flexibilty__Group__0 )
            // InternalQueryPro.g:219:4: rule__Flexibilty__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Flexibilty__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getFlexibiltyAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleFlexibilty"


    // $ANTLR start "entryRulePhone"
    // InternalQueryPro.g:228:1: entryRulePhone : rulePhone EOF ;
    public final void entryRulePhone() throws RecognitionException {
        try {
            // InternalQueryPro.g:229:1: ( rulePhone EOF )
            // InternalQueryPro.g:230:1: rulePhone EOF
            {
             before(grammarAccess.getPhoneRule()); 
            pushFollow(FOLLOW_1);
            rulePhone();

            state._fsp--;

             after(grammarAccess.getPhoneRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRulePhone"


    // $ANTLR start "rulePhone"
    // InternalQueryPro.g:237:1: rulePhone : ( ( rule__Phone__Group__0 ) ) ;
    public final void rulePhone() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:241:2: ( ( ( rule__Phone__Group__0 ) ) )
            // InternalQueryPro.g:242:2: ( ( rule__Phone__Group__0 ) )
            {
            // InternalQueryPro.g:242:2: ( ( rule__Phone__Group__0 ) )
            // InternalQueryPro.g:243:3: ( rule__Phone__Group__0 )
            {
             before(grammarAccess.getPhoneAccess().getGroup()); 
            // InternalQueryPro.g:244:3: ( rule__Phone__Group__0 )
            // InternalQueryPro.g:244:4: rule__Phone__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Phone__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getPhoneAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rulePhone"


    // $ANTLR start "ruleNetzanbieter"
    // InternalQueryPro.g:253:1: ruleNetzanbieter : ( ( rule__Netzanbieter__Alternatives ) ) ;
    public final void ruleNetzanbieter() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:257:1: ( ( ( rule__Netzanbieter__Alternatives ) ) )
            // InternalQueryPro.g:258:2: ( ( rule__Netzanbieter__Alternatives ) )
            {
            // InternalQueryPro.g:258:2: ( ( rule__Netzanbieter__Alternatives ) )
            // InternalQueryPro.g:259:3: ( rule__Netzanbieter__Alternatives )
            {
             before(grammarAccess.getNetzanbieterAccess().getAlternatives()); 
            // InternalQueryPro.g:260:3: ( rule__Netzanbieter__Alternatives )
            // InternalQueryPro.g:260:4: rule__Netzanbieter__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Netzanbieter__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getNetzanbieterAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleNetzanbieter"


    // $ANTLR start "ruleBetriebssystem"
    // InternalQueryPro.g:269:1: ruleBetriebssystem : ( ( rule__Betriebssystem__Alternatives ) ) ;
    public final void ruleBetriebssystem() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:273:1: ( ( ( rule__Betriebssystem__Alternatives ) ) )
            // InternalQueryPro.g:274:2: ( ( rule__Betriebssystem__Alternatives ) )
            {
            // InternalQueryPro.g:274:2: ( ( rule__Betriebssystem__Alternatives ) )
            // InternalQueryPro.g:275:3: ( rule__Betriebssystem__Alternatives )
            {
             before(grammarAccess.getBetriebssystemAccess().getAlternatives()); 
            // InternalQueryPro.g:276:3: ( rule__Betriebssystem__Alternatives )
            // InternalQueryPro.g:276:4: rule__Betriebssystem__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Betriebssystem__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getBetriebssystemAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleBetriebssystem"


    // $ANTLR start "ruleIntensitaet"
    // InternalQueryPro.g:285:1: ruleIntensitaet : ( ( rule__Intensitaet__Alternatives ) ) ;
    public final void ruleIntensitaet() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:289:1: ( ( ( rule__Intensitaet__Alternatives ) ) )
            // InternalQueryPro.g:290:2: ( ( rule__Intensitaet__Alternatives ) )
            {
            // InternalQueryPro.g:290:2: ( ( rule__Intensitaet__Alternatives ) )
            // InternalQueryPro.g:291:3: ( rule__Intensitaet__Alternatives )
            {
             before(grammarAccess.getIntensitaetAccess().getAlternatives()); 
            // InternalQueryPro.g:292:3: ( rule__Intensitaet__Alternatives )
            // InternalQueryPro.g:292:4: rule__Intensitaet__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Intensitaet__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getIntensitaetAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleIntensitaet"


    // $ANTLR start "ruleNetzverbreitung"
    // InternalQueryPro.g:301:1: ruleNetzverbreitung : ( ( rule__Netzverbreitung__Alternatives ) ) ;
    public final void ruleNetzverbreitung() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:305:1: ( ( ( rule__Netzverbreitung__Alternatives ) ) )
            // InternalQueryPro.g:306:2: ( ( rule__Netzverbreitung__Alternatives ) )
            {
            // InternalQueryPro.g:306:2: ( ( rule__Netzverbreitung__Alternatives ) )
            // InternalQueryPro.g:307:3: ( rule__Netzverbreitung__Alternatives )
            {
             before(grammarAccess.getNetzverbreitungAccess().getAlternatives()); 
            // InternalQueryPro.g:308:3: ( rule__Netzverbreitung__Alternatives )
            // InternalQueryPro.g:308:4: rule__Netzverbreitung__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Netzverbreitung__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getNetzverbreitungAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleNetzverbreitung"


    // $ANTLR start "ruleVertragskondition"
    // InternalQueryPro.g:317:1: ruleVertragskondition : ( ( rule__Vertragskondition__Alternatives ) ) ;
    public final void ruleVertragskondition() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:321:1: ( ( ( rule__Vertragskondition__Alternatives ) ) )
            // InternalQueryPro.g:322:2: ( ( rule__Vertragskondition__Alternatives ) )
            {
            // InternalQueryPro.g:322:2: ( ( rule__Vertragskondition__Alternatives ) )
            // InternalQueryPro.g:323:3: ( rule__Vertragskondition__Alternatives )
            {
             before(grammarAccess.getVertragskonditionAccess().getAlternatives()); 
            // InternalQueryPro.g:324:3: ( rule__Vertragskondition__Alternatives )
            // InternalQueryPro.g:324:4: rule__Vertragskondition__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Vertragskondition__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getVertragskonditionAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleVertragskondition"


    // $ANTLR start "ruleMarke"
    // InternalQueryPro.g:333:1: ruleMarke : ( ( rule__Marke__Alternatives ) ) ;
    public final void ruleMarke() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:337:1: ( ( ( rule__Marke__Alternatives ) ) )
            // InternalQueryPro.g:338:2: ( ( rule__Marke__Alternatives ) )
            {
            // InternalQueryPro.g:338:2: ( ( rule__Marke__Alternatives ) )
            // InternalQueryPro.g:339:3: ( rule__Marke__Alternatives )
            {
             before(grammarAccess.getMarkeAccess().getAlternatives()); 
            // InternalQueryPro.g:340:3: ( rule__Marke__Alternatives )
            // InternalQueryPro.g:340:4: rule__Marke__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Marke__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getMarkeAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleMarke"


    // $ANTLR start "rule__Kriteria__TypeAlternatives_0"
    // InternalQueryPro.g:348:1: rule__Kriteria__TypeAlternatives_0 : ( ( ruleTelephone ) | ( ruleSMS ) | ( ruleInternet ) | ( ruleNet ) | ( ruleFlexibilty ) | ( rulePhone ) );
    public final void rule__Kriteria__TypeAlternatives_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:352:1: ( ( ruleTelephone ) | ( ruleSMS ) | ( ruleInternet ) | ( ruleNet ) | ( ruleFlexibilty ) | ( rulePhone ) )
            int alt1=6;
            switch ( input.LA(1) ) {
            case 28:
                {
                alt1=1;
                }
                break;
            case 29:
                {
                alt1=2;
                }
                break;
            case 30:
                {
                alt1=3;
                }
                break;
            case 33:
                {
                alt1=4;
                }
                break;
            case 34:
                {
                alt1=5;
                }
                break;
            case 35:
                {
                alt1=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }

            switch (alt1) {
                case 1 :
                    // InternalQueryPro.g:353:2: ( ruleTelephone )
                    {
                    // InternalQueryPro.g:353:2: ( ruleTelephone )
                    // InternalQueryPro.g:354:3: ruleTelephone
                    {
                     before(grammarAccess.getKriteriaAccess().getTypeTelephoneParserRuleCall_0_0()); 
                    pushFollow(FOLLOW_2);
                    ruleTelephone();

                    state._fsp--;

                     after(grammarAccess.getKriteriaAccess().getTypeTelephoneParserRuleCall_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalQueryPro.g:359:2: ( ruleSMS )
                    {
                    // InternalQueryPro.g:359:2: ( ruleSMS )
                    // InternalQueryPro.g:360:3: ruleSMS
                    {
                     before(grammarAccess.getKriteriaAccess().getTypeSMSParserRuleCall_0_1()); 
                    pushFollow(FOLLOW_2);
                    ruleSMS();

                    state._fsp--;

                     after(grammarAccess.getKriteriaAccess().getTypeSMSParserRuleCall_0_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalQueryPro.g:365:2: ( ruleInternet )
                    {
                    // InternalQueryPro.g:365:2: ( ruleInternet )
                    // InternalQueryPro.g:366:3: ruleInternet
                    {
                     before(grammarAccess.getKriteriaAccess().getTypeInternetParserRuleCall_0_2()); 
                    pushFollow(FOLLOW_2);
                    ruleInternet();

                    state._fsp--;

                     after(grammarAccess.getKriteriaAccess().getTypeInternetParserRuleCall_0_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalQueryPro.g:371:2: ( ruleNet )
                    {
                    // InternalQueryPro.g:371:2: ( ruleNet )
                    // InternalQueryPro.g:372:3: ruleNet
                    {
                     before(grammarAccess.getKriteriaAccess().getTypeNetParserRuleCall_0_3()); 
                    pushFollow(FOLLOW_2);
                    ruleNet();

                    state._fsp--;

                     after(grammarAccess.getKriteriaAccess().getTypeNetParserRuleCall_0_3()); 

                    }


                    }
                    break;
                case 5 :
                    // InternalQueryPro.g:377:2: ( ruleFlexibilty )
                    {
                    // InternalQueryPro.g:377:2: ( ruleFlexibilty )
                    // InternalQueryPro.g:378:3: ruleFlexibilty
                    {
                     before(grammarAccess.getKriteriaAccess().getTypeFlexibiltyParserRuleCall_0_4()); 
                    pushFollow(FOLLOW_2);
                    ruleFlexibilty();

                    state._fsp--;

                     after(grammarAccess.getKriteriaAccess().getTypeFlexibiltyParserRuleCall_0_4()); 

                    }


                    }
                    break;
                case 6 :
                    // InternalQueryPro.g:383:2: ( rulePhone )
                    {
                    // InternalQueryPro.g:383:2: ( rulePhone )
                    // InternalQueryPro.g:384:3: rulePhone
                    {
                     before(grammarAccess.getKriteriaAccess().getTypePhoneParserRuleCall_0_5()); 
                    pushFollow(FOLLOW_2);
                    rulePhone();

                    state._fsp--;

                     after(grammarAccess.getKriteriaAccess().getTypePhoneParserRuleCall_0_5()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Kriteria__TypeAlternatives_0"


    // $ANTLR start "rule__Telephone__Alternatives_1"
    // InternalQueryPro.g:393:1: rule__Telephone__Alternatives_1 : ( ( ( rule__Telephone__ValueAssignment_1_0 ) ) | ( ( rule__Telephone__FreeminutesAssignment_1_1 ) ) );
    public final void rule__Telephone__Alternatives_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:397:1: ( ( ( rule__Telephone__ValueAssignment_1_0 ) ) | ( ( rule__Telephone__FreeminutesAssignment_1_1 ) ) )
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==15||(LA2_0>=18 && LA2_0<=19)) ) {
                alt2=1;
            }
            else if ( (LA2_0==RULE_INT) ) {
                alt2=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }
            switch (alt2) {
                case 1 :
                    // InternalQueryPro.g:398:2: ( ( rule__Telephone__ValueAssignment_1_0 ) )
                    {
                    // InternalQueryPro.g:398:2: ( ( rule__Telephone__ValueAssignment_1_0 ) )
                    // InternalQueryPro.g:399:3: ( rule__Telephone__ValueAssignment_1_0 )
                    {
                     before(grammarAccess.getTelephoneAccess().getValueAssignment_1_0()); 
                    // InternalQueryPro.g:400:3: ( rule__Telephone__ValueAssignment_1_0 )
                    // InternalQueryPro.g:400:4: rule__Telephone__ValueAssignment_1_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Telephone__ValueAssignment_1_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getTelephoneAccess().getValueAssignment_1_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalQueryPro.g:404:2: ( ( rule__Telephone__FreeminutesAssignment_1_1 ) )
                    {
                    // InternalQueryPro.g:404:2: ( ( rule__Telephone__FreeminutesAssignment_1_1 ) )
                    // InternalQueryPro.g:405:3: ( rule__Telephone__FreeminutesAssignment_1_1 )
                    {
                     before(grammarAccess.getTelephoneAccess().getFreeminutesAssignment_1_1()); 
                    // InternalQueryPro.g:406:3: ( rule__Telephone__FreeminutesAssignment_1_1 )
                    // InternalQueryPro.g:406:4: rule__Telephone__FreeminutesAssignment_1_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__Telephone__FreeminutesAssignment_1_1();

                    state._fsp--;


                    }

                     after(grammarAccess.getTelephoneAccess().getFreeminutesAssignment_1_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Telephone__Alternatives_1"


    // $ANTLR start "rule__SMS__Alternatives_1"
    // InternalQueryPro.g:414:1: rule__SMS__Alternatives_1 : ( ( ( rule__SMS__ValueAssignment_1_0 ) ) | ( ( rule__SMS__CostAssignment_1_1 ) ) );
    public final void rule__SMS__Alternatives_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:418:1: ( ( ( rule__SMS__ValueAssignment_1_0 ) ) | ( ( rule__SMS__CostAssignment_1_1 ) ) )
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==15||(LA3_0>=18 && LA3_0<=19)) ) {
                alt3=1;
            }
            else if ( (LA3_0==RULE_PRICE) ) {
                alt3=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }
            switch (alt3) {
                case 1 :
                    // InternalQueryPro.g:419:2: ( ( rule__SMS__ValueAssignment_1_0 ) )
                    {
                    // InternalQueryPro.g:419:2: ( ( rule__SMS__ValueAssignment_1_0 ) )
                    // InternalQueryPro.g:420:3: ( rule__SMS__ValueAssignment_1_0 )
                    {
                     before(grammarAccess.getSMSAccess().getValueAssignment_1_0()); 
                    // InternalQueryPro.g:421:3: ( rule__SMS__ValueAssignment_1_0 )
                    // InternalQueryPro.g:421:4: rule__SMS__ValueAssignment_1_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__SMS__ValueAssignment_1_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getSMSAccess().getValueAssignment_1_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalQueryPro.g:425:2: ( ( rule__SMS__CostAssignment_1_1 ) )
                    {
                    // InternalQueryPro.g:425:2: ( ( rule__SMS__CostAssignment_1_1 ) )
                    // InternalQueryPro.g:426:3: ( rule__SMS__CostAssignment_1_1 )
                    {
                     before(grammarAccess.getSMSAccess().getCostAssignment_1_1()); 
                    // InternalQueryPro.g:427:3: ( rule__SMS__CostAssignment_1_1 )
                    // InternalQueryPro.g:427:4: rule__SMS__CostAssignment_1_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__SMS__CostAssignment_1_1();

                    state._fsp--;


                    }

                     after(grammarAccess.getSMSAccess().getCostAssignment_1_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SMS__Alternatives_1"


    // $ANTLR start "rule__Internet__Alternatives_1"
    // InternalQueryPro.g:435:1: rule__Internet__Alternatives_1 : ( ( ( rule__Internet__ValueAssignment_1_0 ) ) | ( ( rule__Internet__Alternatives_1_1 )* ) );
    public final void rule__Internet__Alternatives_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:439:1: ( ( ( rule__Internet__ValueAssignment_1_0 ) ) | ( ( rule__Internet__Alternatives_1_1 )* ) )
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==15||(LA5_0>=18 && LA5_0<=19)) ) {
                alt5=1;
            }
            else if ( (LA5_0==EOF||LA5_0==RULE_INT||(LA5_0>=28 && LA5_0<=30)||(LA5_0>=33 && LA5_0<=35)) ) {
                alt5=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }
            switch (alt5) {
                case 1 :
                    // InternalQueryPro.g:440:2: ( ( rule__Internet__ValueAssignment_1_0 ) )
                    {
                    // InternalQueryPro.g:440:2: ( ( rule__Internet__ValueAssignment_1_0 ) )
                    // InternalQueryPro.g:441:3: ( rule__Internet__ValueAssignment_1_0 )
                    {
                     before(grammarAccess.getInternetAccess().getValueAssignment_1_0()); 
                    // InternalQueryPro.g:442:3: ( rule__Internet__ValueAssignment_1_0 )
                    // InternalQueryPro.g:442:4: rule__Internet__ValueAssignment_1_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Internet__ValueAssignment_1_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getInternetAccess().getValueAssignment_1_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalQueryPro.g:446:2: ( ( rule__Internet__Alternatives_1_1 )* )
                    {
                    // InternalQueryPro.g:446:2: ( ( rule__Internet__Alternatives_1_1 )* )
                    // InternalQueryPro.g:447:3: ( rule__Internet__Alternatives_1_1 )*
                    {
                     before(grammarAccess.getInternetAccess().getAlternatives_1_1()); 
                    // InternalQueryPro.g:448:3: ( rule__Internet__Alternatives_1_1 )*
                    loop4:
                    do {
                        int alt4=2;
                        int LA4_0 = input.LA(1);

                        if ( (LA4_0==RULE_INT) ) {
                            alt4=1;
                        }


                        switch (alt4) {
                    	case 1 :
                    	    // InternalQueryPro.g:448:4: rule__Internet__Alternatives_1_1
                    	    {
                    	    pushFollow(FOLLOW_3);
                    	    rule__Internet__Alternatives_1_1();

                    	    state._fsp--;


                    	    }
                    	    break;

                    	default :
                    	    break loop4;
                        }
                    } while (true);

                     after(grammarAccess.getInternetAccess().getAlternatives_1_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Internet__Alternatives_1"


    // $ANTLR start "rule__Internet__Alternatives_1_1"
    // InternalQueryPro.g:456:1: rule__Internet__Alternatives_1_1 : ( ( ( rule__Internet__Group_1_1_0__0 ) ) | ( ( rule__Internet__Group_1_1_1__0 ) ) );
    public final void rule__Internet__Alternatives_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:460:1: ( ( ( rule__Internet__Group_1_1_0__0 ) ) | ( ( rule__Internet__Group_1_1_1__0 ) ) )
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==RULE_INT) ) {
                int LA6_1 = input.LA(2);

                if ( (LA6_1==31) ) {
                    alt6=1;
                }
                else if ( (LA6_1==32) ) {
                    alt6=2;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 6, 1, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }
            switch (alt6) {
                case 1 :
                    // InternalQueryPro.g:461:2: ( ( rule__Internet__Group_1_1_0__0 ) )
                    {
                    // InternalQueryPro.g:461:2: ( ( rule__Internet__Group_1_1_0__0 ) )
                    // InternalQueryPro.g:462:3: ( rule__Internet__Group_1_1_0__0 )
                    {
                     before(grammarAccess.getInternetAccess().getGroup_1_1_0()); 
                    // InternalQueryPro.g:463:3: ( rule__Internet__Group_1_1_0__0 )
                    // InternalQueryPro.g:463:4: rule__Internet__Group_1_1_0__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Internet__Group_1_1_0__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getInternetAccess().getGroup_1_1_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalQueryPro.g:467:2: ( ( rule__Internet__Group_1_1_1__0 ) )
                    {
                    // InternalQueryPro.g:467:2: ( ( rule__Internet__Group_1_1_1__0 ) )
                    // InternalQueryPro.g:468:3: ( rule__Internet__Group_1_1_1__0 )
                    {
                     before(grammarAccess.getInternetAccess().getGroup_1_1_1()); 
                    // InternalQueryPro.g:469:3: ( rule__Internet__Group_1_1_1__0 )
                    // InternalQueryPro.g:469:4: rule__Internet__Group_1_1_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Internet__Group_1_1_1__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getInternetAccess().getGroup_1_1_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Internet__Alternatives_1_1"


    // $ANTLR start "rule__Net__Alternatives_1"
    // InternalQueryPro.g:477:1: rule__Net__Alternatives_1 : ( ( ( rule__Net__ValueAssignment_1_0 ) ) | ( ( rule__Net__NetAssignment_1_1 ) ) );
    public final void rule__Net__Alternatives_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:481:1: ( ( ( rule__Net__ValueAssignment_1_0 ) ) | ( ( rule__Net__NetAssignment_1_1 ) ) )
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==15||(LA7_0>=20 && LA7_0<=21)) ) {
                alt7=1;
            }
            else if ( ((LA7_0>=12 && LA7_0<=14)) ) {
                alt7=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 7, 0, input);

                throw nvae;
            }
            switch (alt7) {
                case 1 :
                    // InternalQueryPro.g:482:2: ( ( rule__Net__ValueAssignment_1_0 ) )
                    {
                    // InternalQueryPro.g:482:2: ( ( rule__Net__ValueAssignment_1_0 ) )
                    // InternalQueryPro.g:483:3: ( rule__Net__ValueAssignment_1_0 )
                    {
                     before(grammarAccess.getNetAccess().getValueAssignment_1_0()); 
                    // InternalQueryPro.g:484:3: ( rule__Net__ValueAssignment_1_0 )
                    // InternalQueryPro.g:484:4: rule__Net__ValueAssignment_1_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Net__ValueAssignment_1_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getNetAccess().getValueAssignment_1_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalQueryPro.g:488:2: ( ( rule__Net__NetAssignment_1_1 ) )
                    {
                    // InternalQueryPro.g:488:2: ( ( rule__Net__NetAssignment_1_1 ) )
                    // InternalQueryPro.g:489:3: ( rule__Net__NetAssignment_1_1 )
                    {
                     before(grammarAccess.getNetAccess().getNetAssignment_1_1()); 
                    // InternalQueryPro.g:490:3: ( rule__Net__NetAssignment_1_1 )
                    // InternalQueryPro.g:490:4: rule__Net__NetAssignment_1_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__Net__NetAssignment_1_1();

                    state._fsp--;


                    }

                     after(grammarAccess.getNetAccess().getNetAssignment_1_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Net__Alternatives_1"


    // $ANTLR start "rule__Flexibilty__Alternatives_1"
    // InternalQueryPro.g:498:1: rule__Flexibilty__Alternatives_1 : ( ( ( rule__Flexibilty__ValueAssignment_1_0 ) ) | ( ( rule__Flexibilty__MonthsAssignment_1_1 ) ) );
    public final void rule__Flexibilty__Alternatives_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:502:1: ( ( ( rule__Flexibilty__ValueAssignment_1_0 ) ) | ( ( rule__Flexibilty__MonthsAssignment_1_1 ) ) )
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==15||LA8_0==20||(LA8_0>=22 && LA8_0<=23)) ) {
                alt8=1;
            }
            else if ( (LA8_0==RULE_INT) ) {
                alt8=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 8, 0, input);

                throw nvae;
            }
            switch (alt8) {
                case 1 :
                    // InternalQueryPro.g:503:2: ( ( rule__Flexibilty__ValueAssignment_1_0 ) )
                    {
                    // InternalQueryPro.g:503:2: ( ( rule__Flexibilty__ValueAssignment_1_0 ) )
                    // InternalQueryPro.g:504:3: ( rule__Flexibilty__ValueAssignment_1_0 )
                    {
                     before(grammarAccess.getFlexibiltyAccess().getValueAssignment_1_0()); 
                    // InternalQueryPro.g:505:3: ( rule__Flexibilty__ValueAssignment_1_0 )
                    // InternalQueryPro.g:505:4: rule__Flexibilty__ValueAssignment_1_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Flexibilty__ValueAssignment_1_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getFlexibiltyAccess().getValueAssignment_1_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalQueryPro.g:509:2: ( ( rule__Flexibilty__MonthsAssignment_1_1 ) )
                    {
                    // InternalQueryPro.g:509:2: ( ( rule__Flexibilty__MonthsAssignment_1_1 ) )
                    // InternalQueryPro.g:510:3: ( rule__Flexibilty__MonthsAssignment_1_1 )
                    {
                     before(grammarAccess.getFlexibiltyAccess().getMonthsAssignment_1_1()); 
                    // InternalQueryPro.g:511:3: ( rule__Flexibilty__MonthsAssignment_1_1 )
                    // InternalQueryPro.g:511:4: rule__Flexibilty__MonthsAssignment_1_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__Flexibilty__MonthsAssignment_1_1();

                    state._fsp--;


                    }

                     after(grammarAccess.getFlexibiltyAccess().getMonthsAssignment_1_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Flexibilty__Alternatives_1"


    // $ANTLR start "rule__Phone__Alternatives_1"
    // InternalQueryPro.g:519:1: rule__Phone__Alternatives_1 : ( ( ( rule__Phone__Group_1_0__0 ) ) | ( ( rule__Phone__Group_1_1__0 ) ) | ( ( rule__Phone__Group_1_2__0 ) ) );
    public final void rule__Phone__Alternatives_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:523:1: ( ( ( rule__Phone__Group_1_0__0 ) ) | ( ( rule__Phone__Group_1_1__0 ) ) | ( ( rule__Phone__Group_1_2__0 ) ) )
            int alt9=3;
            switch ( input.LA(1) ) {
            case 36:
                {
                alt9=1;
                }
                break;
            case 37:
                {
                alt9=2;
                }
                break;
            case 38:
                {
                alt9=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 9, 0, input);

                throw nvae;
            }

            switch (alt9) {
                case 1 :
                    // InternalQueryPro.g:524:2: ( ( rule__Phone__Group_1_0__0 ) )
                    {
                    // InternalQueryPro.g:524:2: ( ( rule__Phone__Group_1_0__0 ) )
                    // InternalQueryPro.g:525:3: ( rule__Phone__Group_1_0__0 )
                    {
                     before(grammarAccess.getPhoneAccess().getGroup_1_0()); 
                    // InternalQueryPro.g:526:3: ( rule__Phone__Group_1_0__0 )
                    // InternalQueryPro.g:526:4: rule__Phone__Group_1_0__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Phone__Group_1_0__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getPhoneAccess().getGroup_1_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalQueryPro.g:530:2: ( ( rule__Phone__Group_1_1__0 ) )
                    {
                    // InternalQueryPro.g:530:2: ( ( rule__Phone__Group_1_1__0 ) )
                    // InternalQueryPro.g:531:3: ( rule__Phone__Group_1_1__0 )
                    {
                     before(grammarAccess.getPhoneAccess().getGroup_1_1()); 
                    // InternalQueryPro.g:532:3: ( rule__Phone__Group_1_1__0 )
                    // InternalQueryPro.g:532:4: rule__Phone__Group_1_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Phone__Group_1_1__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getPhoneAccess().getGroup_1_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalQueryPro.g:536:2: ( ( rule__Phone__Group_1_2__0 ) )
                    {
                    // InternalQueryPro.g:536:2: ( ( rule__Phone__Group_1_2__0 ) )
                    // InternalQueryPro.g:537:3: ( rule__Phone__Group_1_2__0 )
                    {
                     before(grammarAccess.getPhoneAccess().getGroup_1_2()); 
                    // InternalQueryPro.g:538:3: ( rule__Phone__Group_1_2__0 )
                    // InternalQueryPro.g:538:4: rule__Phone__Group_1_2__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Phone__Group_1_2__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getPhoneAccess().getGroup_1_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Phone__Alternatives_1"


    // $ANTLR start "rule__Netzanbieter__Alternatives"
    // InternalQueryPro.g:546:1: rule__Netzanbieter__Alternatives : ( ( ( 'O2' ) ) | ( ( 'TELEKOM' ) ) | ( ( 'VODAFON' ) ) );
    public final void rule__Netzanbieter__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:550:1: ( ( ( 'O2' ) ) | ( ( 'TELEKOM' ) ) | ( ( 'VODAFON' ) ) )
            int alt10=3;
            switch ( input.LA(1) ) {
            case 12:
                {
                alt10=1;
                }
                break;
            case 13:
                {
                alt10=2;
                }
                break;
            case 14:
                {
                alt10=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 10, 0, input);

                throw nvae;
            }

            switch (alt10) {
                case 1 :
                    // InternalQueryPro.g:551:2: ( ( 'O2' ) )
                    {
                    // InternalQueryPro.g:551:2: ( ( 'O2' ) )
                    // InternalQueryPro.g:552:3: ( 'O2' )
                    {
                     before(grammarAccess.getNetzanbieterAccess().getO2EnumLiteralDeclaration_0()); 
                    // InternalQueryPro.g:553:3: ( 'O2' )
                    // InternalQueryPro.g:553:4: 'O2'
                    {
                    match(input,12,FOLLOW_2); 

                    }

                     after(grammarAccess.getNetzanbieterAccess().getO2EnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalQueryPro.g:557:2: ( ( 'TELEKOM' ) )
                    {
                    // InternalQueryPro.g:557:2: ( ( 'TELEKOM' ) )
                    // InternalQueryPro.g:558:3: ( 'TELEKOM' )
                    {
                     before(grammarAccess.getNetzanbieterAccess().getTELEKOMEnumLiteralDeclaration_1()); 
                    // InternalQueryPro.g:559:3: ( 'TELEKOM' )
                    // InternalQueryPro.g:559:4: 'TELEKOM'
                    {
                    match(input,13,FOLLOW_2); 

                    }

                     after(grammarAccess.getNetzanbieterAccess().getTELEKOMEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalQueryPro.g:563:2: ( ( 'VODAFON' ) )
                    {
                    // InternalQueryPro.g:563:2: ( ( 'VODAFON' ) )
                    // InternalQueryPro.g:564:3: ( 'VODAFON' )
                    {
                     before(grammarAccess.getNetzanbieterAccess().getVODAFONEnumLiteralDeclaration_2()); 
                    // InternalQueryPro.g:565:3: ( 'VODAFON' )
                    // InternalQueryPro.g:565:4: 'VODAFON'
                    {
                    match(input,14,FOLLOW_2); 

                    }

                     after(grammarAccess.getNetzanbieterAccess().getVODAFONEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Netzanbieter__Alternatives"


    // $ANTLR start "rule__Betriebssystem__Alternatives"
    // InternalQueryPro.g:573:1: rule__Betriebssystem__Alternatives : ( ( ( 'egal' ) ) | ( ( 'ANDROID' ) ) | ( ( 'IOS' ) ) );
    public final void rule__Betriebssystem__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:577:1: ( ( ( 'egal' ) ) | ( ( 'ANDROID' ) ) | ( ( 'IOS' ) ) )
            int alt11=3;
            switch ( input.LA(1) ) {
            case 15:
                {
                alt11=1;
                }
                break;
            case 16:
                {
                alt11=2;
                }
                break;
            case 17:
                {
                alt11=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 11, 0, input);

                throw nvae;
            }

            switch (alt11) {
                case 1 :
                    // InternalQueryPro.g:578:2: ( ( 'egal' ) )
                    {
                    // InternalQueryPro.g:578:2: ( ( 'egal' ) )
                    // InternalQueryPro.g:579:3: ( 'egal' )
                    {
                     before(grammarAccess.getBetriebssystemAccess().getEgalEnumLiteralDeclaration_0()); 
                    // InternalQueryPro.g:580:3: ( 'egal' )
                    // InternalQueryPro.g:580:4: 'egal'
                    {
                    match(input,15,FOLLOW_2); 

                    }

                     after(grammarAccess.getBetriebssystemAccess().getEgalEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalQueryPro.g:584:2: ( ( 'ANDROID' ) )
                    {
                    // InternalQueryPro.g:584:2: ( ( 'ANDROID' ) )
                    // InternalQueryPro.g:585:3: ( 'ANDROID' )
                    {
                     before(grammarAccess.getBetriebssystemAccess().getANDROIDEnumLiteralDeclaration_1()); 
                    // InternalQueryPro.g:586:3: ( 'ANDROID' )
                    // InternalQueryPro.g:586:4: 'ANDROID'
                    {
                    match(input,16,FOLLOW_2); 

                    }

                     after(grammarAccess.getBetriebssystemAccess().getANDROIDEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalQueryPro.g:590:2: ( ( 'IOS' ) )
                    {
                    // InternalQueryPro.g:590:2: ( ( 'IOS' ) )
                    // InternalQueryPro.g:591:3: ( 'IOS' )
                    {
                     before(grammarAccess.getBetriebssystemAccess().getIOSEnumLiteralDeclaration_2()); 
                    // InternalQueryPro.g:592:3: ( 'IOS' )
                    // InternalQueryPro.g:592:4: 'IOS'
                    {
                    match(input,17,FOLLOW_2); 

                    }

                     after(grammarAccess.getBetriebssystemAccess().getIOSEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Betriebssystem__Alternatives"


    // $ANTLR start "rule__Intensitaet__Alternatives"
    // InternalQueryPro.g:600:1: rule__Intensitaet__Alternatives : ( ( ( 'egal' ) ) | ( ( 'wenig' ) ) | ( ( 'viel' ) ) );
    public final void rule__Intensitaet__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:604:1: ( ( ( 'egal' ) ) | ( ( 'wenig' ) ) | ( ( 'viel' ) ) )
            int alt12=3;
            switch ( input.LA(1) ) {
            case 15:
                {
                alt12=1;
                }
                break;
            case 18:
                {
                alt12=2;
                }
                break;
            case 19:
                {
                alt12=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 12, 0, input);

                throw nvae;
            }

            switch (alt12) {
                case 1 :
                    // InternalQueryPro.g:605:2: ( ( 'egal' ) )
                    {
                    // InternalQueryPro.g:605:2: ( ( 'egal' ) )
                    // InternalQueryPro.g:606:3: ( 'egal' )
                    {
                     before(grammarAccess.getIntensitaetAccess().getEgalEnumLiteralDeclaration_0()); 
                    // InternalQueryPro.g:607:3: ( 'egal' )
                    // InternalQueryPro.g:607:4: 'egal'
                    {
                    match(input,15,FOLLOW_2); 

                    }

                     after(grammarAccess.getIntensitaetAccess().getEgalEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalQueryPro.g:611:2: ( ( 'wenig' ) )
                    {
                    // InternalQueryPro.g:611:2: ( ( 'wenig' ) )
                    // InternalQueryPro.g:612:3: ( 'wenig' )
                    {
                     before(grammarAccess.getIntensitaetAccess().getWenigEnumLiteralDeclaration_1()); 
                    // InternalQueryPro.g:613:3: ( 'wenig' )
                    // InternalQueryPro.g:613:4: 'wenig'
                    {
                    match(input,18,FOLLOW_2); 

                    }

                     after(grammarAccess.getIntensitaetAccess().getWenigEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalQueryPro.g:617:2: ( ( 'viel' ) )
                    {
                    // InternalQueryPro.g:617:2: ( ( 'viel' ) )
                    // InternalQueryPro.g:618:3: ( 'viel' )
                    {
                     before(grammarAccess.getIntensitaetAccess().getVielEnumLiteralDeclaration_2()); 
                    // InternalQueryPro.g:619:3: ( 'viel' )
                    // InternalQueryPro.g:619:4: 'viel'
                    {
                    match(input,19,FOLLOW_2); 

                    }

                     after(grammarAccess.getIntensitaetAccess().getVielEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Intensitaet__Alternatives"


    // $ANTLR start "rule__Netzverbreitung__Alternatives"
    // InternalQueryPro.g:627:1: rule__Netzverbreitung__Alternatives : ( ( ( 'egal' ) ) | ( ( 'normal' ) ) | ( ( 'gut' ) ) );
    public final void rule__Netzverbreitung__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:631:1: ( ( ( 'egal' ) ) | ( ( 'normal' ) ) | ( ( 'gut' ) ) )
            int alt13=3;
            switch ( input.LA(1) ) {
            case 15:
                {
                alt13=1;
                }
                break;
            case 20:
                {
                alt13=2;
                }
                break;
            case 21:
                {
                alt13=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 13, 0, input);

                throw nvae;
            }

            switch (alt13) {
                case 1 :
                    // InternalQueryPro.g:632:2: ( ( 'egal' ) )
                    {
                    // InternalQueryPro.g:632:2: ( ( 'egal' ) )
                    // InternalQueryPro.g:633:3: ( 'egal' )
                    {
                     before(grammarAccess.getNetzverbreitungAccess().getEgalEnumLiteralDeclaration_0()); 
                    // InternalQueryPro.g:634:3: ( 'egal' )
                    // InternalQueryPro.g:634:4: 'egal'
                    {
                    match(input,15,FOLLOW_2); 

                    }

                     after(grammarAccess.getNetzverbreitungAccess().getEgalEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalQueryPro.g:638:2: ( ( 'normal' ) )
                    {
                    // InternalQueryPro.g:638:2: ( ( 'normal' ) )
                    // InternalQueryPro.g:639:3: ( 'normal' )
                    {
                     before(grammarAccess.getNetzverbreitungAccess().getNormalEnumLiteralDeclaration_1()); 
                    // InternalQueryPro.g:640:3: ( 'normal' )
                    // InternalQueryPro.g:640:4: 'normal'
                    {
                    match(input,20,FOLLOW_2); 

                    }

                     after(grammarAccess.getNetzverbreitungAccess().getNormalEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalQueryPro.g:644:2: ( ( 'gut' ) )
                    {
                    // InternalQueryPro.g:644:2: ( ( 'gut' ) )
                    // InternalQueryPro.g:645:3: ( 'gut' )
                    {
                     before(grammarAccess.getNetzverbreitungAccess().getGutEnumLiteralDeclaration_2()); 
                    // InternalQueryPro.g:646:3: ( 'gut' )
                    // InternalQueryPro.g:646:4: 'gut'
                    {
                    match(input,21,FOLLOW_2); 

                    }

                     after(grammarAccess.getNetzverbreitungAccess().getGutEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Netzverbreitung__Alternatives"


    // $ANTLR start "rule__Vertragskondition__Alternatives"
    // InternalQueryPro.g:654:1: rule__Vertragskondition__Alternatives : ( ( ( 'egal' ) ) | ( ( 'kurz' ) ) | ( ( 'flexibel' ) ) | ( ( 'normal' ) ) );
    public final void rule__Vertragskondition__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:658:1: ( ( ( 'egal' ) ) | ( ( 'kurz' ) ) | ( ( 'flexibel' ) ) | ( ( 'normal' ) ) )
            int alt14=4;
            switch ( input.LA(1) ) {
            case 15:
                {
                alt14=1;
                }
                break;
            case 22:
                {
                alt14=2;
                }
                break;
            case 23:
                {
                alt14=3;
                }
                break;
            case 20:
                {
                alt14=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 14, 0, input);

                throw nvae;
            }

            switch (alt14) {
                case 1 :
                    // InternalQueryPro.g:659:2: ( ( 'egal' ) )
                    {
                    // InternalQueryPro.g:659:2: ( ( 'egal' ) )
                    // InternalQueryPro.g:660:3: ( 'egal' )
                    {
                     before(grammarAccess.getVertragskonditionAccess().getEgalEnumLiteralDeclaration_0()); 
                    // InternalQueryPro.g:661:3: ( 'egal' )
                    // InternalQueryPro.g:661:4: 'egal'
                    {
                    match(input,15,FOLLOW_2); 

                    }

                     after(grammarAccess.getVertragskonditionAccess().getEgalEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalQueryPro.g:665:2: ( ( 'kurz' ) )
                    {
                    // InternalQueryPro.g:665:2: ( ( 'kurz' ) )
                    // InternalQueryPro.g:666:3: ( 'kurz' )
                    {
                     before(grammarAccess.getVertragskonditionAccess().getKurzEnumLiteralDeclaration_1()); 
                    // InternalQueryPro.g:667:3: ( 'kurz' )
                    // InternalQueryPro.g:667:4: 'kurz'
                    {
                    match(input,22,FOLLOW_2); 

                    }

                     after(grammarAccess.getVertragskonditionAccess().getKurzEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalQueryPro.g:671:2: ( ( 'flexibel' ) )
                    {
                    // InternalQueryPro.g:671:2: ( ( 'flexibel' ) )
                    // InternalQueryPro.g:672:3: ( 'flexibel' )
                    {
                     before(grammarAccess.getVertragskonditionAccess().getFlexibelEnumLiteralDeclaration_2()); 
                    // InternalQueryPro.g:673:3: ( 'flexibel' )
                    // InternalQueryPro.g:673:4: 'flexibel'
                    {
                    match(input,23,FOLLOW_2); 

                    }

                     after(grammarAccess.getVertragskonditionAccess().getFlexibelEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalQueryPro.g:677:2: ( ( 'normal' ) )
                    {
                    // InternalQueryPro.g:677:2: ( ( 'normal' ) )
                    // InternalQueryPro.g:678:3: ( 'normal' )
                    {
                     before(grammarAccess.getVertragskonditionAccess().getNormalEnumLiteralDeclaration_3()); 
                    // InternalQueryPro.g:679:3: ( 'normal' )
                    // InternalQueryPro.g:679:4: 'normal'
                    {
                    match(input,20,FOLLOW_2); 

                    }

                     after(grammarAccess.getVertragskonditionAccess().getNormalEnumLiteralDeclaration_3()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Vertragskondition__Alternatives"


    // $ANTLR start "rule__Marke__Alternatives"
    // InternalQueryPro.g:687:1: rule__Marke__Alternatives : ( ( ( 'egal' ) ) | ( ( 'SAMSUNG' ) ) | ( ( 'IPHONE' ) ) | ( ( 'NOKIA' ) ) );
    public final void rule__Marke__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:691:1: ( ( ( 'egal' ) ) | ( ( 'SAMSUNG' ) ) | ( ( 'IPHONE' ) ) | ( ( 'NOKIA' ) ) )
            int alt15=4;
            switch ( input.LA(1) ) {
            case 15:
                {
                alt15=1;
                }
                break;
            case 24:
                {
                alt15=2;
                }
                break;
            case 25:
                {
                alt15=3;
                }
                break;
            case 26:
                {
                alt15=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 15, 0, input);

                throw nvae;
            }

            switch (alt15) {
                case 1 :
                    // InternalQueryPro.g:692:2: ( ( 'egal' ) )
                    {
                    // InternalQueryPro.g:692:2: ( ( 'egal' ) )
                    // InternalQueryPro.g:693:3: ( 'egal' )
                    {
                     before(grammarAccess.getMarkeAccess().getEgalEnumLiteralDeclaration_0()); 
                    // InternalQueryPro.g:694:3: ( 'egal' )
                    // InternalQueryPro.g:694:4: 'egal'
                    {
                    match(input,15,FOLLOW_2); 

                    }

                     after(grammarAccess.getMarkeAccess().getEgalEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalQueryPro.g:698:2: ( ( 'SAMSUNG' ) )
                    {
                    // InternalQueryPro.g:698:2: ( ( 'SAMSUNG' ) )
                    // InternalQueryPro.g:699:3: ( 'SAMSUNG' )
                    {
                     before(grammarAccess.getMarkeAccess().getSAMSUNGEnumLiteralDeclaration_1()); 
                    // InternalQueryPro.g:700:3: ( 'SAMSUNG' )
                    // InternalQueryPro.g:700:4: 'SAMSUNG'
                    {
                    match(input,24,FOLLOW_2); 

                    }

                     after(grammarAccess.getMarkeAccess().getSAMSUNGEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalQueryPro.g:704:2: ( ( 'IPHONE' ) )
                    {
                    // InternalQueryPro.g:704:2: ( ( 'IPHONE' ) )
                    // InternalQueryPro.g:705:3: ( 'IPHONE' )
                    {
                     before(grammarAccess.getMarkeAccess().getIPHONEEnumLiteralDeclaration_2()); 
                    // InternalQueryPro.g:706:3: ( 'IPHONE' )
                    // InternalQueryPro.g:706:4: 'IPHONE'
                    {
                    match(input,25,FOLLOW_2); 

                    }

                     after(grammarAccess.getMarkeAccess().getIPHONEEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalQueryPro.g:710:2: ( ( 'NOKIA' ) )
                    {
                    // InternalQueryPro.g:710:2: ( ( 'NOKIA' ) )
                    // InternalQueryPro.g:711:3: ( 'NOKIA' )
                    {
                     before(grammarAccess.getMarkeAccess().getNOKIAEnumLiteralDeclaration_3()); 
                    // InternalQueryPro.g:712:3: ( 'NOKIA' )
                    // InternalQueryPro.g:712:4: 'NOKIA'
                    {
                    match(input,26,FOLLOW_2); 

                    }

                     after(grammarAccess.getMarkeAccess().getNOKIAEnumLiteralDeclaration_3()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Marke__Alternatives"


    // $ANTLR start "rule__Query__Group__0"
    // InternalQueryPro.g:720:1: rule__Query__Group__0 : rule__Query__Group__0__Impl rule__Query__Group__1 ;
    public final void rule__Query__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:724:1: ( rule__Query__Group__0__Impl rule__Query__Group__1 )
            // InternalQueryPro.g:725:2: rule__Query__Group__0__Impl rule__Query__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__Query__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Query__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Query__Group__0"


    // $ANTLR start "rule__Query__Group__0__Impl"
    // InternalQueryPro.g:732:1: rule__Query__Group__0__Impl : ( 'SUCHE' ) ;
    public final void rule__Query__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:736:1: ( ( 'SUCHE' ) )
            // InternalQueryPro.g:737:1: ( 'SUCHE' )
            {
            // InternalQueryPro.g:737:1: ( 'SUCHE' )
            // InternalQueryPro.g:738:2: 'SUCHE'
            {
             before(grammarAccess.getQueryAccess().getSUCHEKeyword_0()); 
            match(input,27,FOLLOW_2); 
             after(grammarAccess.getQueryAccess().getSUCHEKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Query__Group__0__Impl"


    // $ANTLR start "rule__Query__Group__1"
    // InternalQueryPro.g:747:1: rule__Query__Group__1 : rule__Query__Group__1__Impl rule__Query__Group__2 ;
    public final void rule__Query__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:751:1: ( rule__Query__Group__1__Impl rule__Query__Group__2 )
            // InternalQueryPro.g:752:2: rule__Query__Group__1__Impl rule__Query__Group__2
            {
            pushFollow(FOLLOW_5);
            rule__Query__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Query__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Query__Group__1"


    // $ANTLR start "rule__Query__Group__1__Impl"
    // InternalQueryPro.g:759:1: rule__Query__Group__1__Impl : ( ( rule__Query__AmountAssignment_1 ) ) ;
    public final void rule__Query__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:763:1: ( ( ( rule__Query__AmountAssignment_1 ) ) )
            // InternalQueryPro.g:764:1: ( ( rule__Query__AmountAssignment_1 ) )
            {
            // InternalQueryPro.g:764:1: ( ( rule__Query__AmountAssignment_1 ) )
            // InternalQueryPro.g:765:2: ( rule__Query__AmountAssignment_1 )
            {
             before(grammarAccess.getQueryAccess().getAmountAssignment_1()); 
            // InternalQueryPro.g:766:2: ( rule__Query__AmountAssignment_1 )
            // InternalQueryPro.g:766:3: rule__Query__AmountAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Query__AmountAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getQueryAccess().getAmountAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Query__Group__1__Impl"


    // $ANTLR start "rule__Query__Group__2"
    // InternalQueryPro.g:774:1: rule__Query__Group__2 : rule__Query__Group__2__Impl ;
    public final void rule__Query__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:778:1: ( rule__Query__Group__2__Impl )
            // InternalQueryPro.g:779:2: rule__Query__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Query__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Query__Group__2"


    // $ANTLR start "rule__Query__Group__2__Impl"
    // InternalQueryPro.g:785:1: rule__Query__Group__2__Impl : ( ( rule__Query__KritsAssignment_2 )* ) ;
    public final void rule__Query__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:789:1: ( ( ( rule__Query__KritsAssignment_2 )* ) )
            // InternalQueryPro.g:790:1: ( ( rule__Query__KritsAssignment_2 )* )
            {
            // InternalQueryPro.g:790:1: ( ( rule__Query__KritsAssignment_2 )* )
            // InternalQueryPro.g:791:2: ( rule__Query__KritsAssignment_2 )*
            {
             before(grammarAccess.getQueryAccess().getKritsAssignment_2()); 
            // InternalQueryPro.g:792:2: ( rule__Query__KritsAssignment_2 )*
            loop16:
            do {
                int alt16=2;
                int LA16_0 = input.LA(1);

                if ( ((LA16_0>=28 && LA16_0<=30)||(LA16_0>=33 && LA16_0<=35)) ) {
                    alt16=1;
                }


                switch (alt16) {
            	case 1 :
            	    // InternalQueryPro.g:792:3: rule__Query__KritsAssignment_2
            	    {
            	    pushFollow(FOLLOW_6);
            	    rule__Query__KritsAssignment_2();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop16;
                }
            } while (true);

             after(grammarAccess.getQueryAccess().getKritsAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Query__Group__2__Impl"


    // $ANTLR start "rule__Telephone__Group__0"
    // InternalQueryPro.g:801:1: rule__Telephone__Group__0 : rule__Telephone__Group__0__Impl rule__Telephone__Group__1 ;
    public final void rule__Telephone__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:805:1: ( rule__Telephone__Group__0__Impl rule__Telephone__Group__1 )
            // InternalQueryPro.g:806:2: rule__Telephone__Group__0__Impl rule__Telephone__Group__1
            {
            pushFollow(FOLLOW_7);
            rule__Telephone__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Telephone__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Telephone__Group__0"


    // $ANTLR start "rule__Telephone__Group__0__Impl"
    // InternalQueryPro.g:813:1: rule__Telephone__Group__0__Impl : ( 'TELEFONIERE' ) ;
    public final void rule__Telephone__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:817:1: ( ( 'TELEFONIERE' ) )
            // InternalQueryPro.g:818:1: ( 'TELEFONIERE' )
            {
            // InternalQueryPro.g:818:1: ( 'TELEFONIERE' )
            // InternalQueryPro.g:819:2: 'TELEFONIERE'
            {
             before(grammarAccess.getTelephoneAccess().getTELEFONIEREKeyword_0()); 
            match(input,28,FOLLOW_2); 
             after(grammarAccess.getTelephoneAccess().getTELEFONIEREKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Telephone__Group__0__Impl"


    // $ANTLR start "rule__Telephone__Group__1"
    // InternalQueryPro.g:828:1: rule__Telephone__Group__1 : rule__Telephone__Group__1__Impl ;
    public final void rule__Telephone__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:832:1: ( rule__Telephone__Group__1__Impl )
            // InternalQueryPro.g:833:2: rule__Telephone__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Telephone__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Telephone__Group__1"


    // $ANTLR start "rule__Telephone__Group__1__Impl"
    // InternalQueryPro.g:839:1: rule__Telephone__Group__1__Impl : ( ( rule__Telephone__Alternatives_1 ) ) ;
    public final void rule__Telephone__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:843:1: ( ( ( rule__Telephone__Alternatives_1 ) ) )
            // InternalQueryPro.g:844:1: ( ( rule__Telephone__Alternatives_1 ) )
            {
            // InternalQueryPro.g:844:1: ( ( rule__Telephone__Alternatives_1 ) )
            // InternalQueryPro.g:845:2: ( rule__Telephone__Alternatives_1 )
            {
             before(grammarAccess.getTelephoneAccess().getAlternatives_1()); 
            // InternalQueryPro.g:846:2: ( rule__Telephone__Alternatives_1 )
            // InternalQueryPro.g:846:3: rule__Telephone__Alternatives_1
            {
            pushFollow(FOLLOW_2);
            rule__Telephone__Alternatives_1();

            state._fsp--;


            }

             after(grammarAccess.getTelephoneAccess().getAlternatives_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Telephone__Group__1__Impl"


    // $ANTLR start "rule__SMS__Group__0"
    // InternalQueryPro.g:855:1: rule__SMS__Group__0 : rule__SMS__Group__0__Impl rule__SMS__Group__1 ;
    public final void rule__SMS__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:859:1: ( rule__SMS__Group__0__Impl rule__SMS__Group__1 )
            // InternalQueryPro.g:860:2: rule__SMS__Group__0__Impl rule__SMS__Group__1
            {
            pushFollow(FOLLOW_8);
            rule__SMS__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SMS__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SMS__Group__0"


    // $ANTLR start "rule__SMS__Group__0__Impl"
    // InternalQueryPro.g:867:1: rule__SMS__Group__0__Impl : ( 'SMS' ) ;
    public final void rule__SMS__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:871:1: ( ( 'SMS' ) )
            // InternalQueryPro.g:872:1: ( 'SMS' )
            {
            // InternalQueryPro.g:872:1: ( 'SMS' )
            // InternalQueryPro.g:873:2: 'SMS'
            {
             before(grammarAccess.getSMSAccess().getSMSKeyword_0()); 
            match(input,29,FOLLOW_2); 
             after(grammarAccess.getSMSAccess().getSMSKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SMS__Group__0__Impl"


    // $ANTLR start "rule__SMS__Group__1"
    // InternalQueryPro.g:882:1: rule__SMS__Group__1 : rule__SMS__Group__1__Impl ;
    public final void rule__SMS__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:886:1: ( rule__SMS__Group__1__Impl )
            // InternalQueryPro.g:887:2: rule__SMS__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__SMS__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SMS__Group__1"


    // $ANTLR start "rule__SMS__Group__1__Impl"
    // InternalQueryPro.g:893:1: rule__SMS__Group__1__Impl : ( ( rule__SMS__Alternatives_1 ) ) ;
    public final void rule__SMS__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:897:1: ( ( ( rule__SMS__Alternatives_1 ) ) )
            // InternalQueryPro.g:898:1: ( ( rule__SMS__Alternatives_1 ) )
            {
            // InternalQueryPro.g:898:1: ( ( rule__SMS__Alternatives_1 ) )
            // InternalQueryPro.g:899:2: ( rule__SMS__Alternatives_1 )
            {
             before(grammarAccess.getSMSAccess().getAlternatives_1()); 
            // InternalQueryPro.g:900:2: ( rule__SMS__Alternatives_1 )
            // InternalQueryPro.g:900:3: rule__SMS__Alternatives_1
            {
            pushFollow(FOLLOW_2);
            rule__SMS__Alternatives_1();

            state._fsp--;


            }

             after(grammarAccess.getSMSAccess().getAlternatives_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SMS__Group__1__Impl"


    // $ANTLR start "rule__Internet__Group__0"
    // InternalQueryPro.g:909:1: rule__Internet__Group__0 : rule__Internet__Group__0__Impl rule__Internet__Group__1 ;
    public final void rule__Internet__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:913:1: ( rule__Internet__Group__0__Impl rule__Internet__Group__1 )
            // InternalQueryPro.g:914:2: rule__Internet__Group__0__Impl rule__Internet__Group__1
            {
            pushFollow(FOLLOW_7);
            rule__Internet__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Internet__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Internet__Group__0"


    // $ANTLR start "rule__Internet__Group__0__Impl"
    // InternalQueryPro.g:921:1: rule__Internet__Group__0__Impl : ( 'INTERNET' ) ;
    public final void rule__Internet__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:925:1: ( ( 'INTERNET' ) )
            // InternalQueryPro.g:926:1: ( 'INTERNET' )
            {
            // InternalQueryPro.g:926:1: ( 'INTERNET' )
            // InternalQueryPro.g:927:2: 'INTERNET'
            {
             before(grammarAccess.getInternetAccess().getINTERNETKeyword_0()); 
            match(input,30,FOLLOW_2); 
             after(grammarAccess.getInternetAccess().getINTERNETKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Internet__Group__0__Impl"


    // $ANTLR start "rule__Internet__Group__1"
    // InternalQueryPro.g:936:1: rule__Internet__Group__1 : rule__Internet__Group__1__Impl ;
    public final void rule__Internet__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:940:1: ( rule__Internet__Group__1__Impl )
            // InternalQueryPro.g:941:2: rule__Internet__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Internet__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Internet__Group__1"


    // $ANTLR start "rule__Internet__Group__1__Impl"
    // InternalQueryPro.g:947:1: rule__Internet__Group__1__Impl : ( ( rule__Internet__Alternatives_1 ) ) ;
    public final void rule__Internet__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:951:1: ( ( ( rule__Internet__Alternatives_1 ) ) )
            // InternalQueryPro.g:952:1: ( ( rule__Internet__Alternatives_1 ) )
            {
            // InternalQueryPro.g:952:1: ( ( rule__Internet__Alternatives_1 ) )
            // InternalQueryPro.g:953:2: ( rule__Internet__Alternatives_1 )
            {
             before(grammarAccess.getInternetAccess().getAlternatives_1()); 
            // InternalQueryPro.g:954:2: ( rule__Internet__Alternatives_1 )
            // InternalQueryPro.g:954:3: rule__Internet__Alternatives_1
            {
            pushFollow(FOLLOW_2);
            rule__Internet__Alternatives_1();

            state._fsp--;


            }

             after(grammarAccess.getInternetAccess().getAlternatives_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Internet__Group__1__Impl"


    // $ANTLR start "rule__Internet__Group_1_1_0__0"
    // InternalQueryPro.g:963:1: rule__Internet__Group_1_1_0__0 : rule__Internet__Group_1_1_0__0__Impl rule__Internet__Group_1_1_0__1 ;
    public final void rule__Internet__Group_1_1_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:967:1: ( rule__Internet__Group_1_1_0__0__Impl rule__Internet__Group_1_1_0__1 )
            // InternalQueryPro.g:968:2: rule__Internet__Group_1_1_0__0__Impl rule__Internet__Group_1_1_0__1
            {
            pushFollow(FOLLOW_9);
            rule__Internet__Group_1_1_0__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Internet__Group_1_1_0__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Internet__Group_1_1_0__0"


    // $ANTLR start "rule__Internet__Group_1_1_0__0__Impl"
    // InternalQueryPro.g:975:1: rule__Internet__Group_1_1_0__0__Impl : ( ( rule__Internet__VolumeAssignment_1_1_0_0 ) ) ;
    public final void rule__Internet__Group_1_1_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:979:1: ( ( ( rule__Internet__VolumeAssignment_1_1_0_0 ) ) )
            // InternalQueryPro.g:980:1: ( ( rule__Internet__VolumeAssignment_1_1_0_0 ) )
            {
            // InternalQueryPro.g:980:1: ( ( rule__Internet__VolumeAssignment_1_1_0_0 ) )
            // InternalQueryPro.g:981:2: ( rule__Internet__VolumeAssignment_1_1_0_0 )
            {
             before(grammarAccess.getInternetAccess().getVolumeAssignment_1_1_0_0()); 
            // InternalQueryPro.g:982:2: ( rule__Internet__VolumeAssignment_1_1_0_0 )
            // InternalQueryPro.g:982:3: rule__Internet__VolumeAssignment_1_1_0_0
            {
            pushFollow(FOLLOW_2);
            rule__Internet__VolumeAssignment_1_1_0_0();

            state._fsp--;


            }

             after(grammarAccess.getInternetAccess().getVolumeAssignment_1_1_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Internet__Group_1_1_0__0__Impl"


    // $ANTLR start "rule__Internet__Group_1_1_0__1"
    // InternalQueryPro.g:990:1: rule__Internet__Group_1_1_0__1 : rule__Internet__Group_1_1_0__1__Impl ;
    public final void rule__Internet__Group_1_1_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:994:1: ( rule__Internet__Group_1_1_0__1__Impl )
            // InternalQueryPro.g:995:2: rule__Internet__Group_1_1_0__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Internet__Group_1_1_0__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Internet__Group_1_1_0__1"


    // $ANTLR start "rule__Internet__Group_1_1_0__1__Impl"
    // InternalQueryPro.g:1001:1: rule__Internet__Group_1_1_0__1__Impl : ( 'datenvolumen' ) ;
    public final void rule__Internet__Group_1_1_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1005:1: ( ( 'datenvolumen' ) )
            // InternalQueryPro.g:1006:1: ( 'datenvolumen' )
            {
            // InternalQueryPro.g:1006:1: ( 'datenvolumen' )
            // InternalQueryPro.g:1007:2: 'datenvolumen'
            {
             before(grammarAccess.getInternetAccess().getDatenvolumenKeyword_1_1_0_1()); 
            match(input,31,FOLLOW_2); 
             after(grammarAccess.getInternetAccess().getDatenvolumenKeyword_1_1_0_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Internet__Group_1_1_0__1__Impl"


    // $ANTLR start "rule__Internet__Group_1_1_1__0"
    // InternalQueryPro.g:1017:1: rule__Internet__Group_1_1_1__0 : rule__Internet__Group_1_1_1__0__Impl rule__Internet__Group_1_1_1__1 ;
    public final void rule__Internet__Group_1_1_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1021:1: ( rule__Internet__Group_1_1_1__0__Impl rule__Internet__Group_1_1_1__1 )
            // InternalQueryPro.g:1022:2: rule__Internet__Group_1_1_1__0__Impl rule__Internet__Group_1_1_1__1
            {
            pushFollow(FOLLOW_10);
            rule__Internet__Group_1_1_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Internet__Group_1_1_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Internet__Group_1_1_1__0"


    // $ANTLR start "rule__Internet__Group_1_1_1__0__Impl"
    // InternalQueryPro.g:1029:1: rule__Internet__Group_1_1_1__0__Impl : ( ( rule__Internet__SpeedAssignment_1_1_1_0 ) ) ;
    public final void rule__Internet__Group_1_1_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1033:1: ( ( ( rule__Internet__SpeedAssignment_1_1_1_0 ) ) )
            // InternalQueryPro.g:1034:1: ( ( rule__Internet__SpeedAssignment_1_1_1_0 ) )
            {
            // InternalQueryPro.g:1034:1: ( ( rule__Internet__SpeedAssignment_1_1_1_0 ) )
            // InternalQueryPro.g:1035:2: ( rule__Internet__SpeedAssignment_1_1_1_0 )
            {
             before(grammarAccess.getInternetAccess().getSpeedAssignment_1_1_1_0()); 
            // InternalQueryPro.g:1036:2: ( rule__Internet__SpeedAssignment_1_1_1_0 )
            // InternalQueryPro.g:1036:3: rule__Internet__SpeedAssignment_1_1_1_0
            {
            pushFollow(FOLLOW_2);
            rule__Internet__SpeedAssignment_1_1_1_0();

            state._fsp--;


            }

             after(grammarAccess.getInternetAccess().getSpeedAssignment_1_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Internet__Group_1_1_1__0__Impl"


    // $ANTLR start "rule__Internet__Group_1_1_1__1"
    // InternalQueryPro.g:1044:1: rule__Internet__Group_1_1_1__1 : rule__Internet__Group_1_1_1__1__Impl ;
    public final void rule__Internet__Group_1_1_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1048:1: ( rule__Internet__Group_1_1_1__1__Impl )
            // InternalQueryPro.g:1049:2: rule__Internet__Group_1_1_1__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Internet__Group_1_1_1__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Internet__Group_1_1_1__1"


    // $ANTLR start "rule__Internet__Group_1_1_1__1__Impl"
    // InternalQueryPro.g:1055:1: rule__Internet__Group_1_1_1__1__Impl : ( 'MBits' ) ;
    public final void rule__Internet__Group_1_1_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1059:1: ( ( 'MBits' ) )
            // InternalQueryPro.g:1060:1: ( 'MBits' )
            {
            // InternalQueryPro.g:1060:1: ( 'MBits' )
            // InternalQueryPro.g:1061:2: 'MBits'
            {
             before(grammarAccess.getInternetAccess().getMBitsKeyword_1_1_1_1()); 
            match(input,32,FOLLOW_2); 
             after(grammarAccess.getInternetAccess().getMBitsKeyword_1_1_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Internet__Group_1_1_1__1__Impl"


    // $ANTLR start "rule__Net__Group__0"
    // InternalQueryPro.g:1071:1: rule__Net__Group__0 : rule__Net__Group__0__Impl rule__Net__Group__1 ;
    public final void rule__Net__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1075:1: ( rule__Net__Group__0__Impl rule__Net__Group__1 )
            // InternalQueryPro.g:1076:2: rule__Net__Group__0__Impl rule__Net__Group__1
            {
            pushFollow(FOLLOW_11);
            rule__Net__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Net__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Net__Group__0"


    // $ANTLR start "rule__Net__Group__0__Impl"
    // InternalQueryPro.g:1083:1: rule__Net__Group__0__Impl : ( 'NETZ' ) ;
    public final void rule__Net__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1087:1: ( ( 'NETZ' ) )
            // InternalQueryPro.g:1088:1: ( 'NETZ' )
            {
            // InternalQueryPro.g:1088:1: ( 'NETZ' )
            // InternalQueryPro.g:1089:2: 'NETZ'
            {
             before(grammarAccess.getNetAccess().getNETZKeyword_0()); 
            match(input,33,FOLLOW_2); 
             after(grammarAccess.getNetAccess().getNETZKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Net__Group__0__Impl"


    // $ANTLR start "rule__Net__Group__1"
    // InternalQueryPro.g:1098:1: rule__Net__Group__1 : rule__Net__Group__1__Impl ;
    public final void rule__Net__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1102:1: ( rule__Net__Group__1__Impl )
            // InternalQueryPro.g:1103:2: rule__Net__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Net__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Net__Group__1"


    // $ANTLR start "rule__Net__Group__1__Impl"
    // InternalQueryPro.g:1109:1: rule__Net__Group__1__Impl : ( ( rule__Net__Alternatives_1 ) ) ;
    public final void rule__Net__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1113:1: ( ( ( rule__Net__Alternatives_1 ) ) )
            // InternalQueryPro.g:1114:1: ( ( rule__Net__Alternatives_1 ) )
            {
            // InternalQueryPro.g:1114:1: ( ( rule__Net__Alternatives_1 ) )
            // InternalQueryPro.g:1115:2: ( rule__Net__Alternatives_1 )
            {
             before(grammarAccess.getNetAccess().getAlternatives_1()); 
            // InternalQueryPro.g:1116:2: ( rule__Net__Alternatives_1 )
            // InternalQueryPro.g:1116:3: rule__Net__Alternatives_1
            {
            pushFollow(FOLLOW_2);
            rule__Net__Alternatives_1();

            state._fsp--;


            }

             after(grammarAccess.getNetAccess().getAlternatives_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Net__Group__1__Impl"


    // $ANTLR start "rule__Flexibilty__Group__0"
    // InternalQueryPro.g:1125:1: rule__Flexibilty__Group__0 : rule__Flexibilty__Group__0__Impl rule__Flexibilty__Group__1 ;
    public final void rule__Flexibilty__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1129:1: ( rule__Flexibilty__Group__0__Impl rule__Flexibilty__Group__1 )
            // InternalQueryPro.g:1130:2: rule__Flexibilty__Group__0__Impl rule__Flexibilty__Group__1
            {
            pushFollow(FOLLOW_12);
            rule__Flexibilty__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Flexibilty__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Flexibilty__Group__0"


    // $ANTLR start "rule__Flexibilty__Group__0__Impl"
    // InternalQueryPro.g:1137:1: rule__Flexibilty__Group__0__Impl : ( 'LAUFZEIT' ) ;
    public final void rule__Flexibilty__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1141:1: ( ( 'LAUFZEIT' ) )
            // InternalQueryPro.g:1142:1: ( 'LAUFZEIT' )
            {
            // InternalQueryPro.g:1142:1: ( 'LAUFZEIT' )
            // InternalQueryPro.g:1143:2: 'LAUFZEIT'
            {
             before(grammarAccess.getFlexibiltyAccess().getLAUFZEITKeyword_0()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getFlexibiltyAccess().getLAUFZEITKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Flexibilty__Group__0__Impl"


    // $ANTLR start "rule__Flexibilty__Group__1"
    // InternalQueryPro.g:1152:1: rule__Flexibilty__Group__1 : rule__Flexibilty__Group__1__Impl ;
    public final void rule__Flexibilty__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1156:1: ( rule__Flexibilty__Group__1__Impl )
            // InternalQueryPro.g:1157:2: rule__Flexibilty__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Flexibilty__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Flexibilty__Group__1"


    // $ANTLR start "rule__Flexibilty__Group__1__Impl"
    // InternalQueryPro.g:1163:1: rule__Flexibilty__Group__1__Impl : ( ( rule__Flexibilty__Alternatives_1 ) ) ;
    public final void rule__Flexibilty__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1167:1: ( ( ( rule__Flexibilty__Alternatives_1 ) ) )
            // InternalQueryPro.g:1168:1: ( ( rule__Flexibilty__Alternatives_1 ) )
            {
            // InternalQueryPro.g:1168:1: ( ( rule__Flexibilty__Alternatives_1 ) )
            // InternalQueryPro.g:1169:2: ( rule__Flexibilty__Alternatives_1 )
            {
             before(grammarAccess.getFlexibiltyAccess().getAlternatives_1()); 
            // InternalQueryPro.g:1170:2: ( rule__Flexibilty__Alternatives_1 )
            // InternalQueryPro.g:1170:3: rule__Flexibilty__Alternatives_1
            {
            pushFollow(FOLLOW_2);
            rule__Flexibilty__Alternatives_1();

            state._fsp--;


            }

             after(grammarAccess.getFlexibiltyAccess().getAlternatives_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Flexibilty__Group__1__Impl"


    // $ANTLR start "rule__Phone__Group__0"
    // InternalQueryPro.g:1179:1: rule__Phone__Group__0 : rule__Phone__Group__0__Impl rule__Phone__Group__1 ;
    public final void rule__Phone__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1183:1: ( rule__Phone__Group__0__Impl rule__Phone__Group__1 )
            // InternalQueryPro.g:1184:2: rule__Phone__Group__0__Impl rule__Phone__Group__1
            {
            pushFollow(FOLLOW_13);
            rule__Phone__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Phone__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Phone__Group__0"


    // $ANTLR start "rule__Phone__Group__0__Impl"
    // InternalQueryPro.g:1191:1: rule__Phone__Group__0__Impl : ( 'HANDY' ) ;
    public final void rule__Phone__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1195:1: ( ( 'HANDY' ) )
            // InternalQueryPro.g:1196:1: ( 'HANDY' )
            {
            // InternalQueryPro.g:1196:1: ( 'HANDY' )
            // InternalQueryPro.g:1197:2: 'HANDY'
            {
             before(grammarAccess.getPhoneAccess().getHANDYKeyword_0()); 
            match(input,35,FOLLOW_2); 
             after(grammarAccess.getPhoneAccess().getHANDYKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Phone__Group__0__Impl"


    // $ANTLR start "rule__Phone__Group__1"
    // InternalQueryPro.g:1206:1: rule__Phone__Group__1 : rule__Phone__Group__1__Impl ;
    public final void rule__Phone__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1210:1: ( rule__Phone__Group__1__Impl )
            // InternalQueryPro.g:1211:2: rule__Phone__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Phone__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Phone__Group__1"


    // $ANTLR start "rule__Phone__Group__1__Impl"
    // InternalQueryPro.g:1217:1: rule__Phone__Group__1__Impl : ( ( ( rule__Phone__Alternatives_1 ) ) ( ( rule__Phone__Alternatives_1 )* ) ) ;
    public final void rule__Phone__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1221:1: ( ( ( ( rule__Phone__Alternatives_1 ) ) ( ( rule__Phone__Alternatives_1 )* ) ) )
            // InternalQueryPro.g:1222:1: ( ( ( rule__Phone__Alternatives_1 ) ) ( ( rule__Phone__Alternatives_1 )* ) )
            {
            // InternalQueryPro.g:1222:1: ( ( ( rule__Phone__Alternatives_1 ) ) ( ( rule__Phone__Alternatives_1 )* ) )
            // InternalQueryPro.g:1223:2: ( ( rule__Phone__Alternatives_1 ) ) ( ( rule__Phone__Alternatives_1 )* )
            {
            // InternalQueryPro.g:1223:2: ( ( rule__Phone__Alternatives_1 ) )
            // InternalQueryPro.g:1224:3: ( rule__Phone__Alternatives_1 )
            {
             before(grammarAccess.getPhoneAccess().getAlternatives_1()); 
            // InternalQueryPro.g:1225:3: ( rule__Phone__Alternatives_1 )
            // InternalQueryPro.g:1225:4: rule__Phone__Alternatives_1
            {
            pushFollow(FOLLOW_14);
            rule__Phone__Alternatives_1();

            state._fsp--;


            }

             after(grammarAccess.getPhoneAccess().getAlternatives_1()); 

            }

            // InternalQueryPro.g:1228:2: ( ( rule__Phone__Alternatives_1 )* )
            // InternalQueryPro.g:1229:3: ( rule__Phone__Alternatives_1 )*
            {
             before(grammarAccess.getPhoneAccess().getAlternatives_1()); 
            // InternalQueryPro.g:1230:3: ( rule__Phone__Alternatives_1 )*
            loop17:
            do {
                int alt17=2;
                int LA17_0 = input.LA(1);

                if ( ((LA17_0>=36 && LA17_0<=38)) ) {
                    alt17=1;
                }


                switch (alt17) {
            	case 1 :
            	    // InternalQueryPro.g:1230:4: rule__Phone__Alternatives_1
            	    {
            	    pushFollow(FOLLOW_14);
            	    rule__Phone__Alternatives_1();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop17;
                }
            } while (true);

             after(grammarAccess.getPhoneAccess().getAlternatives_1()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Phone__Group__1__Impl"


    // $ANTLR start "rule__Phone__Group_1_0__0"
    // InternalQueryPro.g:1240:1: rule__Phone__Group_1_0__0 : rule__Phone__Group_1_0__0__Impl rule__Phone__Group_1_0__1 ;
    public final void rule__Phone__Group_1_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1244:1: ( rule__Phone__Group_1_0__0__Impl rule__Phone__Group_1_0__1 )
            // InternalQueryPro.g:1245:2: rule__Phone__Group_1_0__0__Impl rule__Phone__Group_1_0__1
            {
            pushFollow(FOLLOW_15);
            rule__Phone__Group_1_0__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Phone__Group_1_0__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Phone__Group_1_0__0"


    // $ANTLR start "rule__Phone__Group_1_0__0__Impl"
    // InternalQueryPro.g:1252:1: rule__Phone__Group_1_0__0__Impl : ( 'Marke' ) ;
    public final void rule__Phone__Group_1_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1256:1: ( ( 'Marke' ) )
            // InternalQueryPro.g:1257:1: ( 'Marke' )
            {
            // InternalQueryPro.g:1257:1: ( 'Marke' )
            // InternalQueryPro.g:1258:2: 'Marke'
            {
             before(grammarAccess.getPhoneAccess().getMarkeKeyword_1_0_0()); 
            match(input,36,FOLLOW_2); 
             after(grammarAccess.getPhoneAccess().getMarkeKeyword_1_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Phone__Group_1_0__0__Impl"


    // $ANTLR start "rule__Phone__Group_1_0__1"
    // InternalQueryPro.g:1267:1: rule__Phone__Group_1_0__1 : rule__Phone__Group_1_0__1__Impl ;
    public final void rule__Phone__Group_1_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1271:1: ( rule__Phone__Group_1_0__1__Impl )
            // InternalQueryPro.g:1272:2: rule__Phone__Group_1_0__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Phone__Group_1_0__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Phone__Group_1_0__1"


    // $ANTLR start "rule__Phone__Group_1_0__1__Impl"
    // InternalQueryPro.g:1278:1: rule__Phone__Group_1_0__1__Impl : ( ( rule__Phone__BrandAssignment_1_0_1 ) ) ;
    public final void rule__Phone__Group_1_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1282:1: ( ( ( rule__Phone__BrandAssignment_1_0_1 ) ) )
            // InternalQueryPro.g:1283:1: ( ( rule__Phone__BrandAssignment_1_0_1 ) )
            {
            // InternalQueryPro.g:1283:1: ( ( rule__Phone__BrandAssignment_1_0_1 ) )
            // InternalQueryPro.g:1284:2: ( rule__Phone__BrandAssignment_1_0_1 )
            {
             before(grammarAccess.getPhoneAccess().getBrandAssignment_1_0_1()); 
            // InternalQueryPro.g:1285:2: ( rule__Phone__BrandAssignment_1_0_1 )
            // InternalQueryPro.g:1285:3: rule__Phone__BrandAssignment_1_0_1
            {
            pushFollow(FOLLOW_2);
            rule__Phone__BrandAssignment_1_0_1();

            state._fsp--;


            }

             after(grammarAccess.getPhoneAccess().getBrandAssignment_1_0_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Phone__Group_1_0__1__Impl"


    // $ANTLR start "rule__Phone__Group_1_1__0"
    // InternalQueryPro.g:1294:1: rule__Phone__Group_1_1__0 : rule__Phone__Group_1_1__0__Impl rule__Phone__Group_1_1__1 ;
    public final void rule__Phone__Group_1_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1298:1: ( rule__Phone__Group_1_1__0__Impl rule__Phone__Group_1_1__1 )
            // InternalQueryPro.g:1299:2: rule__Phone__Group_1_1__0__Impl rule__Phone__Group_1_1__1
            {
            pushFollow(FOLLOW_16);
            rule__Phone__Group_1_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Phone__Group_1_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Phone__Group_1_1__0"


    // $ANTLR start "rule__Phone__Group_1_1__0__Impl"
    // InternalQueryPro.g:1306:1: rule__Phone__Group_1_1__0__Impl : ( 'Betriebssystem' ) ;
    public final void rule__Phone__Group_1_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1310:1: ( ( 'Betriebssystem' ) )
            // InternalQueryPro.g:1311:1: ( 'Betriebssystem' )
            {
            // InternalQueryPro.g:1311:1: ( 'Betriebssystem' )
            // InternalQueryPro.g:1312:2: 'Betriebssystem'
            {
             before(grammarAccess.getPhoneAccess().getBetriebssystemKeyword_1_1_0()); 
            match(input,37,FOLLOW_2); 
             after(grammarAccess.getPhoneAccess().getBetriebssystemKeyword_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Phone__Group_1_1__0__Impl"


    // $ANTLR start "rule__Phone__Group_1_1__1"
    // InternalQueryPro.g:1321:1: rule__Phone__Group_1_1__1 : rule__Phone__Group_1_1__1__Impl ;
    public final void rule__Phone__Group_1_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1325:1: ( rule__Phone__Group_1_1__1__Impl )
            // InternalQueryPro.g:1326:2: rule__Phone__Group_1_1__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Phone__Group_1_1__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Phone__Group_1_1__1"


    // $ANTLR start "rule__Phone__Group_1_1__1__Impl"
    // InternalQueryPro.g:1332:1: rule__Phone__Group_1_1__1__Impl : ( ( rule__Phone__OsAssignment_1_1_1 ) ) ;
    public final void rule__Phone__Group_1_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1336:1: ( ( ( rule__Phone__OsAssignment_1_1_1 ) ) )
            // InternalQueryPro.g:1337:1: ( ( rule__Phone__OsAssignment_1_1_1 ) )
            {
            // InternalQueryPro.g:1337:1: ( ( rule__Phone__OsAssignment_1_1_1 ) )
            // InternalQueryPro.g:1338:2: ( rule__Phone__OsAssignment_1_1_1 )
            {
             before(grammarAccess.getPhoneAccess().getOsAssignment_1_1_1()); 
            // InternalQueryPro.g:1339:2: ( rule__Phone__OsAssignment_1_1_1 )
            // InternalQueryPro.g:1339:3: rule__Phone__OsAssignment_1_1_1
            {
            pushFollow(FOLLOW_2);
            rule__Phone__OsAssignment_1_1_1();

            state._fsp--;


            }

             after(grammarAccess.getPhoneAccess().getOsAssignment_1_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Phone__Group_1_1__1__Impl"


    // $ANTLR start "rule__Phone__Group_1_2__0"
    // InternalQueryPro.g:1348:1: rule__Phone__Group_1_2__0 : rule__Phone__Group_1_2__0__Impl rule__Phone__Group_1_2__1 ;
    public final void rule__Phone__Group_1_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1352:1: ( rule__Phone__Group_1_2__0__Impl rule__Phone__Group_1_2__1 )
            // InternalQueryPro.g:1353:2: rule__Phone__Group_1_2__0__Impl rule__Phone__Group_1_2__1
            {
            pushFollow(FOLLOW_4);
            rule__Phone__Group_1_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Phone__Group_1_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Phone__Group_1_2__0"


    // $ANTLR start "rule__Phone__Group_1_2__0__Impl"
    // InternalQueryPro.g:1360:1: rule__Phone__Group_1_2__0__Impl : ( 'Speicher' ) ;
    public final void rule__Phone__Group_1_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1364:1: ( ( 'Speicher' ) )
            // InternalQueryPro.g:1365:1: ( 'Speicher' )
            {
            // InternalQueryPro.g:1365:1: ( 'Speicher' )
            // InternalQueryPro.g:1366:2: 'Speicher'
            {
             before(grammarAccess.getPhoneAccess().getSpeicherKeyword_1_2_0()); 
            match(input,38,FOLLOW_2); 
             after(grammarAccess.getPhoneAccess().getSpeicherKeyword_1_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Phone__Group_1_2__0__Impl"


    // $ANTLR start "rule__Phone__Group_1_2__1"
    // InternalQueryPro.g:1375:1: rule__Phone__Group_1_2__1 : rule__Phone__Group_1_2__1__Impl ;
    public final void rule__Phone__Group_1_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1379:1: ( rule__Phone__Group_1_2__1__Impl )
            // InternalQueryPro.g:1380:2: rule__Phone__Group_1_2__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Phone__Group_1_2__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Phone__Group_1_2__1"


    // $ANTLR start "rule__Phone__Group_1_2__1__Impl"
    // InternalQueryPro.g:1386:1: rule__Phone__Group_1_2__1__Impl : ( ( rule__Phone__StorageAssignment_1_2_1 ) ) ;
    public final void rule__Phone__Group_1_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1390:1: ( ( ( rule__Phone__StorageAssignment_1_2_1 ) ) )
            // InternalQueryPro.g:1391:1: ( ( rule__Phone__StorageAssignment_1_2_1 ) )
            {
            // InternalQueryPro.g:1391:1: ( ( rule__Phone__StorageAssignment_1_2_1 ) )
            // InternalQueryPro.g:1392:2: ( rule__Phone__StorageAssignment_1_2_1 )
            {
             before(grammarAccess.getPhoneAccess().getStorageAssignment_1_2_1()); 
            // InternalQueryPro.g:1393:2: ( rule__Phone__StorageAssignment_1_2_1 )
            // InternalQueryPro.g:1393:3: rule__Phone__StorageAssignment_1_2_1
            {
            pushFollow(FOLLOW_2);
            rule__Phone__StorageAssignment_1_2_1();

            state._fsp--;


            }

             after(grammarAccess.getPhoneAccess().getStorageAssignment_1_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Phone__Group_1_2__1__Impl"


    // $ANTLR start "rule__Query__AmountAssignment_1"
    // InternalQueryPro.g:1402:1: rule__Query__AmountAssignment_1 : ( RULE_INT ) ;
    public final void rule__Query__AmountAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1406:1: ( ( RULE_INT ) )
            // InternalQueryPro.g:1407:2: ( RULE_INT )
            {
            // InternalQueryPro.g:1407:2: ( RULE_INT )
            // InternalQueryPro.g:1408:3: RULE_INT
            {
             before(grammarAccess.getQueryAccess().getAmountINTTerminalRuleCall_1_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getQueryAccess().getAmountINTTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Query__AmountAssignment_1"


    // $ANTLR start "rule__Query__KritsAssignment_2"
    // InternalQueryPro.g:1417:1: rule__Query__KritsAssignment_2 : ( ruleKriteria ) ;
    public final void rule__Query__KritsAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1421:1: ( ( ruleKriteria ) )
            // InternalQueryPro.g:1422:2: ( ruleKriteria )
            {
            // InternalQueryPro.g:1422:2: ( ruleKriteria )
            // InternalQueryPro.g:1423:3: ruleKriteria
            {
             before(grammarAccess.getQueryAccess().getKritsKriteriaParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleKriteria();

            state._fsp--;

             after(grammarAccess.getQueryAccess().getKritsKriteriaParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Query__KritsAssignment_2"


    // $ANTLR start "rule__Kriteria__TypeAssignment"
    // InternalQueryPro.g:1432:1: rule__Kriteria__TypeAssignment : ( ( rule__Kriteria__TypeAlternatives_0 ) ) ;
    public final void rule__Kriteria__TypeAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1436:1: ( ( ( rule__Kriteria__TypeAlternatives_0 ) ) )
            // InternalQueryPro.g:1437:2: ( ( rule__Kriteria__TypeAlternatives_0 ) )
            {
            // InternalQueryPro.g:1437:2: ( ( rule__Kriteria__TypeAlternatives_0 ) )
            // InternalQueryPro.g:1438:3: ( rule__Kriteria__TypeAlternatives_0 )
            {
             before(grammarAccess.getKriteriaAccess().getTypeAlternatives_0()); 
            // InternalQueryPro.g:1439:3: ( rule__Kriteria__TypeAlternatives_0 )
            // InternalQueryPro.g:1439:4: rule__Kriteria__TypeAlternatives_0
            {
            pushFollow(FOLLOW_2);
            rule__Kriteria__TypeAlternatives_0();

            state._fsp--;


            }

             after(grammarAccess.getKriteriaAccess().getTypeAlternatives_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Kriteria__TypeAssignment"


    // $ANTLR start "rule__Telephone__ValueAssignment_1_0"
    // InternalQueryPro.g:1447:1: rule__Telephone__ValueAssignment_1_0 : ( ruleIntensitaet ) ;
    public final void rule__Telephone__ValueAssignment_1_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1451:1: ( ( ruleIntensitaet ) )
            // InternalQueryPro.g:1452:2: ( ruleIntensitaet )
            {
            // InternalQueryPro.g:1452:2: ( ruleIntensitaet )
            // InternalQueryPro.g:1453:3: ruleIntensitaet
            {
             before(grammarAccess.getTelephoneAccess().getValueIntensitaetEnumRuleCall_1_0_0()); 
            pushFollow(FOLLOW_2);
            ruleIntensitaet();

            state._fsp--;

             after(grammarAccess.getTelephoneAccess().getValueIntensitaetEnumRuleCall_1_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Telephone__ValueAssignment_1_0"


    // $ANTLR start "rule__Telephone__FreeminutesAssignment_1_1"
    // InternalQueryPro.g:1462:1: rule__Telephone__FreeminutesAssignment_1_1 : ( RULE_INT ) ;
    public final void rule__Telephone__FreeminutesAssignment_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1466:1: ( ( RULE_INT ) )
            // InternalQueryPro.g:1467:2: ( RULE_INT )
            {
            // InternalQueryPro.g:1467:2: ( RULE_INT )
            // InternalQueryPro.g:1468:3: RULE_INT
            {
             before(grammarAccess.getTelephoneAccess().getFreeminutesINTTerminalRuleCall_1_1_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getTelephoneAccess().getFreeminutesINTTerminalRuleCall_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Telephone__FreeminutesAssignment_1_1"


    // $ANTLR start "rule__SMS__ValueAssignment_1_0"
    // InternalQueryPro.g:1477:1: rule__SMS__ValueAssignment_1_0 : ( ruleIntensitaet ) ;
    public final void rule__SMS__ValueAssignment_1_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1481:1: ( ( ruleIntensitaet ) )
            // InternalQueryPro.g:1482:2: ( ruleIntensitaet )
            {
            // InternalQueryPro.g:1482:2: ( ruleIntensitaet )
            // InternalQueryPro.g:1483:3: ruleIntensitaet
            {
             before(grammarAccess.getSMSAccess().getValueIntensitaetEnumRuleCall_1_0_0()); 
            pushFollow(FOLLOW_2);
            ruleIntensitaet();

            state._fsp--;

             after(grammarAccess.getSMSAccess().getValueIntensitaetEnumRuleCall_1_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SMS__ValueAssignment_1_0"


    // $ANTLR start "rule__SMS__CostAssignment_1_1"
    // InternalQueryPro.g:1492:1: rule__SMS__CostAssignment_1_1 : ( RULE_PRICE ) ;
    public final void rule__SMS__CostAssignment_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1496:1: ( ( RULE_PRICE ) )
            // InternalQueryPro.g:1497:2: ( RULE_PRICE )
            {
            // InternalQueryPro.g:1497:2: ( RULE_PRICE )
            // InternalQueryPro.g:1498:3: RULE_PRICE
            {
             before(grammarAccess.getSMSAccess().getCostPRICETerminalRuleCall_1_1_0()); 
            match(input,RULE_PRICE,FOLLOW_2); 
             after(grammarAccess.getSMSAccess().getCostPRICETerminalRuleCall_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SMS__CostAssignment_1_1"


    // $ANTLR start "rule__Internet__ValueAssignment_1_0"
    // InternalQueryPro.g:1507:1: rule__Internet__ValueAssignment_1_0 : ( ruleIntensitaet ) ;
    public final void rule__Internet__ValueAssignment_1_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1511:1: ( ( ruleIntensitaet ) )
            // InternalQueryPro.g:1512:2: ( ruleIntensitaet )
            {
            // InternalQueryPro.g:1512:2: ( ruleIntensitaet )
            // InternalQueryPro.g:1513:3: ruleIntensitaet
            {
             before(grammarAccess.getInternetAccess().getValueIntensitaetEnumRuleCall_1_0_0()); 
            pushFollow(FOLLOW_2);
            ruleIntensitaet();

            state._fsp--;

             after(grammarAccess.getInternetAccess().getValueIntensitaetEnumRuleCall_1_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Internet__ValueAssignment_1_0"


    // $ANTLR start "rule__Internet__VolumeAssignment_1_1_0_0"
    // InternalQueryPro.g:1522:1: rule__Internet__VolumeAssignment_1_1_0_0 : ( RULE_INT ) ;
    public final void rule__Internet__VolumeAssignment_1_1_0_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1526:1: ( ( RULE_INT ) )
            // InternalQueryPro.g:1527:2: ( RULE_INT )
            {
            // InternalQueryPro.g:1527:2: ( RULE_INT )
            // InternalQueryPro.g:1528:3: RULE_INT
            {
             before(grammarAccess.getInternetAccess().getVolumeINTTerminalRuleCall_1_1_0_0_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getInternetAccess().getVolumeINTTerminalRuleCall_1_1_0_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Internet__VolumeAssignment_1_1_0_0"


    // $ANTLR start "rule__Internet__SpeedAssignment_1_1_1_0"
    // InternalQueryPro.g:1537:1: rule__Internet__SpeedAssignment_1_1_1_0 : ( RULE_INT ) ;
    public final void rule__Internet__SpeedAssignment_1_1_1_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1541:1: ( ( RULE_INT ) )
            // InternalQueryPro.g:1542:2: ( RULE_INT )
            {
            // InternalQueryPro.g:1542:2: ( RULE_INT )
            // InternalQueryPro.g:1543:3: RULE_INT
            {
             before(grammarAccess.getInternetAccess().getSpeedINTTerminalRuleCall_1_1_1_0_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getInternetAccess().getSpeedINTTerminalRuleCall_1_1_1_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Internet__SpeedAssignment_1_1_1_0"


    // $ANTLR start "rule__Net__ValueAssignment_1_0"
    // InternalQueryPro.g:1552:1: rule__Net__ValueAssignment_1_0 : ( ruleNetzverbreitung ) ;
    public final void rule__Net__ValueAssignment_1_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1556:1: ( ( ruleNetzverbreitung ) )
            // InternalQueryPro.g:1557:2: ( ruleNetzverbreitung )
            {
            // InternalQueryPro.g:1557:2: ( ruleNetzverbreitung )
            // InternalQueryPro.g:1558:3: ruleNetzverbreitung
            {
             before(grammarAccess.getNetAccess().getValueNetzverbreitungEnumRuleCall_1_0_0()); 
            pushFollow(FOLLOW_2);
            ruleNetzverbreitung();

            state._fsp--;

             after(grammarAccess.getNetAccess().getValueNetzverbreitungEnumRuleCall_1_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Net__ValueAssignment_1_0"


    // $ANTLR start "rule__Net__NetAssignment_1_1"
    // InternalQueryPro.g:1567:1: rule__Net__NetAssignment_1_1 : ( ruleNetzanbieter ) ;
    public final void rule__Net__NetAssignment_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1571:1: ( ( ruleNetzanbieter ) )
            // InternalQueryPro.g:1572:2: ( ruleNetzanbieter )
            {
            // InternalQueryPro.g:1572:2: ( ruleNetzanbieter )
            // InternalQueryPro.g:1573:3: ruleNetzanbieter
            {
             before(grammarAccess.getNetAccess().getNetNetzanbieterEnumRuleCall_1_1_0()); 
            pushFollow(FOLLOW_2);
            ruleNetzanbieter();

            state._fsp--;

             after(grammarAccess.getNetAccess().getNetNetzanbieterEnumRuleCall_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Net__NetAssignment_1_1"


    // $ANTLR start "rule__Flexibilty__ValueAssignment_1_0"
    // InternalQueryPro.g:1582:1: rule__Flexibilty__ValueAssignment_1_0 : ( ruleVertragskondition ) ;
    public final void rule__Flexibilty__ValueAssignment_1_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1586:1: ( ( ruleVertragskondition ) )
            // InternalQueryPro.g:1587:2: ( ruleVertragskondition )
            {
            // InternalQueryPro.g:1587:2: ( ruleVertragskondition )
            // InternalQueryPro.g:1588:3: ruleVertragskondition
            {
             before(grammarAccess.getFlexibiltyAccess().getValueVertragskonditionEnumRuleCall_1_0_0()); 
            pushFollow(FOLLOW_2);
            ruleVertragskondition();

            state._fsp--;

             after(grammarAccess.getFlexibiltyAccess().getValueVertragskonditionEnumRuleCall_1_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Flexibilty__ValueAssignment_1_0"


    // $ANTLR start "rule__Flexibilty__MonthsAssignment_1_1"
    // InternalQueryPro.g:1597:1: rule__Flexibilty__MonthsAssignment_1_1 : ( RULE_INT ) ;
    public final void rule__Flexibilty__MonthsAssignment_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1601:1: ( ( RULE_INT ) )
            // InternalQueryPro.g:1602:2: ( RULE_INT )
            {
            // InternalQueryPro.g:1602:2: ( RULE_INT )
            // InternalQueryPro.g:1603:3: RULE_INT
            {
             before(grammarAccess.getFlexibiltyAccess().getMonthsINTTerminalRuleCall_1_1_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getFlexibiltyAccess().getMonthsINTTerminalRuleCall_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Flexibilty__MonthsAssignment_1_1"


    // $ANTLR start "rule__Phone__BrandAssignment_1_0_1"
    // InternalQueryPro.g:1612:1: rule__Phone__BrandAssignment_1_0_1 : ( ruleMarke ) ;
    public final void rule__Phone__BrandAssignment_1_0_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1616:1: ( ( ruleMarke ) )
            // InternalQueryPro.g:1617:2: ( ruleMarke )
            {
            // InternalQueryPro.g:1617:2: ( ruleMarke )
            // InternalQueryPro.g:1618:3: ruleMarke
            {
             before(grammarAccess.getPhoneAccess().getBrandMarkeEnumRuleCall_1_0_1_0()); 
            pushFollow(FOLLOW_2);
            ruleMarke();

            state._fsp--;

             after(grammarAccess.getPhoneAccess().getBrandMarkeEnumRuleCall_1_0_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Phone__BrandAssignment_1_0_1"


    // $ANTLR start "rule__Phone__OsAssignment_1_1_1"
    // InternalQueryPro.g:1627:1: rule__Phone__OsAssignment_1_1_1 : ( ruleBetriebssystem ) ;
    public final void rule__Phone__OsAssignment_1_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1631:1: ( ( ruleBetriebssystem ) )
            // InternalQueryPro.g:1632:2: ( ruleBetriebssystem )
            {
            // InternalQueryPro.g:1632:2: ( ruleBetriebssystem )
            // InternalQueryPro.g:1633:3: ruleBetriebssystem
            {
             before(grammarAccess.getPhoneAccess().getOsBetriebssystemEnumRuleCall_1_1_1_0()); 
            pushFollow(FOLLOW_2);
            ruleBetriebssystem();

            state._fsp--;

             after(grammarAccess.getPhoneAccess().getOsBetriebssystemEnumRuleCall_1_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Phone__OsAssignment_1_1_1"


    // $ANTLR start "rule__Phone__StorageAssignment_1_2_1"
    // InternalQueryPro.g:1642:1: rule__Phone__StorageAssignment_1_2_1 : ( RULE_INT ) ;
    public final void rule__Phone__StorageAssignment_1_2_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalQueryPro.g:1646:1: ( ( RULE_INT ) )
            // InternalQueryPro.g:1647:2: ( RULE_INT )
            {
            // InternalQueryPro.g:1647:2: ( RULE_INT )
            // InternalQueryPro.g:1648:3: RULE_INT
            {
             before(grammarAccess.getPhoneAccess().getStorageINTTerminalRuleCall_1_2_1_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getPhoneAccess().getStorageINTTerminalRuleCall_1_2_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Phone__StorageAssignment_1_2_1"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000012L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000E70000000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000E70000002L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x00000000000C8010L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x00000000000C8020L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000080000000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000100000000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x000000000030F000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000D08010L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000007000000000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000007000000002L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000007008000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000038000L});

}